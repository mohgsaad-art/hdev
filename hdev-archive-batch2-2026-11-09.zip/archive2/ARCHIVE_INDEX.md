# HDEV project archive, batch 2 (9 Nov 2026)

These files were removed from the claude.ai project "HDEV sizing & Modelling Tool" to declutter it.

Their still-valid content was merged into three living project docs:
- `claude/status-engine.md`: engine, system design, PTO, consumption, validation, next steps.
- `claude/status-data-library.md`: EEA data, library rules, weights, chargers/tariffs.
- Both copies, as of 9 Nov, are included here.

## claude/ (exact project copies, read on 9 Nov)

**Engine closeouts, merged into status-engine.md:**
- `session-closeout-2026-10-12-kiro-planning.md`
- `status-and-known-contradictions-2026-10-12.md`
- `year-and-day-simulation-problem-2026-10-12.md`
- `session-closeout-2026-10-19-paux-hvac.md`. Holds the full climate/COP and HD-case tables.
- `session-closeout-2026-10-21-pto-driver.md`. Holds the 21 Oct driver_model code and the VECTO driver research.
- `session-closeout-2026-10-22-consumption-harness.md`
- `session-closeout-2026-10-22-vecto-bev-comparison.md`
- `session-closeout-2026-10-22-function-review-crosswind-payload-pto.md`. Holds the fridge (TRU) design.
- `session-closeout-2026-10-22-validation-drivetrain-winter.md`. Holds the validation source links. Also in the repo at `docs/research/inputs/`.
- `session-closeout-2026-10-31-pto.md`

**Data library, merged into status-data-library.md:**
- `session-closeout-2026-11-06-data-library-research.md`
- `session-closeout-2026-11-07-eea-library-validation.md`. Also in the repo at `docs/research/inputs/`.
- `status-data-library-combined-2026-11-07.md`

**Executed Kiro prompts:**
- `kiro-prompt-assistant-ui-2026-10-15.md`
- `kiro-prompt-finish-all-2026-10-15.md`
- `kiro-prompt-ui-mockup-2026-10-26.md`
- `kiro-prompt-driver-model-review-2026-11-02.md`. Appendix 1 = the 2 Nov driver_model code of record.
- `kiro-prompt-driver-model-followup-2026-11-03.md`
- `kiro-prompt-drivetrain-inputs-fallbacks-2026-11-03.md`

**Scripts:**
- `hdev_test_harness_v1.5.py` and `hdev_test_harness_v1.6.py`. Superseded by v1.7, which is in batch 1 and in the repo at `docs/research/vecto/`.
- `hdev_winter_test_v1.py` and `hdev_winter_test_v2.py`

**Other:**
- `code-snapshot-2026-10-12.md`: the 12 Oct code bundle, including the thesis charging env, EDF/ES allocators and the DMI draft.

## claude-repo-copies/ (taken from `mohgsaad-art/hdev` main, commit cbe39e1)

The project held copies of these files, and they were removed from the project. These copies come from the repo.

Three repo files were compared byte-for-byte with project copies (two 22 Oct–7 Nov closeouts and the 11-03 closeout), and all matched. The files below were not compared one by one.

- 10-06, 10-07/08 crosswind-payload, 10-08 P_aux and 10-08 payload-force closeouts (`docs/decisions/`). The 10-08 P_aux file holds the full VECTO BEV aux trace and tables.
- `hdev_maps_test_v1.py`, `hdev_maps_test_v2.py` and `hdev_addon_std_drag_v1.py`
- `kiro-prompt-drag-default-test-2026-11-03.md` and `kiro-prompt-eea-truck-validation-2026-11-07.md` (v1)
