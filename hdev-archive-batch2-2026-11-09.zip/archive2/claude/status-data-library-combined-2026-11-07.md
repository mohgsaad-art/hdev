# Data library: combined status after Kiro passes, 7 Nov 2026

Checked by Claude against `mohgsaad-art/hdev` main (commit after merge of PR #19, 7 Nov 01:23). Kiro outputs can be wrong; items below are either re-checked by Claude from repo files (marked CHECKED) or still Kiro-only.

## What is in the repo (docs/research/)
- PDFs: eEconic sheet, Liebherr ETM, Carrier eCool, Volvo 2BATT170, BEV_BATTERY (Volvo ESS), BEK 1415/2023 (B20230141505), BEK 1447/2025 (DG1229), COM(2025)589, ISO FDIS 24162, EEA metadata 22fd286c (RP 2019–2023).
- XLSX: HDV table definition (RP 2019–2023), cars/vans 2025 provisional table definitions.
- CSV: `hdv_2024_battery`, `hdv_2024_voltagelevel_electricmachine`, `hdv_2024_voltagelevel_iepc`, `hdv_2024_derogation`, `hdv_zev_2019_2023` (44,107 rows × 461), `my_zev_configs` (6,135 configs).
- Peeks (7 Nov): `eea-hdv-2024-peeks/` — vehicle, battery, voltagelevel_*, steeringpumptechnology, enginetorquelimit, derogation, plus `peek_drive_csv.py`.
- Kiro deliverables: `data-library-sources-2026-11/`, `data-library-chargers-2026-11/`, `charger-hardware-sources-2026-11/`.
- NOT in repo (any branch): pass-1/pass-2 reports, Gemini text, manual-fetch-list, findings-eea, knowledge-base markdown incl. Danish tender/concession/SLA docs; EEA RP 2024–25 `electricmachine`, `iepc`, `capacitor`, `transfer`, READ_ME, metadata XML. The full `vehicle` table (2 GB) stays on Bob's Drive.

## Claude's own checks of the CSVs (CHECKED)
- `hdv_2024_battery`: 35,021 rows = one row per battery pack/string; 8,024 Pk_Vehicle / 8,020 Vehicle_id. All units kWh. MinVoltage/MaxVoltage/Capacitance 100 % null; CertificationNumber 34 % null. Methods: 31,611 rows Standard values, 3,410 Measured.
- 846 vehicles have a single 1 kWh / 49 V "Measured" entry, and 846 rows in the e-machine table are 24/25 kW. [INFERENCE] these are likely hybrids (48 V), not BEVs. So "8,020 BEV configs" (Kiro) is too high; exclude these until the `vehicle` table confirms powertrain type.
- Usable/installed per pack clusters at ~0.855 for both Standard and Measured (e.g. 90→77, 69→59, 88→75, 94→81, 214→183 kWh). Kiro's "Measured median 1.0" is an artefact of the 1 kWh rows. Some Standard-value rows are far lower (e.g. 31→4 kWh, 81→59, 93→66); not explained.
- `TotalUsableCapacityInSimulation` is a VECTO simulation value, not the OEM's declared usable. Example: Volvo ESS sheet says 540 installed → 380 max usable (6 × 90 kWh packs); the EEA table's most common pack is 90 → 77 kWh (would be 462 for 6 packs). [INFERENCE] pack fingerprint only; cannot attribute to Volvo until joined to `vehicle`. The library needs three separate fields: installed, VECTO-simulation usable, OEM-declared usable.
- No join from battery/e-machine tables to make/model via `hdv_zev_2019_2023` (zero matches on OEM_PK_Vehicle, MS_PK_Vehicle, MS_CryptHashManufacturerRecord) or `my_zev_configs` (no IDs). Derogation IDs (123) are not in the battery table.
- `voltagelevel_electricmachine`: 8,106 rows, 4,157 vehicles, 2,538 exact duplicate rows, Voltage 49 % null, MaxContinuousPower only (no peak, torque, maps). `voltagelevel_iepc`: 15,249 rows, 4,572 vehicles, 7,090 duplicates, Voltage 12 % null; most common 440 kW.
- `my_zev_configs`: 18,731 registrations; makes need normalising ("Mercedes Benz" vs "Mercedes-Benz"). OffVehicleChargingMaxPower 100 % null, SumNetPower 96 % null, PEVArchitecture 54 % null, gears 56 % null. Derived from Bob's 139-column file = RP 2024–25 `vehicle` table (see update below).
- `hdv_zev_2019_2023`: 44,107 rows; OEM_ZeroEmissionVehicle = Yes only 3,221; MS_Electric = Yes 42,634; 82 rows are OEM "Diesel CI" but MS_Electric = Yes (registry/OEM inconsistency).
- BEK check: BEK 1447/2025 §21 stk. 2 nr. 1 = 20,000 kg two-axle lorry, no ZEV line. Kiro missed: three-axle twin-tyre limit also went 26,000 kg + up to 2,000 kg ZEV (BEK 1415/2023 nr. 5 and 7) → 28,000 kg with no ZEV line (BEK 1447/2025 nr. 3). Read from PDF text extraction; verify on retsinformation.dk.

## Update 7 Nov 01:45: peeks of EEA RP 2024–25 tables (Bob's Colab)
- `hdv_2024_vehicle`: 1,999.5 MB, ~1,767,622 rows, 139 columns. Same column set as Bob's 139-column Drive file → that file IS the RP 2024–25 `vehicle` table (EEA, CC-BY 4.0 per catalogue). Settles open question 2.
- It has `Vehicle_id` (0x… hash, same format as `battery` and `voltagelevel_*`) plus Make/Model → join key exists. [INFERENCE] until a test join is run; `Pk_Vehicle` mixes GUIDs and integers, so join on `Vehicle_id`.
- Data quirks seen in 10 sample rows: TPMLM unit mixes kg (18000.00) and t (20.50); boolean flags mix true/false and 1/0; many fields are the text "NULL". Needs normalising in the parser.
- `hdv_2024_enginetorquelimit` ("the torque CSV"): 81.6 MB, ~726,692 rows; columns Vehicle_id, Pk_Vehicle, Gear, Unit (%), EngineTorqueLimit. Combustion-engine torque limit per gear in % — not e-motor torque. Not useful for the BEV library.
- `hdv_2024_steeringpumptechnology`: ~1,770,767 rows; technology label only (e.g. Fixed displacement), no W.
- No torque, peak power or maps in any 2024 table peeked so far.
- Not yet peeked: `electricmachine` (362 KB), `iepc` (311 KB), `capacitor`, `transfer`, READ_ME, metadata XML.
- Next: test join vehicle ↔ battery ↔ voltagelevel on Vehicle_id, split ZEV/HEV, count per make/model.

## Kiro errors / weak points found
- Charger `tariffs_dk.csv`: elafgift "general base rate 0.008 DKK/kWh effective 2021-01-01, [V]" contradicts its own next row (cut to 0.8 øre for 2026–27 from ~72.7 øre). One of them is wrong; needs skat.dk satser.
- Charger `costs_extracted.csv`: US installer estimates (USD) carry `source_id = cowi_eltruck_calc`. Wrong attribution; those are secondary web sources.
- Elindsigt tariffs are household (C-customer) examples, not depot (A/B) tariffs. Not usable for truck depots.
- Vehicle pass: DAF torque from web text, MAN NMC from press, eActros 600 from searches, Volvo "460 kWh = 2026 Aero" from trade press: all [C], not [V].
- Charger pass: IEC 61851-23-3:2026 publication, Milence country prices (single capture, incl. "0.399 GBP" UK), AFIR article numbers: unverified.
- Kiro rebuilt the charger `catalogue.csv` by re-entering rows; spot-check needed.

## Still blocking
1. Test join of `vehicle` (Bob's Drive, 2 GB) with battery / voltagelevel tables on Vehicle_id.
2. EEA `electricmachine`, `iepc`, READ_ME and metadata XML (column definitions, units, whether usable = SoC window).
3. Danish tender/concession/SLA documents in the repo for the charger pass.
4. Current DSO takstblade (Radius, Cerius, N1, TREFOR, Konstant) and skat.dk elafgift satser.
