# HDEV session close-out: PTO engine, P_aux update, driver model rewrite (21 Oct 2026)

Hand-over for a new chat. Tags:

- **[VECTO]**: read directly from VECTO source/resource files in Bob's repo `mohgsaad-art/VECTO` (file and lines named).
- **[DECIDED]**: Bob agreed in this session.
- **[ASSUMPTION]**: HDEV choice with no VECTO/authentic source. Must be flagged in reports.
- **[SIMPLIFICATION]**: deliberate simplification, flagged in reports.
- **[OPEN]**: not resolved.

Previous close-outs: `claude/session-closeout-2026-10-19-paux-hvac.md`, `claude/session-closeout-2026-10-08-paux.md`, `claude/session-closeout-2026-10-08-payload-force.md`, `claude/code-snapshot-2026-10-12.md`.

---

## 1. Status of functions

| Function | Status |
|---|---|
| `crosswind_engine` | done (height-grid issue still open, see 7) |
| `payload_engine` | done |
| `force_engine` | done, **no change needed** for the new driver model (checked) |
| `P_aux` | done, one bug fix (see 3) |
| `SP_power_helper` | done (now returns mechanical W; ×0.7 happens in `P_aux` via `SP_alteff`) |
| `HVAC_thermal`, `ssm_total_w`, `climate_lookup` | done (20 Oct) |
| `pto_engine` | **done this session** |
| `driver_model` + helpers `interp1`, `decel_distance`, `coast_distance` | **rewritten this session, tested** |
| Parser (`defaults.py`) | to do (list in 6) |
| Consumption engine | **next** |

---

## 2. PTO

### 2.1 What VECTO does [VECTO]
- One PTO profile per vehicle (`.vptoel` for BEV: time + electric power in kW). Runs at every stop with `<PTO>` = 1 in the `.vdri` (`DrivingCycleData.cs` line 309). `MunicipalUtility.vdri`: 96 of 103 stops flagged, all with stop = 2 s.
- **Standing time = stop time + PTO duration** (`DistanceBasedDrivingCycle.cs` lines 218–220, 376–378). Duration = last time − first time of the profile (`PTOCycleController.cs`, `EPTOCycleController`) → refuse: 23 s → standing 25 s.
- **PTO sits in the middle of the stop**: stop/2 before, profile, stop/2 after (3-phase ≤ 6 s, lines 264–279; 7-phase longer, lines 281–304, `TargetTimeInterval` 0.5 s).
- BEV uses the same logic via `EPTOCycleController` (`PowertrainBuilderBase.cs` lines 242–249, 486).
- Power is held from each row until the next row (`EPTO.cs` line 32, `LeftSample`); last row's power never used.
- Refuse energy per stop: rows t = 0–22, 1 s each = 539.74 kJ = **0.14993 kWh** (confirmed; the 0.1524 kWh trapezoid value is wrong).

### 2.2 Decisions [DECIDED]
- Default = VECTO: standing time = stop + PTO duration, done in the **parser before the driver model**.
- Route-level option "use stop time as PTO time": standing time = max(stop, PTO duration). [ASSUMPTION] non-VECTO, flagged.
- PTO in the **middle** of the stop, `floor` for odd seconds [ASSUMPTION].
- **Power profile, not constant W.** Input = two lists `pto_t`, `pto_w` (Bob's idea: same lists cover VECTO profile, constant PTO as 2 rows, custom). One profile per vehicle, kept outside the stop table.
- Stop table stays one row per stop: `stop`, `pto_on` (1/0), `payload`. 1 s expansion happens only in the consumption engine.
- Same PTO power at every stop. Per-stop "repeats" column parked for later (`pto_on` 0/1 is its special case).
- Profile times must be whole seconds for now (parser check), `pto_1s` built with `np.repeat`. **Future: per-second averaging for fractional times** (3-line `np.interp` cumulative-energy method, tested: keeps energy exact).
- **Always-on PTO does NOT go through `pto_engine`** — it is a term in `P_aux` (`PTO_always_on`, eff 1.0).
- Input checks (lengths, increasing times, whole seconds, no negative W, `is_on` length) live in the **parser**, not the engine (19 Oct validation split).

### 2.3 `pto_engine` (final, Bob's version)
```python
#PTO engine
def pto_engine(stop, is_on, pto_t, pto_w):

  stop = np.asarray(stop, dtype=float) # stop time of every waypoint/row in s, 0 means no stop; FINAL standing time incl. PTO usage time
  pto_t = np.asarray(pto_t, dtype=float) #pto time profile
  pto_w = np.asarray(pto_w, dtype=float) #pto power profile

  is_stop = stop > 0 # true where the vehicle stops
  is_stop[0] = False # first row is the depot start, its dwell is not a pto change
  n_stops = int(is_stop.sum()) # number of stops where pto can run

  pto_dur = pto_t[-1] - pto_t[0] if len(pto_t) > 0 else 0.0 # PTO length in s; last row is only the end marker (VECTO EPTOCycleController)

  pto_1s = np.repeat(pto_w[:-1], np.diff(pto_t).astype(int)) # each row's W held for its whole seconds, like VECTO (EPTO.cs uses the left row); times must be whole seconds (parser check); TODO: per-second averaging for fractional times

  pto_on = np.broadcast_to(np.asarray(is_on, dtype=float), (n_stops,)) # one 1/0 per stop; a single value means all stops; wrong length raises an error
  pto_on_col = np.full(len(stop), np.nan) # blank column, same length as waypoints
  pto_on_col[is_stop] = pto_on            # written on stop rows only, no start row (PTO doesn't carry over)

  pto_start_col = np.full(len(stop), np.nan) # blank column, same length as waypoints
  pto_start_col[is_stop] = np.where(pto_on > 0, np.floor((stop[is_stop] - pto_dur) / 2), np.nan) # s after stopping when PTO begins; middle of stop like VECTO (DistanceBasedDrivingCycle.cs 264-304); floor for odd seconds = HDEV assumption; NaN where PTO is off

  return pto_1s, pto_on_col, pto_start_col
```
Tests: refuse profile → 23 values, 0.14993 kWh; standing 25 s → start 1 s (= VECTO 1 / 23 / 1); 60 s → start 18; PTO off → NaN; empty profile → empty `pto_1s`, no error; no stops → all NaN.

Consumption engine use: for each stop with `pto_on` = 1, the v = 0 rows at that stop's distance get `pto_1s` starting `pto_start` rows in. PTO duration = `len(pto_1s)`.

---

## 3. P_aux (current, with fix)

Bob's current code has `SP_alteff=0.7` in the signature but `SP_eff` in the `effs` line → `NameError`. **Fix: use `SP_alteff` in `effs`.** 0.7 is correct now because `SP_power_helper` returns mechanical W.

```python
##5.1 Electrical system
def P_aux(ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on, ES_alteff=0.7, PS_alteff=1.0, HVAC_eff=1.25, SP_alteff=0.7, cond_eff=1.0, PTO_eff=1.0):
  # pure: electric W per aux = input W * efficiency factor
  # works for one number or an array using numpy
  # PTO_always_on = always-on PTO only (chiller, mixer); stop PTO comes from pto_engine and is laid on rows in the consumption engine

  powers = [np.asarray(p, dtype=float) for p in (ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on)]
  effs = (ES_alteff, PS_alteff, HVAC_eff, SP_alteff, cond_eff, PTO_eff)

  for p in powers:
      if np.any(p < 0):
          raise ValueError("aux power cannot be negative")
  for e in effs:
      if e <= 0:
          raise ValueError("efficiency must be > 0")

  ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on = (p * e for p, e in zip(powers, effs))

  return ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on
```
[OPEN] Does always-on PTO also switch Cond on at stops? VECTO Cond is on when motor or e-PTO runs (`Conditioning.cs`); VECTO has no always-on PTO → HDEV rule needed.

---

## 4. Driver model

### 4.1 VECTO research [VECTO]
- BEV uses `DefaultDriverStrategy` (`PowertrainBuilder.cs` line 841).
- Declaration driver settings (`DeclarationData.cs` 718–822, `DriverDataAdapter.cs`): look-ahead coasting **on** (min 50 km/h, distance factor 10, decision factor 2.5 − 1.5·f(v_target)·f(v_drop) from `LAC-DF-Vtarget.csv` / `LAC-DF-Vdrop.csv`); overspeed **on** (+2.5 km/h above 50 km/h); eco-roll / PCC only if declared.
- Braking distance: exact per `.vacc` segment (`AccelerationCurve.cs` `ComputeAccelerationSegmentDistance`), safety margin 0.1 m (`DefaultDriverStrategy.cs` line 62).
- Look-ahead distance = max(2·ds, 10 × v[km/h], 1.2 × stop distance + ds) (lines 647–683).
- Coasting distance = ΔE / (DF × (air + rolling + drag losses/v)) (lines 721–756); energy uses mass + wheel inertia, rolling uses mass only; air drag = VECTO average `(v1+v2)(v1²+v2²)/8` with CdxA at average speed. **Depends on mass and drag.**
- Altitude: `alt += ds × previous grade / 100` (`DrivingCycleDataReader.cs` line 236); step slope = atan(Δalt/ds) (`DistanceBasedDrivingCycle.cs` 417–420).
- After a stop, target = next waypoint's target (`DrivingCycleDataReader.cs` 246–253). Cycle starting at 0 km/h without stop gets 1 s stop (line 221).
- `.vacc` lookup extrapolates beyond the table (`AccelerationCurve.cs` 77–90); `np.interp`/`interp1` hold the edge — identical for `Truck.vacc`.
- Air density 1.188 kg/m³ (`DeclarationData.cs` line 74). Declaration wind 3 m/s at 4 m, Hellmann 0.2 (`Physics.cs` 56–66). CdxA table 60–130 km/h step 5, below 60 = 60 value; **CdxA_eff = CdxA0 × W1 + W2** (`AirdragDataAdapter.cs` 59–87); no 10° yaw clamp in VECTO declaration.
- Share of distance with target > 50 km/h (where coasting can act): Long haul 99.9 %, Regional 94.0 %, Construction 79.3 %, Municipal 60.5 %, Urban delivery 45.7 %, Urban 13.6 %, Heavy urban 4.9 %.

### 4.2 Decisions [DECIDED]
- Full rewrite, simple, robust, fast. Balance: VECTO kinematic parts **plus** look-ahead coasting and overspeed at **one fixed reference vehicle** so the driver model still runs once per vehicle (Bob's fixed-mass idea; default = VECTO reference mass, not max permissible weight, because heavier mass coasts further).
- `coast_mass=None` → kinematic only (coasting/overspeed-roll off).
- Coasting/overspeed use fixed reference CdxA table (crosswind engine at VECTO declaration wind, `beta_limit_deg=None`), ρ = 1.188, no wind. Weather ρ(T) and DMI CdxA stay in the consumption engine.
- Motor drag loss `P_drag_loss` default 0 [ASSUMPTION], `P_max` cap optional (`None`).
- `.vacc` reading = parser; lookup at current speed = inside the loop (no `vacc_lookup` helper). Altitude = inside `driver_model` (no helper).
- VECTO driver constants are arguments with VECTO defaults (explained in 4.4). Could move to one `vecto_driver` dict filled by the parser if Bob prefers.
- **Bob wants `interp1`, `decel_distance`, `coast_distance` and `driver_model` explained to him later.**

### 4.3 Code (tested)
```python
import math, bisect
import numpy as np


# helper: linear interpolation for ONE number, holds end values like np.interp, but much faster inside a loop
def interp1(x, xs, ys):
  if x <= xs[0]:
      return ys[0]
  if x >= xs[-1]:
      return ys[-1]
  i = bisect.bisect_right(xs, x)                                  # first table point above x
  return ys[i-1] + (ys[i] - ys[i-1]) * (x - xs[i-1]) / (xs[i] - xs[i-1])


# helper: braking distance v_from -> v_to on the .vacc deceleration curve, exact per segment
# VECTO AccelerationCurve.ComputeDecelerationDistance / ComputeAccelerationSegmentDistance; speeds and vacc_v in m/s, vacc_dec negative
def decel_distance(v_from, v_to, vacc_v, vacc_dec):
  if v_to >= v_from:
      return 0.0
  dist = 0.0
  for i in range(1, len(vacc_v)):
      v_lo, v_hi = vacc_v[i-1], vacc_v[i]
      a_lo, a_hi = vacc_dec[i-1], vacc_dec[i]
      v1 = min(v_from, v_hi)
      v2 = max(v_to, v_lo)
      if v2 >= v1:
          continue
      if math.isclose(a_lo, a_hi):
          dist += (v1**2 - v2**2) / (2 * -a_lo)
      else:
          k = (a_lo - a_hi) / (v_lo - v_hi)
          d = a_lo - k * v_lo
          t = math.log((v2*k + d) / (v1*k + d)) / k
          m = v1 + d / k
          dist += m / k * math.exp(k * t) - d / k * t - m / k
  return dist


# helper: look-ahead coasting distance, VECTO DefaultDriverStrategy.ComputeCoastingDistance (lines 721-756)
# speeds m/s; cdxa_v in m/s; df tables in km/h like the VECTO csv files
def coast_distance(v, v_target, h_now, h_target, s_now, s_target,
                   coast_mass, m_red_wheels, cdxa_v, cdxa, Crr, rho, g, P_drag_loss,
                   df_offset, df_scaling, df_vtarget, df_vdrop):
  m_eff = coast_mass + m_red_wheels
  dE = m_eff * g * (h_now - h_target) + m_eff * (v**2 - v_target**2) / 2
  v_avg = (v + v_target) / 2
  cda = interp1(v_avg, cdxa_v, cdxa)
  F_air = rho / 8 * cda * (v + v_target) * (v**2 + v_target**2) / v_avg
  grad = (h_target - h_now) / (s_target - s_now)
  F_roll = math.cos(grad) * coast_mass * g * Crr
  F_loss = P_drag_loss / v
  f_vt = interp1(v_target * 3.6, df_vtarget[0], df_vtarget[1])
  f_vd = interp1((v - v_target) * 3.6, df_vdrop[0], df_vdrop[1])
  DF = df_offset - df_scaling * f_vt * f_vd
  return dE / (DF * (F_air + F_roll + F_loss))


# driver model: VECTO DefaultDriverStrategy on fixed 1 s rows (HDEV deviation: VECTO uses ~0.5 s variable steps)
# pure kinematics when coast_mass is None; with coast_mass: look-ahead coasting + overspeed at a FIXED reference vehicle (HDEV assumption)
def driver_model(wp_s, wp_v, wp_stop, wp_grade,
                 vacc_v, vacc_acc, vacc_dec, dt=1.0,
                 coast_mass=None, m_red_wheels=0.0, cdxa_v=None, cdxa=None, Crr=None, rho=1.188, g=9.81,
                 P_drag_loss=0.0, P_max=None,
                 lac_min_v=50.0, lac_dist_factor=10.0, df_offset=2.5, df_scaling=1.5,
                 df_vtarget=((0, 48, 52, 100), (0, 0, 1, 1)), df_vdrop=((-100, 9, 11, 100), (1, 1, 0, 0)),
                 os_min_v=50.0, os_allowed=2.5, brake_margin=0.1, v_min_coast=5.0):

  # ---------- A. once, before the loop ----------
  s_wp = [float(x) for x in wp_s]                      # waypoint distance [m]
  v_wp = [float(x) / 3.6 for x in wp_v]                # waypoint target speed [m/s]
  stop_wp = [float(x) for x in wp_stop]                # FINAL standing time [s] (PTO already added by the parser)
  gr_wp = np.asarray(wp_grade, dtype=float)            # waypoint grade [%]
  n = len(s_wp)

  rise = np.diff(np.asarray(s_wp)) * gr_wp[:-1] / 100  # altitude per waypoint, VECTO DrivingCycleDataReader.cs line 236
  alt_wp = np.concatenate(([0.0], np.cumsum(rise)))
  alt_l = alt_wp.tolist()
  gr_l = gr_wp.tolist()

  if v_wp[0] == 0 and stop_wp[0] == 0:                 # VECTO line 221: cycle starting at 0 km/h without stop gets a 1 s stop
      stop_wp[0] = 1.0

  # speed the driver aims for after passing waypoint i; after a stop it is the next waypoint's target (VECTO line 246-253)
  # (HDEV: if several stops follow each other, take the next POSITIVE target, so the truck never gets stuck at 0 km/h)
  seg_v = [0.0] * n
  nxt = 0.0
  for i in range(n - 1, -1, -1):
      seg_v[i] = v_wp[i] if v_wp[i] > 0 else nxt
      if v_wp[i] > 0:
          nxt = v_wp[i]
  # change points: only waypoints whose target differs from the segment before can trigger braking/coasting
  chg = [i for i in range(1, n) if v_wp[i] != seg_v[i-1]]
  chg_s = [s_wp[i] for i in chg]

  vv = [x / 3.6 for x in vacc_v]                       # .vacc speeds in m/s
  va = [float(x) for x in vacc_acc]
  vd = [float(x) for x in vacc_dec]

  coast_on = coast_mass is not None
  if coast_on:
      if cdxa_v is None or cdxa is None or Crr is None:
          raise ValueError("coasting needs cdxa_v, cdxa and Crr")  # guard only; parser gives friendly message
      m_eff = coast_mass + m_red_wheels                # mass incl. rotating wheels
      cv = [x / 3.6 for x in cdxa_v]                   # reference CdxA table speeds in m/s
      cc = [float(x) for x in cdxa]

  lac_min = lac_min_v / 3.6
  os_min = os_min_v / 3.6
  os_add = os_allowed / 3.6
  v_min_c = v_min_coast / 3.6                          # VECTO MinVelocityForCoast 5 km/h (Constants.cs line 301)

  def coast_acc(v, k):                                 # acceleration with no motor torque at speed v on segment k [m/s²]
      th = math.atan(gr_l[k] / 100)
      F = (rho / 2 * interp1(v, cv, cc) * v * v       # air drag, instantaneous (HDEV: VECTO uses the step average)
           + coast_mass * g * Crr * math.cos(th)       # rolling resistance, mass without wheel inertia like VECTO
           + coast_mass * g * math.sin(th)             # slope force
           + (P_drag_loss / v if v > 0 else 0.0))      # motor/gearbox drag while rolling
      return -F / m_eff

  T, S, V, A, M = [], [], [], [], []                   # rows: time, distance, speed, acceleration, mode
  t = 0.0
  s = s_wp[0]
  v = v_wp[0]                                          # VECTO starts at the first waypoint's target speed (DistanceBasedDrivingCycle.cs line 107)
  s_end = s_wp[-1]

  def add_stop(i, t):                                  # standing rows at waypoint i
      for _ in range(int(round(stop_wp[i] / dt))):
          T.append(t); S.append(s_wp[i]); V.append(0.0); A.append(0.0); M.append(0)
          t += dt
      return t

  if v_wp[0] == 0:                                     # depot start stop
      t = add_stop(0, t)
      v = 0.0

  trig = None                                          # active slowdown: [index, trigger distance, target speed, coasting allowed, braking started]
  max_steps = int(sum(stop_wp) / dt + (s_end - s_wp[0]) / 0.5 + 10000)  # guard against endless loops (truck must average > 0.5 m/s)

  # ---------- B. each 1 s step ----------
  for _ in range(max_steps):
      if s >= s_end - 1e-6:
          break
      k = bisect.bisect_right(s_wp, s) - 1             # waypoint segment we are in
      target = seg_v[k]
      v_os = target + os_add if target > os_min else target  # overspeed limit (VECTO IsOverspeedAllowed: > 50 km/h, +2.5 km/h)

      if trig is not None and s >= trig[1] - 1e-6:     # slowdown point passed
          trig = None

      # look ahead (VECTO GetNextDrivingAction, lines 647-683)
      look = max(2 * v * dt, v * 3.6 * lac_dist_factor, 1.2 * decel_distance(v, 0.0, vv, vd) + v * dt)
      j0 = bisect.bisect_right(chg_s, s)
      j1 = bisect.bisect_right(chg_s, s + look)
      best_b = None                                    # candidate with the earliest braking start
      best_c = None                                    # candidate with the earliest coasting start
      for j in range(j0, j1):
          i = chg[j]
          vt = v_wp[i] + os_add if v_wp[i] > os_min else v_wp[i]  # target incl. overspeed (VECTO line 662)
          if vt >= v:
              continue
          b_start = s_wp[i] - (decel_distance(v, vt, vv, vd) + brake_margin)
          c_start = b_start
          if coast_on and v > lac_min:
              cd = coast_distance(v, vt, interp1(s, s_wp, alt_l), alt_l[i], s, s_wp[i],
                                  coast_mass, m_red_wheels, cv, cc, Crr, rho, g, P_drag_loss,
                                  df_offset, df_scaling, df_vtarget, df_vdrop)
              if cd > 0:
                  c_start = s_wp[i] - cd
          if best_b is None or b_start < best_b[1]:
              best_b = (i, b_start, c_start, vt)
          if best_c is None or c_start < best_c[2]:
              best_c = (i, b_start, c_start, vt)
      action = None
      if best_b is not None:                           # VECTO: braking action, unless the earliest coasting one is the same point
          i, b_start, c_start, vt = best_b
          coast_ok = best_c[0] == i and c_start < b_start
          action = (i, s_wp[i], vt, coast_ok, min(b_start, c_start))

      if trig is None and action is not None and s + v * dt >= action[4]:  # start slowing down if the next step would pass the start point (HDEV: VECTO shortens the step to land on it)
          trig = [action[0], action[1], action[2], action[3], False]
      elif trig is not None and action is not None and action[1] != trig[1]:
          b_new = action[1] - (decel_distance(v, action[2], vv, vd) + brake_margin)
          b_cur = trig[1] - (decel_distance(v, trig[2], vv, vd) + brake_margin)
          if b_new < b_cur:                            # a nearer slowdown needs earlier braking (VECTO CheckSwitchingToBraking)
              trig = [action[0], action[1], action[2], False, True]

      # ---------- choose acceleration ----------
      acc_max = interp1(v, vv, va)
      dec_max = interp1(v, vv, vd)
      if trig is not None:
          i_t, s_t, v_t, coast_ok, braking = trig
          b_start = s_t - (decel_distance(v, v_t, vv, vd) + brake_margin)
          if 0 < v <= v_t:                             # next target already reached: drive along at it (VECTO TargetSpeedReachedDriveAlong)
              a = max(dec_max, min(acc_max, (v_t - v) / dt)); mode = 2
          elif coast_on and coast_ok and not braking and s + v * dt < b_start and v >= v_min_c:  # whole step still before braking start
              a = coast_acc(v, k)                      # look-ahead coasting
              a = min(a, (max(target, v) - v) / dt)    # VECTO DoCoast: never faster than max(target, current speed)
              a = max(a, dec_max); mode = 3            # coasting harder than the driver's max deceleration -> limited (VECTO Underload -> brake)
          elif not braking and s < b_start:            # braking starts inside this step: brake only for the part of the step after b_start
              frac = (s + v * dt - b_start) / (v * dt) if v > 0 else 1.0
              a = dec_max * min(max(frac, 0.0), 1.0); mode = 4  # HDEV: VECTO shortens the step to start braking exactly at b_start
              trig[4] = True                           # once braking, stay braking until the point (VECTO BrakingPhase.Brake)
          else:
              rem = s_t - s
              if rem < 2 * v * dt and v > v_t:         # last one or two steps: land on v_t at the point (VECTO AdaptDecelerationToTargetDistance)
                  a = (v_t**2 - v**2) / (2 * rem) if rem > 1e-6 else dec_max
              else:
                  a = max(dec_max, (v_t - v) / dt)     # brake along the .vacc deceleration curve, never below the next target (VECTO DoBrake)
              mode = 4
              trig[4] = True
      else:
          if v < target - 1e-9:                        # accelerate
              a = min(acc_max, (target - v) / dt)
              if P_max is not None and coast_on:       # optional motor power cap (HDEV simplification, not VECTO's motor search)
                  F_res = -coast_acc(v, k) * m_eff
                  a = min(a, (P_max / max(v, 1.0) - F_res) / m_eff)
              if action is not None:                   # don't speed up so much that the next slowdown can't be braked for in time
                  room = action[1] - s - v * dt - brake_margin   # distance left after this step (HDEV: stands in for VECTO's CheckRequestDoesNotExceedNextAction)
                  v_cap = math.sqrt(max(action[2]**2 + 2 * -dec_max * max(room, 0.0), 0.0))
                  a = max(min(a, (v_cap - v) / dt), 0.0)
              mode = 1
          elif coast_on and target > os_min:           # at/above target with overspeed allowed: roll (VECTO FirstAccelerateOrCoast)
              ca = coast_acc(v, k)
              if ca >= 0:
                  a = max(dec_max, min(ca, (v_os - v) / dt)); mode = 3   # downhill: let it run up to target + 2.5 km/h, then hold
              elif v + ca * dt > target:
                  a = ca; mode = 3                     # roll back down towards target
              else:
                  a = (target - v) / dt; mode = 2      # would drop below target -> hold target
          elif v > target + 1e-9:
              a = max(dec_max, (target - v) / dt); mode = 4  # above target without overspeed -> brake to target
          else:
              a = 0.0; mode = 2                        # cruise

      # ---------- move one step ----------
      v_new = v + a * dt
      if v_new < 0:                                    # would stop inside the step
          ds = v * v / (2 * -a) if a < 0 else 0.0
          v_new = 0.0
      else:
          ds = (v + v_new) / 2 * dt
      if trig is not None and trig[2] == 0 and (v_new <= 0 or s + ds >= trig[1]):
          ds = max(trig[1] - s, 0.0)                   # arrive exactly at the stop (HDEV: VECTO shortens the step instead)
          v_new = 0.0
      T.append(t); S.append(s); V.append(v); A.append((v_new - v) / dt); M.append(mode)
      t += dt
      s += ds
      v = v_new

      if trig is not None and trig[2] == 0 and v == 0:  # arrived at a stop
          s = trig[1]
          t = add_stop(trig[0], t)
          trig = None
  else:
      raise RuntimeError("driver_model did not reach the end of the route")  # guard only

  # ---------- C. after the loop: arrays + grade from altitude ----------
  T = np.asarray(T); S = np.asarray(S); V = np.asarray(V); A = np.asarray(A); M = np.asarray(M, dtype=int)
  s_next = np.append(S[1:], s)                         # distance at the end of each row
  ds_row = s_next - S
  h1 = np.interp(S, s_wp, alt_wp)
  h2 = np.interp(s_next, s_wp, alt_wp)
  k_row = np.searchsorted(s_wp, S, side="right") - 1
  grade = np.where(ds_row > 1e-9, (h2 - h1) / np.where(ds_row > 1e-9, ds_row, 1.0) * 100, gr_wp[k_row])  # [%]; standing rows use the waypoint grade
  return T, S, V, A, grade, M
```

**Returns** numpy arrays per 1 s row: `T` cumulative time [s], `S` cumulative distance [m], `V` speed at row start [m/s], `A` acceleration [m/s²] (exactly `(V_next − V)/dt`), `grade` [%] (from altitude; standing rows use waypoint grade), `M` mode (0 stop, 1 accelerate, 2 cruise, 3 coast, 4 brake).

### 4.4 The VECTO driver constants (arguments)
| Argument | Meaning | VECTO source |
|---|---|---|
| `lac_min_v=50` | coasting only above 50 km/h | `DeclarationData.Driver.LookAhead.MinimumSpeed` |
| `lac_dist_factor=10` | look-ahead = 10 × speed in km/h, in m | `LookAheadDistanceFactor` |
| `df_offset=2.5`, `df_scaling=1.5` | decision factor between 2.5 (let off late) and 1 (early) | `DecisionFactorCoastingOffset/Scaling` |
| `df_vtarget` | coasting counts only if the slowed-to speed is above ~50 km/h | `LAC-DF-Vtarget.csv` |
| `df_vdrop` | small drops (< ~10 km/h) → let off earlier | `LAC-DF-Vdrop.csv` |
| `os_min_v=50`, `os_allowed=2.5` | overspeed +2.5 km/h above 50 km/h | `DeclarationData.Driver.OverSpeed` |
| `brake_margin=0.1` | start braking 0.1 m early | `BrakingSafetyMargin` |
| `v_min_coast=5` | no coasting below 5 km/h | `Constants.MinVelocityForCoast` |

### 4.5 Tests (all 10 VECTO declaration cycles, `Truck.vacc`; coasting runs used ILLUSTRATIVE values only: 30 t, flat CdxA 6 m², Crr 0.005)
- Reaches route end; every stop has full standing time; speed never above target + 2.5 km/h; acceleration never above `.vacc` (except 6 downhill rolling rows, gravity); speed continuity exact; altitude along rows = cycle altitude exactly.
- Speed: ~0.1 s per 100 km cycle; 300 km day (~40,000 rows) 0.3 s.
- Old bug #1 (stuck at back-to-back stops) fixed; all-zero-speed route raises the guard error (parser should reject).
- **Not yet compared with a real VECTO run** — needs a `.vmod` (v, a, distance per step) from VECTO for a generic BEV on Regional Delivery and Municipal.

### 4.6 HDEV deviations to flag in reports
1. Fixed 1 s rows (VECTO variable ~0.5 s). First braking step split by fraction; final step snapped to stops. Last 1–2 braking steps can be up to ~1.8× `.vacc` deceleration in < 1.5 % of braking rows.
2. Coasting + overspeed at a fixed reference mass/CdxA, no wind (VECTO: simulated mass).
3. Coasting air drag instantaneous (VECTO: step average).
4. Motor drag loss 0, no power cap by default.
5. Back-to-back stops take the next positive target speed.
6. Acceleration capped before slowdowns so braking is still possible (stands in for VECTO `CheckRequestDoesNotExceedNextAction`).

---

## 5. Force engine connection [checked]
```python
T, S, V, A, G, M = driver_model(...)
k_lin, k_roll, k_rot, L, v_avg = force_engine(g, Crr, V, A, dt, G, r_dyn, theta_red)   # dt can be a plain number
```
No change to `force_engine`. Only known mismatch: on each stop-arrival row the driver snaps distance, the force engine assumes `v_avg × dt` → max 0.18 m per stop (Municipal: +9.4 m over 11.24 km, 0.08 %). [SIMPLIFICATION] flagged; exact fix later = return the actual moving time for that row as `dt_s`.

Reference CdxA table for the driver (built once, parser/pre-step):
```python
W1, W2 = crosswind_engine(vehicle_height, v_ref=3.0, h_ref=4.0, ..., v_veh_kmh=speeds, beta_limit_deg=None)
cdxa_ref = CdxA0 * W1[0] + W2[0]   # -> driver_model(cdxa_v=speeds, cdxa=cdxa_ref)
```

---

## 6. Parser to-do list (consolidated)
- Read `.vdri` (s, v, stop, grade, PTO flag) and `.vacc` (latin-1 encoding: header has `²`).
- Stop extension: standing = stop + PTO duration where `pto_on` (default) or max(stop, PTO duration) (option); flag every extended stop.
- PTO checks: `pto_t`/`pto_w` same length, times increasing and whole seconds, no negative W, `is_on` length = number of stops.
- Route checks: at least one positive target speed; stop entries have target 0.
- Reference CdxA table (above); `coast_mass` = VECTO reference mass + `m_red_wheels`.
- ES/PS/SP/HVAC/Cond lookups (19 Oct), missing-COP error.

## 7. Open items
1. Consumption engine (next): mass/payload by distance, weather ρ and CdxA_eff, aux sum, stop PTO on v = 0 rows, always-on PTO, HVAC by hour, wheel → battery power, energy.
2. Compare driver trace and energy with a real VECTO `.vmod`.
3. `crosswind_engine` height-grid issue (~+2.5 % CdxA at h = 4 m) — fix before VECTO comparison.
4. Cond on-rule with always-on PTO; `EmOffPrev` for BEV.
5. Motor drag loss and power cap values when motor data exists.
6. PTO per-second averaging (future); per-stop repeats (future).
7. Explain the four driver functions to Bob.
8. Optional: move VECTO driver constants into one `vecto_driver` dict.

## 8. Next step
Write the consumption engine, then run the whole flow end to end (parser → payload/PTO → driver → force → aux → consumption) on a VECTO cycle.
