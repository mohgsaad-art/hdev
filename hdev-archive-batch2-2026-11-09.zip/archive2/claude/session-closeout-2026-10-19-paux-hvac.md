# HDEV session close-out: P_aux, SP helper, HVAC thermal (16–19 Oct 2026)

Hand-over for a new chat. Tags used:

- **[VECTO]**: read directly from VECTO source or resource files in Bob's repo `mohgsaad-art/VECTO` (release 4.3.4-DEV). File and lines named.
- **[REG]**: Regulation (EU) 2017/2400, from the project knowledge base.
- **[DECIDED]**: Bob agreed in this session.
- **[ASSUMPTION]**: HDEV choice with no VECTO/authentic source. Must be flagged in reports.
- **[SUGGESTION]**: Claude's proposal, not yet agreed.
- **[OPEN]**: not resolved.

Previous close-outs: `claude/session-closeout-2026-10-08-paux.md` (full VECTO BEV aux trace, all tables), `claude/session-closeout-2026-10-08-payload-force.md`, `claude/code-snapshot-2026-10-12.md`.

---

## 0. Answer to the last question: where does `climate_lookup` go?

**Split it in two. Part of it is parser work, part is a small engine helper.**

| Part | Where | Why |
|---|---|---|
| Pick the VECTO columns for the chosen heat-pump type and HD case (5 heating temps + COPs, 3 cooling temps + COPs, 5 share values per heater type, heater efficiency 0.93 / 0.80) | **Parser** (`defaults.py`), before pre-analysis | Pure table lookup by vehicle inputs. No weather. Same as ES/PS/SP lookups. Also where the "missing non-R-744 COP at −20 °C → user must enter one" error is raised. |
| Map each weather hour's temperature onto those points (`np.interp` for COP, nearest heating point for shares) | **Own small function `climate_lookup`**, called inside `HVAC_thermal` | It depends on the weather, so it can't run in the parser. It holds the HDEV gap-fill rule (a deviation from VECTO), so keeping it separate makes it auditable and testable at VECTO's exact 11 points. |

So the parser hands small point arrays → `HVAC_thermal` calls `climate_lookup(T_amb, ...)` → gets per-hour COP and shares → continues with section 2.

**HVAC thermal = 3 functions total:** `ssm_total_w` ✅, `climate_lookup` (next), `HVAC_thermal` (section 1 done).

---

## 1. Repo access

- [DECIDED] Bob's GitHub repo `mohgsaad-art/VECTO` is public. Claude can clone and read it directly (read-only, cannot push). No need to paste VECTO files anymore.

---

## 2. Architecture decisions (this session)

### 2.1 Where aux, payload and PTO meet the rows
- [DECIDED] **Nothing aux-related is written into the driver model.** The driver model stays pure kinematics and runs once (6 Oct precompute rule).
- [DECIDED] **All fill-up onto rows happens in the consumption engine.** Aux values arrive as single numbers (or per-hour arrays for HVAC thermal); numpy broadcasting adds them to every row.
- [DECIDED] **Payload and stop-PTO are also mapped in the consumption engine, by distance.** This supersedes the 8 Oct note "forward-fill as a separate step just before the driver model".
  - `payload_engine` is unchanged: it still writes payload on start + stop waypoints (NaN elsewhere), so the UI can show it before running.
  - Consumption engine: take waypoints where payload is not NaN → (distance, value) pairs → `np.searchsorted` onto the driver rows' cumulative distance = forward fill.
  - Stop PTO rows = rows with v = 0 **and** distance = that stop's distance (small tolerance, not exact `==`).
  - No index column needed (Bob's idea), as long as driver rows carry cumulative distance.
- [OPEN] **Confirm the driver model outputs cumulative distance per row.** Bob to paste the part that builds the output rows if unsure.
- [ASSUMPTION] This only holds while the driver model ignores mass. Real VECTO limits acceleration by available motor power (mass-dependent). HDEV doesn't.
  - [SUGGESTION] Cheap check after consumption: compare each row's wheel power to the motor's max power; flag rows that exceed it in the report. Not yet agreed.
- Driver model rows are 1 s (Bob confirmed). Stops become rows at v = 0.

### 2.2 Consumption-engine aux sum (the target form)
```
P_aux_row = ES + PS + HVAC + SP·[v > 0] + Cond·[motor on] + PTO_row
```
- SP: off when stopped [VECTO `ElectricAuxiliaries.cs`, ID "STP"].
- Cond: on when an electric motor is on or e-PTO is on [VECTO `Conditioning.cs`].
  - [ASSUMPTION] "motor on" approximated as "moving or PTO on" until `EmOffPrev` is traced (driver-model audit).
- HVAC: one number (VECTO mode) or the per-hour thermal value looked up by each row's hour (row clock time = start time + cumulative dt; the weather step needs this anyway).
- PTO_row: from `pto_engine` (always-on W + stop PTO on stop rows).
- P_aux returns **power (W)**, not energy. Energy (× dt) is done once in the consumption sum. Supersedes the 15 Oct `aux_energy` idea.

### 2.3 Function layout for aux
| Aux | Where its W comes from | Function |
|---|---|---|
| ES | parser lookup or custom | straight into `P_aux` |
| PS | parser lookup (`_el` columns) or custom | straight into `P_aux` |
| HVAC | VECTO mode: parser lookup; thermal mode: `HVAC_thermal` | `P_aux` (+ `HVAC_thermal` in thermal mode) |
| SP | `SP_power_helper` (VECTO method) or custom | helper → `P_aux` |
| Cond | parser lookup (`Cond-Table.csv`) or custom; thermal later | `P_aux`; `cond_delta` hook = 0 for now |
| PTO | `pto_engine` (both always-on and at-stops) | own function, not in `P_aux` |

### 2.4 Validation split
- [DECIDED] Full user-facing validation (friendly messages) lives in the parser / FastAPI layer.
- [SUGGESTION, accepted as code] Engine functions keep one-line guards (e.g. `p < 0`, `eff <= 0`) to catch bugs in helpers that never pass the parser (SP helper, HVAC thermal, AI adapter). Bob may delete them; maths unchanged.

### 2.5 Caching
- `P_aux` itself is microseconds; caching it gains nothing. What makes the pipeline cache-friendly: pure functions, no route/weather inside, plain numbers in/out → editing an aux input never reruns the driver model.
- `HVAC_thermal` depends only on cab inputs + weather hours → call it **once for the whole year** (8,760 hourly values in one array). That year table is the cache; reruns only if cab inputs or the weather file change.
- Write everything with numpy so the same line works for a single number or an array.

---

## 3. ES and PS (parser + `P_aux`)

[VECTO] `HeavyLorryAuxiliaryDataAdapter.cs` lines 50, 113–153; `DeclarationData.cs:123` (`AlternatorEfficiency = 0.7`).

| | ES | PS |
|---|---|---|
| User picks | technology dropdown or custom W | technology dropdown or custom W |
| Efficiency field | default 0.7, editable | default 1.0, editable |
| Parser lookup | groups 51–56 → `ES-Tech_Medium.csv`, else `ES-Tech.csv`; key mission × technology | `PS-Table.csv`, `_el` columns, key mission × technology; only "+ elec. driven" rows allowed for BEV (VECTO throws otherwise) |
| Errors | medium lorry + municipal/construction = `---` → user must enter custom | non-electric technology for BEV |
| Mission | through `GetNonEMSMissionType()` first | same |
| On-rule | always on | always on |

- [VECTO] Medium lorry = groups 51–56 (`VehicleClass.cs` lines 198–207). Medium ES values × 0.7: 720 W LH, 600 W RD/UD (standard).
- [REG] AMS = "Air Management System with optimal regeneration" (Annex IX point 2(22)). For electric compressors only Table 9 combinations 8 (none) and 9 (+AMS) exist. Just another dropdown row.
- **Reminder requested by Bob (saved to memory):** when building the aux UI, put a short label next to each efficiency field, e.g. "0.7 = VECTO; set 1.0 if your value is already electric", so a custom electric W isn't × 0.7 by mistake.

---

## 4. Code written this session (current versions)

### 4.1 `P_aux` (main function) — done
```python
def P_aux(ES_power, PS_power, HVAC_power, SP_power, cond_power,
          ES_alteff=0.7, PS_alteff=1.0, HVAC_eff=1.25, SP_eff=1.0, cond_eff=1.0):
  # pure: electric W per aux = input W * efficiency factor
  # works for one number (VECTO mode) or an array (e.g. 24 hourly HVAC values)

  powers = [np.asarray(p, dtype=float) for p in (ES_power, PS_power, HVAC_power, SP_power, cond_power)] # convert first so lists work
  effs = (ES_alteff, PS_alteff, HVAC_eff, SP_eff, cond_eff)

  for p in powers:
      if np.any(p < 0):
          raise ValueError("aux power cannot be negative")
  for e in effs:
      if e <= 0:
          raise ValueError("efficiency must be > 0")

  ES_power, PS_power, HVAC_power, SP_power, cond_power = (p * e for p, e in zip(powers, effs))

  return ES_power, PS_power, HVAC_power, SP_power, cond_power
```
- Efficiency defaults = VECTO BEV: ES 0.7, PS 1.0 (`_el` already electric), HVAC 1.25 (= 1/0.8, `HVACElectricEfficiencyFactor`), SP 1.0 (helper applies 0.7), Cond 1.0 (already electric).
- HVAC thermal mode: pass the thermal W array with `HVAC_eff = 1.0`.
- Test (8 Oct values, group 5 RD): `P_aux(1428.5714, 687, 200, 401.9, 600)` → ES ≈ 1000, PS 687, HVAC 250, SP 401.9, Cond 600; total 2938.9 W = close-out "moving, motor on".

### 4.2 `SP_power_helper` — done, exact VECTO
[VECTO] `SteeringPump.cs` lines 58–114 (`Lookup`), lines 128–148 (SP-Table read, divides by 100), lines 230–250 (SP-Axles read); × 0.7 in `HeavyLorryAuxiliaryDataAdapter`.

```python
##5.x Steering pump helper
# pure: follows VECTO SteeringPump.Lookup (SteeringPump.cs lines 58-114) + x0.7 in HeavyLorryAuxiliaryDataAdapter
# one technology per steered axle, like VECTO; the factors are averaged over the axles (VECTO's method)
# returns electric W, goes into P_aux as SP_power with SP_eff = 1.0

def SP_power_helper(SP_baseline, SP_axle_shares, SP_tech_factors, SP_alteff=0.7):

  SP_baseline = np.asarray(SP_baseline, dtype=float)         # (UF, B, S) in W, from SP-Table.csv
  SP_axle_shares = np.asarray(SP_axle_shares, dtype=float)   # one (UF, B, S) row in % per steered axle, from SP-Axles.csv
  SP_tech_factors = np.asarray(SP_tech_factors, dtype=float) # one (UF, B, S) row per steered axle, from SP-Tech.csv or custom

  if SP_axle_shares.ndim != 2 or SP_axle_shares.shape[1] != 3 or len(SP_axle_shares) == 0:
      raise ValueError("SP_axle_shares needs one (UF, B, S) row per steered axle")
  if SP_tech_factors.shape != SP_axle_shares.shape:
      raise ValueError("need one technology (UF, B, S) per steered axle") # VECTO throws here too

  parts = SP_baseline * SP_axle_shares.sum(axis=0) / 100 # each part summed over the steered axles
  parts = parts * SP_tech_factors.mean(axis=0)           # VECTO: average technology factor over all steered axles
  return float(parts.sum() * SP_alteff)                  # add the 3 parts, x 0.7
```
- Order matters: keep UF/B/S separate until the technology factor is applied (full electric steering gear has different factors per part: 0 / 0.143 / 1.429).
- [DECIDED] **One technology per steered axle, like VECTO.** Supersedes the 15 Oct "one dropdown for all axles". UI: one dropdown per steered axle, each defaulting to the first axle's choice.
- Why: with mixed technologies VECTO's averaged result sits about halfway between the two single-tech values. Worst cases (group 5 LH): 2 axles ±411 W, 3 axles ±404 W, 4 axles ±801 W, wrong pick −1201 W vs VECTO. 15–40 % of total aux while moving. How common mixed setups are: unknown, no source.
- Tests:

| Case | Result |
|---|---|
| Group 5, RD, 2 axles, both electric driven pump | 780.47 W |
| Group 5, RD, 1 axle, full electric steering gear | 49.02 W |
| Group 5, LH, 1 axle, electric driven pump | 431.93 W (8 Oct close-out: 431.9) |
| Group 5, RD, 2 axles, pump + steering gear | 431.90 W |
| Group 5, LH, 2 axles, pump + steering gear | 431.34 W |

### 4.3 `ssm_total_w` (HVAC thermal, function 1 of 3) — done
[VECTO] `SSMRun.cs` lines 26–64 (`TCalc`, `TotalW`); `SSMInputs.cs` lines 49–64 (strict `< 17` for clouding and body heat); constants from `Constants.BusAuxiliaries.SteadyStateModel` (verified 15 Oct).

Bob's current version (defaults moved to `HVAC_thermal`):
```python
# step 1: cabin heat balance, VECTO SSMRun.TotalW (SSMRun.cs lines 48-64)
def ssm_total_w(T_amb, solar, T_calc, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor):
  T_amb = np.asarray(T_amb, dtype=float) # outside temp per weather hour [°C]
  solar = np.asarray(solar, dtype=float) # sunlight per weather hour [W/m²]

  q_wall = (T_amb - T_calc) * A_surface * U
  q_people = N_persons * np.where(T_amb < T_boundary, heat_per_person[0], heat_per_person[1])
  q_solar = solar * A_window * g * np.where(T_amb < T_boundary, clouding[0], clouding[1]) * solar_factor

  return q_wall + q_people + q_solar
```
- Comment fixes to make: `T_boundary` = 17 °C switch for body heat and clouding (not the heating/cooling boundary; those are `T_calc` 18/23). `solar_factor` 0.25 is hard-coded in VECTO with no explanation — say so in the comment. `U` = how well heat passes through the walls (insulation).
- Sign: negative = cab loses heat (needs heating); positive = gains heat (needs cooling).
- °C is fine (only differences and the 17 °C compare are used); VECTO uses Kelvin.
- Inputs, one line each:
  - `T_amb`: outside temperature per weather hour, DMI [°C]
  - `solar`: sunlight on the ground per weather hour, DMI [W/m²]
  - `T_calc`: cab target, 18 °C (heating run) or 23 °C (cooling run), VECTO bus defaults
  - `A_surface`: cab outer surface heat flows through [m²], user
  - `U`: heat transfer through walls, higher = worse insulation [W/m²K], user
  - `N_persons`: people in the cab (1–2 for a truck)
  - `A_window`: glass area [m²], user
  - `heat_per_person`: 50 W below 17 °C, 80 W above (VECTO)
  - `clouding`: 0.65 below 17 °C, 0.8 above (VECTO)
  - `T_boundary`: 17 °C switch (VECTO)
  - `g`: 0.95 glass solar transmission (VECTO)
  - `solar_factor`: 0.25, unexplained VECTO multiplier
- [ASSUMPTION] All VECTO constants are **bus** values; using them for a truck cab must be flagged. Cab area, window area and U have no VECTO lorry source → user input.
- Test (made-up cab: A_surface 20, U 3, 1 person, window 4, T_calc 18 — illustrative only): −5 °C/0 → −1330 W; 17 °C/300 → +248 W; 30 °C/800 → +1408 W.

### 4.4 `HVAC_thermal` (function 3 of 3) — section 1 done, rest pending
[VECTO] Heating demand: `SSMCalculate.cs` lines 744–768 (`CalculateAverageHeatingPower`). Split/cap/electric: lines 172–220 (`CalculateHeatingPower`, `CalculateHeatingDistribution`).

Corrected version of section 1 (Bob's last paste still had the swapped setpoint names, hard-coded 18/23, unused `T_calc`, and the scalar `if`/`abs.max`/`max` — these fixes are below):
```python
def HVAC_thermal(T_amb, solar, A_surface, U, N_persons, A_window,
                 heat_per_person=(50.0, 80.0), clouding=(0.65, 0.8), T_boundary=17.0, g=0.95, solar_factor=0.25,
                 waste_heat=0.0, T_heat=18.0, T_cool=23.0):
  # HVAC thermal mode: VECTO bus SSM chain run per weather hour (HDEV deviation: VECTO averages 11 climate points)
  # defaults are VECTO bus values (Constants.cs), using them for a truck cab is an assumption

  # --- section 1: heating demand, VECTO CalculateAverageHeatingPower (SSMCalculate.cs lines 744-768)
  run1 = ssm_total_w(T_amb, solar, T_heat, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor) # 18 °C heating boundary
  run2 = ssm_total_w(T_amb, solar, T_cool, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor) # 23 °C cooling boundary

  both_losing = (run1 < 0) & (run2 < 0)                                            # heat only if the cab loses heat at both setpoints, per hour
  demand = np.where(both_losing, np.abs(np.maximum(run1, run2)) - waste_heat, 0.0) # smaller heat loss of the two; waste_heat = 0 for a BEV
  demand = np.maximum(demand, 0.0)                                                 # never negative

  # --- section 2: split + cap (next, needs climate_lookup)
```
- Test (same made-up cab): −5 °C → 1330 W; 17 °C → 0; 30 °C → 0.
- Dropped `**ssm_kwargs` (less explicit, no caching benefit).

**Remaining sections (VECTO logic, verified in repo):**

Section 2 — split + cap (`CalculateHeatingDistribution`):
```
hp_share, eh_share, fuel_share = per-hour from climate_lookup (HD case)
fuel = demand · fuel_share
sum  = min(max_heating_power, demand·hp_share + demand·eh_share)   # cap only on HP + electric heater
hp   = sum / (1 − fuel_share) · hp_share     (if fuel_share = 1: sum · hp_share)
eh   = sum / (1 − fuel_share) · eh_share
```
Section 3 — heating electric power:
```
HP_el = hp / cop_heat(T)     # missing COP → error (decided 15 Oct; VECTO silently gives 0 W)
EH_el = eh / eh_eff          # 0.93 constant at every heating point for all electric heater types
```
Section 4 — cooling: only if T ≥ 17 °C (`TemperatureCoolingTurnsOff`, hard-coded) **and** both runs > 0; load = min(run1, run2), capped at max cooling power; electric = load / cop_cool(T). [OPEN] Re-read the cooling code in `SSMCalculate.cs` before coding (summary from 15 Oct, not re-verified this session).

Section 5 — ventilation fan: volume × air-change rate × specific ventilation power (0.56 Wh/m³; rates 20/10/7 per h). [OPEN] Re-read switching logic before coding.

Section 6 — total electric = HP_el + EH_el + cooling_el + fan. Fuel heater output returned **separately** (diesel, not battery) [SUGGESTION].

**Deviations from VECTO to flag in reports:**
1. Per hour instead of 11 weighted climate points → no `env.Weighting`.
2. Driver/passenger split: truck cab = driver share 1 [ASSUMPTION; VECTO has no truck case].
3. Missing COP → error instead of VECTO's 0 W.
4. COP interpolation / nearest-point split (see section 5 below).
5. Bus constants used for a truck cab.

---

## 5. `climate_lookup` (function 2 of 3) — next to write

[VECTO] `VectoCore/VectoCore/Resources/Declaration/Buses/DefaultClimatic.aenv` (the declaration file; the test-data copy has no COP columns) and `HeatingDistribution.csv`.

| Point | T [°C] | Solar | Weight | Mode | R-744 | non-R-744 2-st | 3-st | 4-st | contin. | El. heaters (water/air/other) | Fuel heater |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | −20 | 10 | 0.0053 | h | 1.80 | – | – | – | – | 0.93 | 0.80 |
| 2 | −5 | 30 | 0.0826 | h | 2.04 | 1.54 | 1.64 | 1.68 | 1.78 | 0.93 | 0.80 |
| 3 | 2 | 30 | 0.0826 | h | 2.50 | 2.00 | 2.10 | 2.10 | 2.22 | 0.93 | 0.80 |
| 4 | 8 | 20 | 0.1661 | h | 2.98 | 2.70 | 2.80 | 2.82 | 2.94 | 0.93 | 0.80 |
| 5 | 8 | 155 | 0.0826 | h | 2.98 | 2.70 | 2.80 | 2.82 | 2.94 | 0.93 | 0.80 |
| 6 | 14 | 30 | 0.0826 | h | 3.38 | 3.24 | 3.34 | 3.36 | 3.50 | 0.93 | 0.80 |
| 7 | 14 | 175 | 0.1243 | h | 3.38 | 3.24 | 3.34 | 3.36 | 3.50 | 0.93 | 0.80 |
| 8 | 20.5 | 30 | 0.1243 | c | 3.80 | 3.62 | 3.74 | 3.74 | 3.88 | – | – |
| 9 | 20.5 | 200 | 0.1243 | c | 3.80 | 3.62 | 3.74 | 3.74 | 3.88 | – | – |
| 10 | 26 | 150 | 0.0826 | c | 2.82 | 3.12 | 3.22 | 3.24 | 3.36 | – | – |
| 11 | 33 | 150 | 0.0427 | c | 2.14 | 2.50 | 2.60 | 2.62 | 2.74 | – | – |

Heating distribution (shares %, point 1 / point 2 / point 3 / points 4–11):

| Case | Setup | HP | El. heater | Fuel |
|---|---|---|---|---|
| HD1 | R-744 only | 100 everywhere | – | – |
| HD2 | R-744 + el. heater | 50 / 100 / 100 / 100 | 50 / 0 / 0 / 0 | – |
| HD3 | R-744 + el. + fuel | 40 / 70 / 80 / 100 | 20 / 0 / 0 / 0 | 40 / 30 / 20 / 0 |
| HD4 | R-744 + fuel | 40 / 70 / 80 / 100 | – | 60 / 30 / 20 / 0 |
| HD5 | non-R-744 only | 100 everywhere | – | – |
| HD6 | non-R-744 + el. | 0 / 100 / 100 / 100 | 100 / 0 / 0 / 0 | – |
| HD7 | non-R-744 + el. + fuel | 0 / 70 / 80 / 100 | 20 / 0 / 0 / 0 | 80 / 30 / 20 / 0 |
| HD8 | non-R-744 + fuel | 0 / 70 / 80 / 100 | – | 100 / 30 / 20 / 0 |
| HD9 | el. heater only | – | 100 everywhere | – |
| HD10 | el. + fuel | – | 20 / 0 / 0 / 0 | 80 / 100 / 100 / 100 |
| HD11 | fuel only | – | – | 100 everywhere |
| HD12 | no heating | – | – | – |

Findings:
- Points 4/5, 6/7, 8/9 differ only in solar; COP and split identical → mapping by temperature only loses nothing.
- Heater efficiency is constant (0.93 electric, 0.80 fuel) → a plain number from the parser, no lookup.
- Split only changes at points 1–3.

Planned function (pure):
- **Inputs** (parser picks columns): `T_amb` per hour; `T_heat_points` (−20, −5, 2, 8, 14) + `cop_heat_points` (5); `T_cool_points` (20.5, 26, 33) + `cop_cool_points` (3); `hp_share_points`, `eh_share_points`, `fuel_share_points` (5 each, chosen HD case).
- **Method:** COP = `np.interp(T, points, cop)` separately for heating and cooling (`np.interp` holds end values beyond the range). Shares = nearest heating point.
- **Returns per hour:** `cop_heat`, `cop_cool`, `hp_share`, `eh_share`, `fuel_share`.
- [DECIDED 15 Oct] COP linear interpolation within heating points and within cooling points; split from nearest heating point; missing COP → error.
- [ASSUMPTION] Holding end values (e.g. heating at 16 °C uses the 14 °C COP; cooling at 18 °C uses the 20.5 °C COP).
- [OPEN] Missing non-R-744 COP at −20 °C: user must enter one (parser error otherwise). Only needed when the HP share at point 1 > 0 (HD5); HD6/7/8 have 0 there.
- [SUGGESTION] Tie rule for nearest point: exactly halfway (e.g. −12.5 °C) → pick the colder point (more conservative). Not yet agreed.

---

## 6. PTO (status)

- [DECIDED] One `pto_engine` holds both: stop table (W + usage time per stop, on stop waypoints, not forward-filled) and one always-on W field (chiller, mixer). No weather.
- Mapped onto rows in the consumption engine (see 2.1).
- [OPEN, from 15 Oct] (1) PTO time > stop time: error, or clamp and flag? (2) Which seconds of the stop: centred (VECTO, `DistanceBasedDrivingCycle.cs`) or first seconds (simpler, flagged)?
- [OPEN] Kiro's 0.14993 kWh per refuse stop still unverified (needs `MunicipalUtility_PTO_generic.vptoel`, now readable from the repo).

## 7. Cond (status)

- VECTO number from `Cond-Table.csv` (lorry: LH 600, RD 600, UD 550, MU 550, Constr 600 W; already electric) + `cond_delta` hook = 0.
- Cond thermal can't be precomputed: it needs battery heat (I²R from battery power) and pack temperature carried row to row (like SOC) → belongs inside the consumption/battery loop (year-run tracker, 13 Oct). Not now.

---

## 8. Other notes

- `payload_engine` reviewed: fine. Edge case: empty `stop` array crashes at `is_stop[0] = False` (only matters if an empty route can reach it).
- Code style kept: Bob's variable names (`ES_alteff`, `PS_alteff`), inline comments, numpy throughout, `np.asarray(..., dtype=float)` before maths, `np.where` instead of scalar `if` for arrays.

## 9. Open items (consolidated)

1. Driver model rows: confirm cumulative distance column exists.
2. `EmOffPrev` (when a BEV motor is "off") → driver-model audit; affects Cond on-rule.
3. Power-limit check (wheel power vs motor max) — suggested, not agreed.
4. HVAC cooling and ventilation sections: re-read `SSMCalculate.cs` before coding.
5. Fuel heater output returned separately — suggested, not agreed.
6. Nearest-point tie rule — suggested, not agreed.
7. PTO: time > stop time rule; centred vs first seconds.
8. Kiro refuse PTO energy unverified.
9. Driver-model bugs from the audit (6 bugs) still open.

## 10. Next steps (in order)

1. Write `climate_lookup` (signature first). Parser side: column picking for heat-pump type + HD case.
2. Finish `HVAC_thermal` sections 2–6 (re-read cooling + ventilation code first).
3. `pto_engine`.
4. Consumption engine aux sum (section 2.2).
5. UI reminder: efficiency-field label (section 3).
