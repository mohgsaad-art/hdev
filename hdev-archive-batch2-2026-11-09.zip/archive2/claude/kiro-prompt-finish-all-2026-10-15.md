# Kiro prompt — finish everything (PR 1 fix through PR 10) in one run

Owner: Bob. Repo: `mohgsaad-art/hdev`. This continues `KIRO_PROMPT_assistant_ui_and_engine.md` (the "main prompt"). All of its rules (§0), contracts (§3), assistant rules (§4), UI spec (§5), engine table (§6), demo rules (§7) and never-shown list (§8) still apply. Where this prompt differs, this prompt wins.

---

## A. How to run this job

1. **Do all the work in one run. Don't wait for Bob between steps.**
2. **One PR per step, stacked.** Each step's branch starts from the previous step's branch. Open each PR against the previous step's branch (step 1 against `main`), so Bob can review and merge them in order.
3. **Each PR must pass its own tests** before you start the next step. If a step's tests fail and you can't fix them, stop, write down why in that PR and in the final summary, and continue only with steps that don't depend on it.
4. **Blocked items never stop the run.** Anything that depends on a 🔒 item (M0.12, M6.6, M6.7, M6.16, M6.20, M6.21, M6.24–25, M5.6) or on a value with no source gets an interface plus a stub raising `NotImplementedError("blocked by <item>")`. The UI shows "Not yet available" for it. Then move on.
5. **Every PR description lists:** what it does, how to test it, 🔒 items touched, values without a source, and anything from §8 that came close to being shown.
6. **When everything is done,** post one final summary listing: every PR with its link, the order to merge them, every stub and what blocks it, and the exact commands to start the app.

---

## B. The steps

### Step 1 — Fix PR #7 (push to the existing `feat/registry-slot-validator` branch)

The 112 total and the §5.4 section/subgroup counts were **mock-up placeholders, not requirements**. The registry is the source of truth and the UI follows it.

- Give every field a `maps_to` entry naming the engine function argument, or the source document it comes from (`design.md`, `docs/decisions/*`, the 2026-10-07 VECTO defaults note, `reference/excel/*`).
- Remove every field that exists only to match the mock-up counts.
- Sections and subgroups may change if the real inputs call for it. Keep the 8 section names unless a section ends up empty.
- Tests: remove asserts on 112 and on the §5.4 subgroup counts. Add tests that every field has a `maps_to` and that section and subgroup counts are computed from the registry.
- The PR description contains the full field table: id, label, section, subgroup, visibility, `maps_to`, plus a list of removed fields.

### Step 2 — Local server + static UI shell

- FastAPI bound to `127.0.0.1` only. Static files are served by the same server.
- Header, assistant column and empty workspace, per §5.1–5.2.
- Self-host Barlow and Barlow Condensed (OFL licence) in `static/fonts/` so it works offline.
- Section names and counts come from `/api/inputs` (the registry). Nothing about the sections is hard-coded in JS.
- One start command: `python -m hdev.app` (or `make run`), documented in `README.md`.

### Step 3 — Demo intake

- `demo/sample_case/`: the message text, two sample files (`fuel_log_2025.xlsx`, `collection_routes.pdf`) and the extracted values with their sources.
- `/api/intake` in demo mode returns the extracted values from the fixture.
- The UI runs the filling animation (§5.3 states 1–3), driven by the server response.
- The missing flow ends with buttons *Use standard values* and *I'll add them myself*.
- "Missing" fields are whatever the registry and fixture say. Don't hard-code "2".

### Step 4 — `demo_engine.py` + `/api/run`

- `demo_engine.run_scenario(project, levers) → results JSON` follows §3.3 exactly.
- Port the stand-in formulas from the mock-up's JS (`docs/design/ui-mockup/fleet-assistant-demo.html`, the block marked `ILLUSTRATIVE NUMBERS ONLY`) into Python. Changing a lever or the shift end must move results in the same direction as the mock-up.
- Every result carries `"illustrative": true, "mode": "demo"`.
- Tests on the JSON shape and on the direction of change for each lever.

### Step 5 — Run screen, results tabs, charts, scenario bar

- Run screen with 9 checklist lines, plus "Done in X s · N truck-days simulated" using real timing and counts.
- All tabs from §5.6 (Inputs, Overview, Energy, Charging, Grid & flexibility, Costs (TCO), CO₂, Scenarios, Report, Audit trail).
- Charts are hand-drawn SVG, with no chart library.
- Scenario bar (§5.5) with the recalculation overlay. Every change calls `/api/run`.
- JS does no maths. It only draws the numbers the server sends.

### Step 6 — Assistant in demo mode

- All suggestion buttons from §4.4, the typed-question keyword matching, the field-edit rerun (shift end), and replies built by `explain/` templates from results JSON.
- Add the number check (§4.3): any reply containing a number that isn't in the current results JSON or registry is blocked and replaced by the template text.

### Step 7 — Scenarios, audit trail, run log

- Save/list/compare scenarios. The Audit tab shows source counts (types only, never field names) plus the run log (§3.4), stored in the project JSON.

**Demo acceptance after step 7:**
- With no internet and no API key, the full flow runs without errors: files, message, fill, missing, standard values, run, results, every suggestion button, the shift edit, save scenario, audit trail and report tab.
- The "illustrative values" label is visible.
- Add a Playwright test that clicks through this flow.

### Step 8 — Report export

- PDF and Excel built in Python from the results JSON and the audit data. They hold the 9 sections from §5.6.
- The "Inputs & sources" section lists source types and counts, plus `open` fields with values. It never lists `collapsed` or `hidden` fields.
- Demo reports carry an "Illustrative values – sample case" watermark on every page.

### Step 9 — Engine functions (§6 of the main prompt)

- One PR per function, in the order of §6. Each is pure and every parameter is an argument.
- Tests: against VECTO where a reference exists, otherwise against hand-checked cases written down in the test.
- Driver model: list each fix in the PR. Never change grade handling (🔒 M0.12).
- Then wire `runner.run(base, changes)` so real mode calls the real pipeline. Any stage that is still a stub returns `null` fields, and the UI shows "Not yet available".

### Step 10 — Real AI assistant

**Provider adapter `ai/provider.py`, with one interface and two back ends:**

| Backend | Use | Setup |
|---|---|---|
| `gemini` (default) | Google Gemini Developer API, **free tier** | `GEMINI_API_KEY` in `.env` (key from Google AI Studio). Model name in `.env` (`GEMINI_MODEL`); use a Flash model that is on the free tier at build time, and document which one in the README. |
| `ollama` | Local model, fully offline and private | `OLLAMA_URL` (default `http://127.0.0.1:11434`) and `OLLAMA_MODEL` in `.env` |

- Choose with `AI_PROVIDER=gemini|ollama`. No other code changes when switching.
- Use plain HTTP or the provider's official SDK. Add retries and a clear error message when the key is missing or the rate limit is hit.
- Tool calling as in §4.2. If a backend has no native tool calling, use a JSON-only reply format and validate it in Python.
- **Data guard:** the Gemini free tier may use inputs to improve Google's products. So every project has a `client_data: true|false` flag (default `true`). The server **refuses** to send a project with `client_data: true` to the `gemini` backend unless `ALLOW_CLIENT_DATA_ON_FREE_TIER=true` is set, and the UI shows the reason and suggests switching to `ollama`. This guard applies to the free tier. Add `GEMINI_PAID=true` to lift it when Bob moves to a paid key.
- Demo mode never calls any AI provider.
- All §4.3 rules apply: numbers only from results, results not methods, and the number check.
- Tests use a fake provider, so no real API calls run in CI.

---

## C. Final deliverable

- PRs 1 (fixed) to 10, stacked, each passing its tests.
- `README.md` covering:
  - how to start the app
  - how to switch demo/real mode
  - how to set up Gemini or Ollama
  - the data-guard rule
  - the list of stubs and what blocks each one
- The final summary (§A.6).
