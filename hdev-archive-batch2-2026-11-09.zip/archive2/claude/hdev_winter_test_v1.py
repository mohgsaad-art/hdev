# =====================================================================================
# HDEV winter + battery test v1 (22 Oct 2026) -- runs in Claude's workspace, NOT in Colab
# Base: HDEV v1.7 rows (trace B, split wheel power), EU standard-value drivetrain (add-on v1),
#       coasting drag as the measured ratio C/B from Bob's add-on run (case C / case B, drivetrain part)
# Added, each as its own switch so its effect is visible:
#   1 air density from temperature            ideal gas, p 101325 Pa, R 287.05 (harness v1.7)
#   2 cold tyres                              ISO 28580 eq. 10: F25 = F*(1 + Kt*(t-25)), Kt 0.006 (truck tyre, LI > 121)
#                                             [ASSUMP] ISO allows 20-30 C only -> used outside its range; tyre warm-up ignored;
#                                             LI of 265/70 R19.5 taken as > 121 (not in the VECTO file)
#   3 HVAC thermal                            VECTO bus SSM via harness T14 band means (placeholder cab 20 m2, U 3.0) [ASSUMP]
#                                             electric heater (HD9) = main case, R-744 heat pump (HD1) = alternative
#   4 fresh-air heating                       HDEV addition, not in VECTO SSM: V * n * rho * cp * (18 - T) / 0.93
#                                             V 6.5 m3 (placeholder), n 7/h (VECTO bus), cp 1005 J/kgK (textbook), 0.93 heater eff (VECTO)
#   5 battery losses                          VECTO OCV + Ri: GenericBattery_243kWh_750V.vbat, Ri 0.04 ohm, OCV curve .vbatv, start SOC 50 %
#                                             [ASSUMP] Ri constant with temperature (VECTO has no temperature effect; no sourced cold Ri)
#   not included: battery heating/preconditioning (Dollinger & Fischerauer 2021: ~4 % of winter consumption, model study,
#                 shown as an optional line only), door openings, snow/slush, Cond thermal (Cond stays VECTO constant)
# Weather: DMI 2025, trip-mean temperature per day from harness T12 (Regional, departure 07:00) [ASSUMP: same days used for Urban]
# =====================================================================================
import sys, os, math
import numpy as np, pandas as pd

BASE = sys.argv[1] if len(sys.argv) > 1 else "."
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hdev_addon_std_drag_v1.py")).read()
E = os.path.join(BASE, "vecto") + "/"
R_DYN = 0.867 * 3.05 / (2 * math.pi); V_NO_REGEN = 5 / 3.6
def read_csv_numeric(rel, enc="utf-8-sig"): return None, np.genfromtxt(E + rel, delimiter=",", skip_header=1)
g = dict(np=np, pd=pd, math=math, os=os, OUT_DIR=os.path.join(BASE, "smoke_out/x"), R_DYN=R_DYN, V_NO_REGEN=V_NO_REGEN,
         read_csv_numeric=read_csv_numeric, run_chain=1, CYCLES=1, check=1, run_test=1, show=1, split_energy=1)
os.makedirs(g["OUT_DIR"], exist_ok=True)
exec(src[:src.index("def d00():")], g)
drivetrain_el = g["drivetrain_el"]

P, R, RHO_V = 101325.0, 287.05, 1.188
T_REF = P / (R * RHO_V) - 273.15                        # 23.97 C -> VECTO's 1.188 kg/m3
KT = 0.006
HVAC_BANDS_T = np.array([-7.5, -2.5, 2.5, 7.5, 12.5, 17.5, 22.5, 30.0])
HVAC_EH = np.array([1524, 1208, 936, 622, 261, 55, 119, 253.0])   # harness T14, electric heater, band means [W]
HVAC_HP = np.array([715, 510, 357, 217, 93, 42, 118, 277.0])      # harness T14, R-744 heat pump
VECTO_HVAC = {"RegionalDelivery": 250.0, "UrbanDelivery": 187.5}
COAST_RATIO = {"RegionalDelivery": (97.07 - 3.258) / (94.72 - 3.264), "UrbanDelivery": (84.36 - 6.734) / (81.52 - 6.752)}  # Bob's add-on run
VECTO_FINAL = {"RegionalDelivery": 1.062, "UrbanDelivery": 0.853}  # .vsum EC_el_final (incl. battery losses), 22 Oct run

_, ocv = read_csv_numeric("Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/GenericBattery_243kWh.vbatv")
RI, CAP_AH = 0.04, 324.0 * 2                            # [VECTO] .vbatr, .vbat x NumPacks 2 (.vveh)

def battery_loss(P_term, dt=1.0, soc0=50.0):
    """VECTO-style: terminal power -> internal power with Ri loss; returns loss per row [W] (P_term + = discharge)"""
    soc = soc0; loss = np.zeros(len(P_term))
    for i, p in enumerate(P_term):
        u0 = np.interp(soc, ocv[:, 0], ocv[:, 1])
        I = (u0 - math.sqrt(u0 * u0 - 4 * RI * p)) / (2 * RI)
        loss[i] = I * I * RI
        soc -= I * dt / 3600 / CAP_AH * 100
    return loss

# ---- check the battery model on VECTO's own rows ----
for c, f in [("RegionalDelivery", "data/RD.vmod"), ("UrbanDelivery", "data/UD.vmod")]:
    v = pd.read_csv(os.path.join(BASE, f), skiprows=1, encoding="utf-8-sig")
    v = v[~v.iloc[:, 0].astype(str).str.startswith("#")].apply(pd.to_numeric, errors="coerce")
    ours = battery_loss(-v["P_REESS_T [kW]"].to_numpy() * 1000).sum() / 3.6e6
    print(f"battery-loss check {c}: ours {ours:.3f} kWh vs VECTO {v['P_REESS_loss [kW]'].sum()/3600:.3f} kWh")

daily = pd.read_csv(os.path.join(BASE, "hdev_out/T12_year_daily.csv"))
daily["month"] = pd.to_datetime(daily.date).dt.month

def run(c, T, hvac="EH", tyres=True, fresh_air=True, batt=True):
    h = HR[c]; km = h["km"]; n = h["n"]
    rho_f = P / (R * (T + 273.15)) / RHO_V
    roll_f = 1 / (1 + KT * (T - 25)) if tyres else 1.0
    Pw = h["lin"] + h["roll"] * roll_f + h["rot"] + h["air"] * rho_f
    P_el, _, _ = drivetrain_el(h["va"], np.where(h["use"], Pw, 0.0), h["use"])
    P_el = P_el * COAST_RATIO[c]
    if hvac == "VECTO":
        hv = VECTO_HVAC[c]
    else:
        hv = float(np.interp(T, HVAC_BANDS_T, HVAC_EH if hvac == "EH" else HVAC_HP))
    fa = 6.5 * 7 / 3600 * (P / (R * (T + 273.15))) * 1005 * max(18 - T, 0) / 0.93 if fresh_air else 0.0
    P_term = P_el + h["aux"] + (hv - VECTO_HVAC[c]) + fa
    loss = battery_loss(P_term) if batt else np.zeros(n)
    return dict(kWh_km=(P_term.sum() + loss.sum()) / 3.6e6 / km, batt_kWh=loss.sum() / 3.6e6, hvac_W=hv, fresh_W=fa)

HR = {}
for c in VECTO_HVAC:
    h = pd.read_csv(os.path.join(BASE, f"hdev_out/HDEV_rows_{c}_base.csv"))
    va = np.maximum(h.v_kmh / 3.6 + h.a / 2, 0).to_numpy(); M = h["mode"].to_numpy()
    rot = 6.5 * 6 / R_DYN ** 2 * h.a.to_numpy() * va                  # [ASSUMP] wheel inertia part
    HR[c] = dict(km=h.s_m.iloc[-1] / 1000, n=len(h), va=va, use=(M != 0) & (M != 3) & ~((M == 4) & (h.v_kmh.to_numpy() / 3.6 <= V_NO_REGEN)),
                 lin=(h.P_grade_W + h.P_inertia_W).to_numpy() - rot, rot=rot, roll=h.P_roll_W.to_numpy(), air=h.P_air_W.to_numpy(),
                 aux=h.P_aux_W.to_numpy())

# ---- step by step at three temperatures ----
rows = []
for c in VECTO_HVAC:
    for T in [T_REF, 5.0, -5.0]:
        steps = [("standard drivetrain + coast drag", dict(hvac="VECTO", tyres=False, fresh_air=False, batt=False)),
                 ("+ battery losses", dict(hvac="VECTO", tyres=False, fresh_air=False, batt=True)),
                 ("+ HVAC thermal (el. heater)", dict(hvac="EH", tyres=False, fresh_air=False, batt=True)),
                 ("+ fresh-air heating", dict(hvac="EH", tyres=False, fresh_air=True, batt=True)),
                 ("+ cold tyres (ISO 28580)", dict(hvac="EH", tyres=True, fresh_air=True, batt=True))]
        for lab, kw in steps:
            if T == T_REF and lab != "+ battery losses" and lab != "standard drivetrain + coast drag":
                continue
            r = run(c, T, **kw)
            rows.append(dict(cycle=c, T_C=round(T, 1), step=lab, kWh_km=r["kWh_km"]))
print(pd.DataFrame(rows).round(3).to_string(index=False))

# ---- year (DMI 2025): every day at its trip temperature, all pieces on ----
res = []
for c in VECTO_HVAC:
    for hvac in ["EH", "HP"]:
        k = np.array([run(c, T, hvac=hvac)["kWh_km"] for T in daily.T_trip_C])
        d = daily.assign(k=k)
        ref = run(c, T_REF, hvac="VECTO", tyres=False, fresh_air=False)["kWh_km"]
        res.append(dict(cycle=c, heating="electric heater" if hvac == "EH" else "heat pump", ref_24C=ref,
                        year_mean=k.mean(), january=d[d.month == 1].k.mean(), july=d[d.month == 7].k.mean(),
                        coldest_5pct_days=np.quantile(k, 0.95), max_day=k.max(), winter_swing_pct=(d[d.month == 1].k.mean() / d[d.month == 7].k.mean() - 1) * 100,
                        VECTO_final=VECTO_FINAL[c], ref_vs_VECTO_pct=(ref / VECTO_FINAL[c] - 1) * 100))
print(pd.DataFrame(res).round(3).to_string(index=False))
print(f"trip temperatures 2025: mean {daily.T_trip_C.mean():.1f} C, Jan {daily[daily.month==1].T_trip_C.mean():.1f}, Jul {daily[daily.month==7].T_trip_C.mean():.1f}, min {daily.T_trip_C.min():.1f}")
