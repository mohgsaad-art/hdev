# HDEV session close-out: PTO design finalised (30-31 Oct 2026)

Hand-over for a new chat. Read this first for anything about PTO.

Tags:
- **[VECTO]**: read from Bob's repo `mohgsaad-art/VECTO` (branch `IEPC-experiments`), file and lines named.
- **[DECIDED]**: Bob agreed.
- **[ASSUMPTION]**: HDEV choice, must be flagged in reports.
- **[TESTED]**: run in Claude's workspace with small examples.
- **[OPEN]**: not resolved.

Related: `claude/session-closeout-2026-10-22-function-review-crosswind-payload-pto.md` (earlier PTO review, the 26 Oct start/end-column design is **superseded** by this file), `claude/session-closeout-2026-10-21-pto-driver.md` (original `pto_engine`, VECTO stop-PTO rules), `claude/ui-input-list-2026-10-26.md`.

Function status this session: `crosswind_engine` finalised, `payload_engine` finalised, **`pto_engine` finalised (engine side)**. The consumption-engine side of PTO is not written yet (section 5).

---

## 1. What VECTO does for PTO while driving (checked in source)

- Only in **engineering mode**, not declaration [VECTO `PowertrainBuilderBase.cs` lines 325 and 339]. Reports must say "VECTO engineering-mode method".
- One PTO column per waypoint, four values [VECTO `DrivingCycleData.cs`, enum `PTOActivity`]: 0 off, 1 at stop, 2 road sweeping, 3 PTO while driving.
- **Sweeping (2)** [VECTO `RoadSweeperAuxiliary.cs` 30-34]: on for every stretch that starts at a waypoint flagged 2; power from a per-waypoint `P_PTO` column (kW), interpolated by distance.
- **While driving (3)** [VECTO `PTODriveAuxiliary.cs`]: a flagged waypoint starts one profile (`.vptor`, `t` + `PTO_Power` in kW) that runs by time for its own length.
  - It keeps running if the truck stops (only a warning, lines 72-74).
  - A second trigger while it still runs is an **error** (lines 39-41).
  - Power per step is energy-averaged (lines 59-75).
- For a **BEV**, driving PTO is put on the motor shaft as torque (power / motor speed) [VECTO `PowertrainBuilderBase.cs` 321-349], so it goes through motor losses. Sweeping needs a min engine speed or fixed gear (lines 327-330).
- Stop PTO profile files: `.vptoel`, columns `<t>`, `<P_PTO_el>` in kW (e.g. `MunicipalUtility_PTO_generic.vptoel`). Drive profile files: `.vptor`, columns `t`, `PTO_Power` in kW, times need not be 1 s apart (the example has rows at 0, 10, 12, 15, 25, 28, 30 s).
- VECTO's example sweeper cycle `PTO_RoadSweeper.vdri` (12-25 kW on 7 waypoints) and `PTO-cycle.vptor` (20-40 kW) are **illustrative, not measured**.
- Standard declaration cycles only use label 1 (Municipal). Labels 2 and 3 appear only in engineering examples.

## 2. Decisions [DECIDED]

1. **Unified design, no 0/1/2/3 labels.** Every PTO case is "something at the stop" and/or "something after leaving it". Each stop row has one on/off flag. If on, two **parts** can run:
   - **Stop part:** while standing at the stop.
   - **Drive part:** from the moment the truck leaves that stop (or marker row) until the next stop.
2. **Each part is either one number or a profile.**
   - One number = constant, fills the whole window (whole stop, or whole drive to the next stop). Adapts to the window length.
   - Profile (time + W lists) = plays its own seconds once, never stretched or squeezed. Stop shorter than profile: the parser lengthens the stop (VECTO). Stop longer: no PTO for the rest of the stop.
3. **Stop part and drive part are separate inputs** (a refuse truck lifts at the stop and compacts while driving with different powers). The code that reads them is shared.
4. **Always-on PTO stays in `P_aux`** (`PTO_always_on`, eff 1.0). It does not go through `pto_engine`.
5. **Constants skip `pto_engine`.** `pto_const` / `drive_const` go straight from the parser to the consumption engine, like always-on PTO. `pto_engine` only prepares profiles. (Replaces the intermediate version where constants were arguments.)
6. **Drive profile still running when the next stop arrives: keep running** (VECTO behaviour, does not underestimate). Applies to VECTO profiles. Own profiles use the same rule until a real case needs another; a second rule would need a source flag per profile.
7. **A drive part can start at a 0-second marker row** in the stop table (for sweeping that does not start at a real stop). With VDRI every waypoint is already a row.
8. **One sweeping power for the whole route**; VECTO's per-waypoint varying power is parked. Deviation from VECTO to flag in reports.
9. **PTO profile lists are always lists:** empty list = no profile. The parser gives `is_on` as one 1/0 per waypoint (the "one value for all stops" step is the parser's job).
10. **Readable code over clever code:** one step per line, short comments above blocks (Bob: compressed one-liners "look like gibberish").
11. **PTO efficiency (31 Oct, option A):** the user sets an efficiency field per kind of PTO: stop, drive, always-on. 1.0 = value already electric; otherwise the mechanical-to-electric efficiency. Defaults 1.0 for all three.
    - **Applied by division:** electric W = entered W / efficiency. (Correction 1 Nov: the 31 Oct note said "multiply", which is the wrong direction for a shaft value and would underestimate.)
    - Stop and drive **profiles:** divided inside `pto_engine` (Bob's choice, 1 Nov).
    - Stop and drive **constants:** they skip `pto_engine`, so they are divided in the consumption engine when placed on the rows.
    - Always-on: in `P_aux`, `PTO_always_on / PTO_eff`. The other `P_aux` factors (ES 0.7, HVAC 1.25, SP 0.7, PS 1.0, Cond 1.0) stay **multiplied**, because that is VECTO's convention (e.g. ES 1428.57 W x 0.7 = 1000 W, HVAC 200 W x 1.25 = 250 W).
    - Why three: the VECTO stop profile `.vptoel` is electric power (`P_PTO_el`), so 1.0; the VECTO drive profile `.vptor` is power at the PTO shaft, which VECTO pushes through the motor [VECTO `PowertrainBuilderBase.cs` 321-349], so 1.0 underestimates; a user's own values can be either.
    - UI label next to each field (same idea as ES): "1.0 = already electric; set the efficiency if your value is at the shaft".
    - Once the drivetrain maps exist, drive PTO can move onto the motor shaft like VECTO and the field becomes a fallback.

Why unified beat the label version:
- Fits the stop table Bob already has (`pto_on` column).
- Refuse truck (lift at stop **and** compact after) works from the same stop; one VECTO label per waypoint cannot do both at one spot.
- Only loss: varying sweeper power, for which there is no measured data anyway.

## 3. Which PTO case uses what

| Case | Input |
|---|---|
| Refuse truck | VECTO stop profile (`.vptoel`), or stop profile + drive profile of its own |
| Road sweeper | drive part = one number (marker row if it does not start at a stop) |
| Crane / hook-lift | stop part = profile or one number |
| Chiller / mixer drum (always running) | always-on number in `P_aux` |

## 4. `pto_engine` (final, engine side) [TESTED]

Bob's final version (1 Nov), with the return fixed to `is_on`:

```python
#PTO engine
def pto_engine(stop, is_on, stop_pto_t, stop_pto_w, drive_pto_t, drive_pto_w, stop_pto_eff, drive_pto_eff):

  stop = np.asarray(stop, dtype=float) # stop time of every waypoint/row in s, 0 means no stop; this is just the stop column from vecto or custom inputs this also includes PTO usage time
  is_on = np.array(is_on, dtype=float)       # 1 = PTO on at this waypoint, 0 = off
  stop_pto_t = np.asarray(stop_pto_t, dtype=float) #pto time profile
  stop_pto_w = np.asarray(stop_pto_w, dtype=float) #pto power profile
  drive_pto_w = np.asarray(drive_pto_w, dtype=float) #drive power profile
  drive_pto_t = np.asarray(drive_pto_t, dtype=float) #drive time profile

  is_on[0] = 0 # the first waypoint is the depot: never PTO there

  # turn each profile into one power value per second
  stop_steps = np.diff(stop_pto_t).astype(int) # how many seconds each value lasts
  stop_1s = np.repeat(stop_pto_w[:-1], stop_steps) # stop PTO, W per second

  drive_steps = np.diff(drive_pto_t).astype(int)
  drive_1s = np.repeat(drive_pto_w[:-1], drive_steps) # drive PTO, W per second

  pto_dur = len(stop_1s)   # stop profile length [s]

  #assigning stop pto profiles to waypoints
  is_stop = stop > 0 # true where the vehicle stops
  stop_on = is_stop & (is_on > 0) & (pto_dur > 0) # its a stop & stop pto is on & it has stop profile

  # putting the stop PTO in the center of stops same as VECTO
  pto_start = np.full (len(stop),np.nan) # NaN = no stop profile here
  pto_start[stop_on] = np.floor((stop[stop_on] - pto_dur) / 2) # floor for odd seconds = HDEV assumption

  too_short = np.where(pto_start < 0)[0]
  if len(too_short) > 0:
      raise ValueError(f"PTO ({pto_dur} s) is longer than the stop at waypoint(s) {too_short.tolist()}; the parser must extend these stops")

  #apply the effeciencies
  stop_1s = stop_1s / stop_pto_eff
  drive_1s = drive_1s / drive_pto_eff

  return is_on, pto_start, stop_1s, drive_1s
```

Changes vs the 21 Oct version:
- Arguments renamed `stop_pto_t`, `stop_pto_w`; new `drive_pto_t`, `drive_pto_w`, `stop_pto_eff`, `drive_pto_eff`. Time before power for both profiles.
- `is_on` is now **one 1/0 per waypoint** (not per stop), so a 0 s marker row can start a drive part.
- Returns `is_on` (not `is_stop`): the drive part also starts on marker rows that are not stops.
- Efficiency applied here, **by division** (shaft W / efficiency = electric W; 1.0 = already electric). Constants skip this function, so their efficiency is applied in the consumption engine.
- The too-short check stays as a bug guard; the friendly check and the stop extension are parser jobs.
- Constant PTO and "off" are not handled here: empty lists = no profile; constants go parser -> consumption engine.

Tests (stops 9 s and 6 s; profile 5000 W for 1 s then 3000 W for 2 s):
- Stop profile: `stop_1s = [5000, 3000, 3000]`, starts 3 s and 1 s.
- Efficiency 0.9 on the stop profile: 5556 / 3333 / 3333 W. Drive profile 8000 W at 0.8: 10,000 W.
- Marker row: `is_on` is 1 only at that row; drive profile built.
- Without the guard, a stop shorter than the profile gives a start of -1 (PTO would land before the stop silently), so the check must exist somewhere.
- Refuse profile still gives 0.14993 kWh per stop at efficiency 1.0 (earlier verified).

## 5. Consumption engine: what it must do with PTO (not written yet) [OPEN]

How the tie works: all PTO columns have the length of the waypoint list, so position `i` is waypoint `i`. The link to the 1 s rows is **distance**: `wp_s[i]` equals the `S` of that stop's standing rows (the driver model snaps the stop distance exactly). Match with a tolerance (1e-3 m), not `==`.

- **Stop profile:** for each `i` with `is_on[i] == 1` and a `pto_start[i]`: find rows with `V == 0` and `S` = `wp_s[i]`, take the first, add `pto_start[i]` rows, copy `pto_1s` onto the next `len(pto_1s)` rows.
- **Stop constant:** put `pto_const` on all standing rows of the stop.
- **Drive profile:** first moving row after the last standing row of that stop, copy `drive_1s` (keep running past the next stop).
- **Drive constant:** `drive_const` on all moving rows until the next stop.
- **Efficiency:** profiles arrive already divided by their efficiency (`pto_engine`). Constants: divide `pto_const` by `stop_pto_eff` and `drive_const` by `drive_pto_eff` when placing them (decision 11). Always-on is handled in `P_aux`.
- Energy is not a separate step: PTO watts are added into `P_aux_row`, then `E_battery = np.sum(P_battery * dt) / 3.6e6`. PTO energy alone: `np.sum(pto_row * dt) / 3.6e6`. A profile gives a fixed energy per stop (refuse: 0.14993 kWh); a constant gives W x standing (or driving) seconds.
- Cond (conditioning aux) stays on when the stop PTO is active (existing rule); decide the same for the drive part. [OPEN]
- Guard: two stops at the same distance merge their standing rows. The parser must reject or merge them.
- Overlap check for drive jobs (VECTO errors on a second trigger while one still runs) can only happen after the driver model, so it sits here.

## 6. Parser jobs created by this design

- Read `.vptoel` (stop) and `.vptor` (drive); skip header and `#` lines; **multiply kW by 1000 to get W**; check times are whole seconds (profile-time check); pass two lists.
- Map VDRI `<PTO>` column: 1 = `is_on` at that stop; 2 = drive part with one number (first `P_PTO` value, flagged); 3 = drive part with the `.vptor` profile; a flagged waypoint that is not a stop becomes a 0 s marker row.
- Build `is_on` as one 1/0 per waypoint from the stop table (single value = all stops).
- Pass `[]` when there is no profile; allow a profile **or** a constant per part, not both.
- Extend stop time = stop + PTO duration (VECTO default), or max(stop, PTO) with the route-level option "use stop time as PTO time" (non-VECTO, flagged).
- Checks: `pto_t` / `pto_w` same length, times increasing and whole seconds, no negative W; PTO efficiencies > 0; `is_on` one value per waypoint (never a single value: numpy would spread it silently); stop time >= stop profile length for every stop with PTO on.
- Reject two stops at the same distance.

## 7. Flags for reports (deviations / assumptions)

- Stop PTO placed in the middle of the stop, floor for odd seconds [ASSUMPTION].
- Sweeping power held constant (VECTO interpolates per waypoint by distance).
- Driving PTO: VECTO puts it on the motor shaft (through motor losses). HDEV uses a user efficiency field instead (default 1.0 = treated as electric, which skips motor losses and slightly underestimates energy; flag it when the default is used) [DECIDED 31 Oct, option A]. Same fields for stop and always-on PTO.
- Profile values held per second; VECTO averages drive-PTO power per step. Same for whole-second times; not tested for uneven steps [OPEN].
- Drive profiles are not cut at the next stop (VECTO behaviour).
- Driving PTO is a VECTO **engineering-mode** feature.

## 8. Profile library and Kiro research

Bob's idea: a sourced PTO profile library is part of the moat. Rules agreed:
- Every entry has source, link, page/table and a tag: **measured**, **simulated** or **rating**.
- A **rating** (max power) is not a usage profile: shown as such, never a silent default.
- Check the licence before copying numbers from papers.

Kiro's result (no licence-clear kW-vs-time profile found):
- Ban & Stipetic, IEEE ACEMP-OPTIM 2019 (refuse / concrete / hook-loader / vacuum): **simulated** cycles, paywalled, numbers not retrieved. Link **not found**; Bob to search the title (Ruđer Bošković Institute author copy, ResearchGate).
- MDPI Applied Sciences 2021, electric hydraulic pump for a waste compactor truck, CC BY: best reusable lead, but Kiro found it mostly cost/CO2; check for a measured power curve. https://www.mdpi.com/2076-3417/11/7/3033 (open PDF copy: https://iris.unicas.it/retrieve/bb5794fc-405d-4731-ab75-52fdcaa22ff1/applsci-11-03033.pdf, not opened by Claude).
- VTT/HSY refuse truck, measured, single vehicle: about 2.3 kWh/km total, about 1.4 driving; total energy only. https://www.vttresearch.com/en/project_news/refuse-truck-future-hums-along-quietly-without-emissions
- HECTOR (fuel-cell refuse trucks): whole-vehicle energy 1-2 kWh/km during collection; no body-only profile.
- Liebherr ETM mixer drum: **rating** 125 kW peak / 60 kW continuous. https://www-assets.liebherr.com/media/bu-media/lhbu-lmt/documents/truck-mixer/electric-truck-mixer-etm.pdf
- Eaton Bezares ePTO **rating** 40 kW continuous; Danfoss ED3 **rating** 44 kW DC / 43.6 kVA AC; Dulevo sweeper about 21 kW max (whole machine). Some of these came from search-result text, not opened datasheets, so verify before use.
- Caltrans electric sweeper study (task 4137): progress notes only, no numbers yet. https://dot.ca.gov/-/media/dot-media/programs/research-innovation-system-information/documents/research-notes/task4137-rns-05-26-a11y.pdf
- TRU electric power vs ambient for heavy trucks: not found. Zemo 2021 units are diesel; Warwick 2022 is a small electric van (1.5 kW compressor).
- Springer 2025 concrete mixer paper: the 282 kW is whole-vehicle traction, not drum power.
- Kiro's findings file (`/projects/sandbox/epto_research/epto_findings_for_Bob.md`) lists the rest of the links; Bob to paste it if needed.
- Consequence: **driving PTO has no sourced default; the user must enter it.** Only VECTO's refuse profile is an official default.
- EEA heavy-duty dataset: no PTO profiles in the part checked.

## 9. Pinned for later: assigning routes / PTO / payload per truck

- Not every truck has the same route or PTO. Users should save a route, PTO profile or payload profile with a name; it then appears in the dropdown next to VECTO templates.
- PTO input: simple option = one constant for the full route, or a VECTO template; advanced option = create or upload a profile and save it.
- Problem: doing this for every truck is long. Ideas (not decided): a project library of saved routes / PTO / payload profiles; a vehicle list where each truck picks from dropdowns; shortcuts "apply to all", "copy from truck 1", truck groups.
- Affects how the project JSON is saved and how the engine is called once per truck.

## 10. Open items

1. Consumption-engine PTO placement (section 5), one step at a time.
2. Driving PTO onto the motor shaft once the drivetrain maps exist (the efficiency field is the fallback until then).
3. Cond on-rule for the drive part (and still: always-on PTO, `EmOffPrev`).
4. Parser jobs (section 6).
5. PTO per-second averaging for fractional times; drive-PTO averaging for uneven steps.
6. Fridge-truck (TRU) helper (ATP model) and `PTO_always_on` per hour.
7. PTO shaft drag: waits for the drivetrain work.
8. Fetch the Kiro sources manually (section 8) and build the library entries.
9. Per-truck assignment design (section 9).
10. From earlier sessions, still open: review order `driver_model` (merged with drivetrain maps), `force_engine`, `P_aux` and HVAC helpers, `consumption_engine`, battery engine.
