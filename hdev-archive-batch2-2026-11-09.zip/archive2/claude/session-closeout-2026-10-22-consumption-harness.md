# HDEV session close-out: consumption engine, driver fix, test harness, validation (21–22 Oct 2026)

Hand-over for a new chat. Tags:

- **[VECTO]**: read from Bob's repo `mohgsaad-art/VECTO` (branch `IEPC-experiments`), file and lines named.
- **[SOURCE]**: external source, linked.
- **[DECIDED]**: Bob agreed.
- **[ASSUMPTION] / [SIMPLIFICATION]**: HDEV choice, must be flagged in reports.
- **[ILLUS]**: illustrative test value, not sourced.
- **[OPEN]**: not resolved.

Previous close-outs: `claude/session-closeout-2026-10-21-pto-driver.md` (PTO, P_aux, driver model code), `claude/session-closeout-2026-10-19-paux-hvac.md` (P_aux, SP, HVAC thermal plan, climate tables).
Test harness: `claude/hdev_test_harness_v1.5.py` (run in Colab after the engine cells).

---

## 1. Status

| Function | Status |
|---|---|
| `crosswind_engine` | done; **matches VECTO declaration CdxA curve exactly (0.0000 %)** when `dh = height/10`. The old "height-grid bug" (+2.5 %) does not show with this grid → treat as closed, parser must always pass `dh = height/10` |
| `payload_engine`, `pto_engine`, `force_engine`, `P_aux`, `SP_power_helper`, `ssm_total_w` | done, tested |
| `driver_model` | done + **mode fix this session** (section 3) |
| `consumption_engine` | **done this session** (section 2), tested end to end |
| `climate_lookup`, `HVAC_thermal` sections 2–6 | **not written by Bob.** A test-only reference exists in the harness (`ref_climate_lookup`, `ref_HVAC_thermal`, VECTO `SSMCalculate.cs`) |
| Parser (`defaults.py`) | to do (section 6) |
| Battery engine (Ri, SOC, charge limits) | not started |

---

## 2. Consumption engine (final)

Design [DECIDED]: one main function, **no thin helpers** (Bob: no redundant functions). Mapping onto 1 s rows happens inline, because rows only exist after the driver model; `payload_engine`/`pto_engine` run on waypoints before it. Weather enters here: hourly temperature → ρ, hourly W1/W2 (from `crosswind_engine` called with that day's hourly wind as `v_ref`) → CdxA_eff.

```python
def consumption_engine(T, S, V, M, dt,                                   # driver_model rows
                       k_lin, k_roll, k_rot, L, v_avg,                   # force_engine
                       m_vehicle, wp_s, payload_wp, beta,                # mass; payload_wp from payload_engine
                       t_start, T_amb_h, W1, W2, cdxa_v, CdxA0, p_air, R_air,  # weather per hour + crosswind tables + air constants
                       ES, PS, HVAC, SP, cond, PTO_always_on,            # P_aux outputs (HVAC scalar or per hour)
                       pto_1s, pto_on_col, pto_start_col,                # pto_engine outputs
                       motor_eff, inverter_eff, gearbox_eff, regen_effeiciency, v_no_regen, P_regen_max=None):

  T, S, V, M = (np.asarray(x) for x in (T, S, V, M))                              # driver rows
  wp_s, payload_wp = np.asarray(wp_s, dtype=float), np.asarray(payload_wp, dtype=float)
  T_amb_h, cdxa_v = np.asarray(T_amb_h, dtype=float), np.asarray(cdxa_v, dtype=float)
  pto_1s, pto_on_col, pto_start_col = (np.asarray(x, dtype=float) for x in (pto_1s, pto_on_col, pto_start_col))

  # --- 1. mass per row: payload forward-filled by distance (payload_engine writes it on start + stop waypoints only)
  has_pl = ~np.isnan(payload_wp)
  k_pl = np.searchsorted(wp_s[has_pl], S, side="right") - 1
  m_row = m_vehicle + payload_wp[has_pl][k_pl]                     # [kg]

  # --- 2. weather hour of each row
  hour = ((t_start + T) // 3600).astype(int)

  # --- 3. air density and CdxA_eff per row
  rho_row = p_air / (R_air * (T_amb_h[hour] + 273.15))             # ideal gas, fixed pressure (HDEV; VECTO fixed 1.188)
  cdxa_tab = CdxA0 * np.asarray(W1) + np.asarray(W2)               # VECTO AirdragDataAdapter.cs 59-87
  v_kmh = np.clip(v_avg * 3.6, cdxa_v[0], cdxa_v[-1])              # below 60 km/h uses the 60 value like VECTO
  j = np.clip(np.searchsorted(cdxa_v, v_kmh, side="right") - 1, 0, len(cdxa_v) - 2)
  w = (v_kmh - cdxa_v[j]) / (cdxa_v[j+1] - cdxa_v[j])
  cdxa_row = cdxa_tab[hour, j] * (1 - w) + cdxa_tab[hour, j+1] * w

  # --- 4. wheel power per row [W]
  P_wheel = m_row * k_lin + m_row**beta * k_roll + k_rot + rho_row * cdxa_row * L

  # --- 5. wheel power -> electric traction power [W]
  drivetrain_effeiciency = motor_eff * inverter_eff * gearbox_eff
  P_trac = np.where(P_wheel > 0, P_wheel / drivetrain_effeiciency, P_wheel * regen_effeiciency)
  P_trac = np.where(M == 3, 0.0, P_trac)                           # coasting: no motor torque (BatteryElectricMotorController.cs 44-46)
  P_trac = np.where((M == 4) & (V <= v_no_regen), 0.0, P_trac)     # braking <= 5 km/h: brakes only (same file 62-69; Constants.cs 323)
  if P_regen_max is not None:
      P_trac = np.maximum(P_trac, -P_regen_max)

  # --- 6. aux power per row [W]
  n = len(T)
  pto_row = np.zeros(n); pto_active = np.zeros(n, dtype=bool)
  for i in np.where(pto_on_col == 1)[0]:
      at_stop = np.where((V == 0) & np.isclose(S, wp_s[i], rtol=0, atol=1e-3))[0]
      if len(at_stop) == 0:
          raise ValueError(f"no standing rows found for stop at {wp_s[i]} m")
      k0 = at_stop[0] + int(pto_start_col[i]); k1 = k0 + len(pto_1s)
      if k1 > at_stop[-1] + 1:
          raise ValueError(f"PTO does not fit in stop at {wp_s[i]} m")
      pto_row[k0:k1] = pto_1s; pto_active[k0:k1] = True
  moving = V > 0
  HVAC_row = np.asarray(HVAC, dtype=float)[hour] if np.ndim(HVAC) else float(HVAC)
  P_aux_row = ES + PS + HVAC_row + SP * moving + cond * (moving | pto_active) + PTO_always_on + pto_row

  # --- 7. battery terminals
  P_battery = P_trac + P_aux_row                                   # DC/DC eff 1.0 (DeclarationData.cs 124); battery Ri loss -> battery engine
  E_battery = np.sum(P_battery * dt) / 3.6e6
  return P_wheel, P_trac, P_aux_row, P_battery, E_battery
```

Flags: ρ from ISO 2533 p = 101325 Pa, R = 287.05 [ASSUMPTION, VECTO has only fixed ρ = 1.188 (`DeclarationData.cs` 74)]; hourly values held for the whole hour; payload change on arrival; Cond on = moving or stop PTO [ASSUMPTION until `EmOffPrev`]; constant efficiencies (VECTO uses maps); regen cap `None` = uncapped.

Parser items found here: `Crr_eff` for β = 0.9 (`VehicleData.cs` 292–311, exponent `Physics.cs` 51): `Crr_eff = g^(β−1) Σ share·RRC·(share/(FzISO·n_wheels))^(β−1)`; payload t → kg; `cdxa_v` 60–130 km/h (`Constants.cs` 355–357); g = 9.80665 (`DeclarationData.cs` 72) also in `driver_model`.

---

## 3. Driver model fix (applied by Bob, verified)

Bug: when the speed cap held speed downhill or during look-ahead coasting, the row stayed mode 3 → consumption gave 0 power → braking energy not recuperated. VECTO switches to Brake (`DefaultDriverStrategy.cs` 1000–1006, 1031–1032, 1046–1052).

```python
# look-ahead coasting branch
              ca = coast_acc(v, k)
              a = min(ca, (max(target, v) - v) / dt)
              a = max(a, dec_max)
              mode = 3 if a >= ca - 1e-9 else 4
# overspeed branch
                  a = max(dec_max, min(ca, (v_os - v) / dt))
                  mode = 3 if a >= ca - 1e-9 else 4
```
Effect: LongHaul 78.06 → 77.32 kWh, Regional 73.64 → 72.37, Urban 61.10 → 60.30, Construction 68.26 → 66.81; −6 % downhill regen 0.014 → 3.71 kWh. Leftover 0.02–0.29 kWh/cycle = instantaneous vs step-average air drag in coasting [SIMPLIFICATION].
Remaining driver item: up to 1 km/h over target on 6 rows (Urban, Construction) when a 1 s row crosses waypoints a few m apart.

---

## 4. Test harness (`claude/hdev_test_harness_v1.5.py`)

Calls Bob's notebook functions. CONFIG at top. Downloads VECTO files from the repo, DMI key-less climateData API (each parameter from its nearest station with a full year; 2025: temp Landbohøjskolen 06186, wind Jægersborg 06181, radiation Københavns Toldbod 06187; 365/365 days complete).
Generic vehicle [VECTO]: `Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/BatteryElectricVehicle.vveh` (group 2, curb 4670 + body B2 1900 kg, ref payload 3019.6 kg from `Payloads.cs`, CdA 4.83). Efficiencies 0.95/0.95/0.98 [ILLUS], regen = same chain [ASSUMPTION].

Tests: T00 setup · T01 crosswind vs VECTO · T02/T04 PTO · T03 5 VECTO cycles · T05 payload · T06 energy identity · T07 regen rules + cap · T08 created waypoints · T09 edge cases · T10 temperature → ρ · T11 DMI coverage · T12 year run · T13 vs VECTO 2.2 12 t truck `.vmod` · T14–T16 HVAC thermal (reference) · T17 eActros-like vs Öko model · T18 sensitivities vs Öko. Graphs G01–G16.

Last full Colab result (v1.3): 71 PASS, 7 WARN (known), 0 FAIL. T17/T18 only dry-run here (same functions).

---

## 5. Findings

**Verified against VECTO**
- Crosswind CdxA exact; PTO 0.14993 kWh/stop × 96; rolling with β = 0.9 exact at 3 masses.
- T13 (VECTO's own 12 t truck, `VectoCoreTest/TestData/Integration/DeclarationMode/12t Truck`, VECTO 2.2, 2015): rolling +0.02 %, air +1.1 %, positive wheel energy −2.0 %, braking −15 %.

**Generic VECTO BEV results (VECTO-equivalent weather)**: LongHaul 0.77, Regional 0.72, Urban 0.60, Municipal 2.08 (PTO 55 % of gross), Construction 0.67 kWh/km. Year 2025 Regional: 69.5–82.5 kWh/trip, wind dominant (r = 0.91), temperature weak (r = −0.40).

**Regen**: we recover 88 % of the wheel braking energy (= the fixed chain efficiency, only limited below 5 km/h). That is 43 % of traction energy on Urban, 8 % Regional, 2 % LongHaul. VECTO limits regen by motor map, max generating torque (`ElectricMotor.cs` 485–509), battery charge power (`Battery.cs` 212–224), full battery → likely overestimated on Urban. Generic motor cap (250 kW) never reached.

**HVAC**: all earlier runs used VECTO constant HVAC (HVAC-Table "Default" × 1.25 = 187.5 W UD/MU, 250 W RD/LH/Constr). Thermal reference (cab placeholders): cold day +0.9 % (heat pump) to +4.4 % (electric heater).

**Comparison with measured eActros** [SOURCE] Öko-Institut, *Real-world data analysis of battery electric trucks operating in Germany* (19 eActros 300/400, 19 t GVW, regional delivery, mean speed 44 km/h). Regression C = 5.130·e^(−0.17 s) − 0.013 T + 0.018 w + 0.002 a + 0.709 (w = gross excl. body; R² 0.473); mean 0.96 kWh/km at 11–18 t, 19–21 °C.
- eActros-like HDEV (VECTO group 4: standard CdxA 8.4 m² [not measured eActros], height 4 m, body B4, 315/70 R22.5), 14.5 t, 20 °C: Urban 0.95, Regional 1.19 kWh/km vs measured mean 0.96 / regression ≈ 0.71 at 44 km/h. Regional dominated by CdxA (≈ 59 % air) and its 61 km/h speed; their regression has no aero term at speed.
- Sensitivities: weight +0.022 (RD) / +0.031 (UD) vs +0.018 kWh/km/t (rolling alone 0.019); climb matches if their events are ~25 km; **temperature only 7–28 % of measured −0.013 kWh/km/°C** even with electric heater → missing cold effects (battery heating/Ri, efficiency, tyre Crr in cold, pre-heating, door openings; part may be seasonal confounding).
- Net picture: mild weather at or above measured level; winter clearly under.

**Weather use**: year/day runs use real DMI hourly temperature (ρ, HVAC), wind (CdxA_eff), radiation (HVAC only). Not used: wind direction (VECTO averages directions), temperature effect on Crr, efficiencies, battery.

**Explanations given to Bob (for consistency)**
- CdxA: HDEV *calculates* CdxA_eff (crosswind correction for wind + speed) from CdxA0. CdxA0 itself is a vehicle input measured in the VECTO constant-speed test (Annex VIII); for the eActros it is not published, so the VECTO standard value 8.4 m² was used.
- Regen 88 % = share of the *braking* energy returned, not of total energy; braking energy is itself a fraction of traction.
- VECTO is a certification tool that does compute energy consumption (kWh/km) for BEVs on standard cycles at standard conditions; not a sizing tool, but its BEV run separates motor losses, recuperation and battery losses and is the best check of our absolute level and regen.

---

## 6. Open items / next steps (in order)

1. **Bob runs VECTO** on `Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/BEV_E2.vecto` (Urban + Regional, modal output on) → compare `.vsum`/`.vmod` with HDEV: kWh/km, regen, motor/battery losses.
2. Battery engine (OCV + Ri, SOC, charge-power limit → regen cap, full battery).
3. Motor map (`.vemo`) instead of constant efficiencies.
4. Bob writes `climate_lookup` + `HVAC_thermal` sections 2–6 (compare with harness reference). Needs cab inputs: surface, glass area, U/UA, volume, HVAC hardware, max heat/cool (currently placeholders/bus values).
5. Cold-weather gap: sourced temperature effects (battery, Crr, efficiency) or an optional flagged empirical term (Öko −0.013 kWh/km/°C minus modelled part).
6. Parser items (section 2 + 21 Oct list: stop extension, PTO checks, `dh = height/10`).
7. eActros data (CdxA, curb mass, tyres) via a VECTO customer information file if available.
8. Driver: 1 km/h overshoot rows; explain `interp1`, `decel_distance`, `coast_distance`, `driver_model` to Bob.
9. Still open from before: Cond rule with always-on PTO, `EmOffPrev`, motor drag loss.
