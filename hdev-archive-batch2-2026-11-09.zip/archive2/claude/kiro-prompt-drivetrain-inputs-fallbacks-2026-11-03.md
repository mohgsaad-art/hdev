# Kiro prompt: drivetrain inputs, safe fallbacks and the coasting-drag table (3 Nov 2026)

Repo: `mohgsaad-art/hdev`. New branch: `drivetrain-inputs-fallbacks-2026-11`. VECTO source reference: `mohgsaad-art/VECTO` (public; the default branch at commit `b8d6126` was read for this prompt).

Read first, in this order:
1. `claude/session-closeout-2026-11-03-driver-model-review.md` (in Bob's project; copied into the repo at `docs/research/driver-model-review-2026-11.md` context) — the driver model review and the drag-table result.
2. `claude/session-closeout-2026-10-22-validation-drivetrain-winter.md` — sections 3, 4 and 9: the standard-value loss-map tests and the agreed plan.
3. `claude/hdev_maps_test_v2.py` and `claude/hdev_addon_std_drag_v1.py` — the test code that built the standard-value maps and the drag table. These are **test scripts only**; nothing in them is in Bob's engine.

Write for Bob in plain English, short sentences. Bob is the only person named in anything you write.

---

## 0. Why this task exists (the problem, stated honestly)

1. On 22 Oct Bob decided to replace the consumption engine's fixed efficiencies (motor 0.95, inverter 0.95, gearbox 0.98) with **EU standard-value loss formulas** for gearbox, axle and motor (Reg. (EU) 2017/2400), and to take the driver model's coasting drag from the same formulas.
2. Those formulas still need **vehicle-specific inputs**: gear ratios, gearbox max input torque `Tmax_in`, axle type and ratio, motor full-load torque curve, rated speed, motor type, number of motors, motor-to-gearbox ratio (ADC), dynamic tyre radius `r_dyn`.
3. The same day, the open concern was recorded: **a fleet owner will not know most of these**, and Bob does not want hard-to-get user inputs. This was never resolved. On 3 Nov the drag table was agreed on the engine side (`drag_v`, `drag_F`, built by the parser) without the input problem being solved.
4. `Tmax_in` alone moved Regional consumption from 0.947 to 1.150 kWh/km (1940 vs 5500 Nm) in the 22 Oct test. So the fallback choice is not a detail.
5. Nothing in Bob's engine code uses standard values yet. Everything below is research and test work.

**Goal:** find out, from authentic sources only, (a) where each drivetrain input can come from, (b) what defensible fallback exists when the user does not have it, and (c) how much each fallback moves kWh/km — so Bob can decide on a minimal, realistic user input set that does **not** underestimate energy.

---

## 1. Rules

- **No invented numbers.** Every value you use or recommend must carry a source tag: `[VECTO file:line]`, `[REG annex/appendix/point]`, `[OEM doc + link]`, `[STUDY + link]`, `[TEST script + result]` or `[ASSUMPTION]`. An untagged number is a defect.
- Separate **facts** (read in a source) from **inferences** (your reasoning) in every section. Label inferences.
- If a document is paywalled, OCR-garbled or unreachable, say so and add it to a "Bob to fetch" list with the link. Do not fill the gap from memory.
- Do **not** change Bob's engine code (`src/engine/*`, the code of record in `tests/driver_model/reference_copy.py`). Use test-only copies, as in PR #21.
- VECTO line numbers: give the branch/commit you read. Note where v5.1.3 and the default branch differ.
- Keep each finding short. Tables over prose.

---

## 2. Part A — Inventory: what inputs do the standard-value formulas need?

For each drivetrain layout VECTO knows — **E2** (motor + separate gearbox), **E3** (motor on the axle), **E4** (motor in the wheel), **IEPC** (motor + gears in one unit, with or without separate axle) — list:

| Component | Formula / data VECTO uses when the part is not measured | Exact source | Inputs it needs | Units |

Cover at least: gearbox (Annex VI App. 8), axle (Annex VII App. 3), angle drive if any, motor loss map and drag curve (Annex Xb App. 8), IEPC (Annex Xb App. 9), ADC (motor-to-gearbox) loss, `r_dyn` from tyre size, battery is out of scope.

**Must resolve:**
- **A1. Axle formula conflict.** The 22 Oct test used `Td0 = 70 + 20·i` (constant, η 0.98), attributed to Annex VII App. 3 and "built like VECTO's generic axle". But VECTO's generic axle in `VectoCore/VectoCore/Models/GenericModelData/GenericTransmissionComponentData.cs` lines 71–124 with `Constants.cs` lines 403–417 (commit `b8d6126`) uses `Td0 = 52.5 + 15·i`, split half fixed and half speed-dependent (`× n_out / 150 rpm`), plus `|T|/0.98 − |T|`. Find out which formula the regulation actually gives for which axle type (single reduction, hub reduction, single portal, etc.), and where VECTO uses each (generic bus data vs declaration standard values). Quote the regulation point; if the knowledge-base text is garbled, get a clean copy (EUR-Lex consolidated text) or put it on the fetch list.
- **A2.** Same check for the gearbox standard value: confirm `Td0 = Td1000 = 0.005 × Tmax_in`, `fT` 0.04 indirect / 0.01 direct, against the regulation text and against VECTO's code that applies standard values (find the class; give file:line).
- **A3.** Motor: confirm Annex Xb App. 8 steps 6–7 (k_mn table, × 0.96, drag curve) against VECTO's code (`StandardValuesInputData`, `GenericBusElectricMotorData.cs`, `GenericBusEMBase.cs`). Note which inputs are strictly required (full-load curve? rated point? machine type ASM/PSM?).

---

## 3. Part B — Where can each input come from?

For every input in Part A, fill:

| Input | Who realistically has it | Public source? (spec sheet, CIF, type-approval docs, VECTO file) | Example values found (with links) | Hard for a fleet owner? |

Check specifically:
- **B1. OEM spec sheets** for the trucks already in the validation set (MAN eTGL, Renault E-Tech D12/D16, DAF XB Electric, Fuso eCanter, Volvo FL Electric, Mercedes eActros/eEconic): which drivetrain inputs do they publish (motor power/torque, number of motors, gearbox type and gears, axle ratio, tyre size)? One row per truck, with links.
- **B2. Customer Information File (CIF)** under Reg. 2017/2400 (and the amendment that added zero-emission vehicles): which drivetrain fields does a fleet owner receive with a certified truck? Quote the annex/part. This could be the realistic source for certified trucks.
- **B3. Tyre size → `r_dyn`:** confirm how VECTO derives `r_dyn` from the tyre dimension (file:line, the 0.867 factor and the circumference table) so a tyre size string is enough.
- **B4. `Tmax_in`:** is there any published source, rule or regulation point that defines the gearbox max input torque when only motor data is known? The 22 Oct test assumed `Tmax_in = motors × motor max torque × ADC ratio` = 2 × 485 × 2.0 = 1940 Nm `[ASSUMPTION]`. Find whether VECTO or the regulation states this, or anything else.

---

## 4. Part C — Does VECTO or the EU regulation already have a "generic vehicle" mechanism?

- **C1. Completed-bus generic data.** VECTO builds full drivetrain data from a few inputs for completed buses: `VectoCore/VectoCore/Models/GenericModelData/` (`GenericBusElectricMotorData.cs` — normalized ASM/PSM efficiency maps `Resources/Declaration/GenericBusData/EfficiencyMap_*_normalized.vmap` scaled by the rated point of the full-load curve; ADC loss fixed 0.98 if ratio = 1 else 0.96, lines ~30–45; `GenericTransmissionComponentData.cs` for axle and angle drive; `GenericBusIEPCData.cs`). Explain in plain words: what inputs it takes, what it fills in, which regulation point it implements, and whether the same approach can be used for trucks (legally it is a bus method — say so; technically, would it work?).
- **C2. Generic example vehicles.** `Generic Vehicles/Declaration Mode/PEV/` contains only `GenericVehicleE2` and `GenericIEPC` (1-speed and 3-speed, with/without axle). Confirm they are examples, not certified data. Check whether any other folder (Engineering Mode, test data) has E3/E4 examples.
- **C3. Segment/class tables.** Does VECTO's declaration data hold any per-vehicle-class default for drivetrain specs (ratios, motor size)? Check `Resources/Declaration/` (segment tables, generic bus parameters). Report what exists and what does not.
- **C4. Other standards** with generic e-truck drivetrain data that could serve as fallback (e.g. NREL FASTSim/Autonomie default truck components, JRC reports, ISO). Only include what you can link and quote.

---

## 5. Part D — Fallback options and their effect (tests)

Build a fallback ladder per input and test it. Proposed ladder to evaluate (change it if the sources say otherwise):

1. User's own value or OEM / VECTO component files (labelled "measured").
2. Value derived from data the user does know (e.g. motor torque × count × ADC → `Tmax_in`; tyre size → `r_dyn`) — labelled "derived", with the rule's source.
3. Generic/example value from VECTO (C1/C2) — labelled "VECTO example".
4. A conservative bound, only if a sourced range exists — labelled "conservative".

**Tests** (Regional, Urban, and Municipal with PTO; generic E2 at reference load; same harness setup as 22 Oct, VECTO-equivalent weather):

- **D1. Reproduce the 22 Oct baselines** with the standard-value maps (0.947 / 0.815 kWh/km, no drag; 0.971 / 0.844 with drag) to prove the setup is the same. VECTO `.vsum`: 1.050 / 0.840.
- **D2. Fix the drag table.** The 22 Oct drag formula used only the fixed parts (gearbox `Td0`, `Td1000`; axle `Td0`) and left out the gearbox `fT·|T_in|` term and the axle `(1/η − 1)·|T|` term. Rebuild it with losses read at the torque the drag itself puts through (as the 3 Nov close-out section 4.2 did for the E2 component files). Report the table (N vs km/h, 0–130 km/h) before and after, and the kWh/km effect.
- **D3. Apply the A1 axle result** (70 + 20·i vs 52.5 + 15·i split) and report the kWh/km effect.
- **D4. One-at-a-time sensitivity.** For each input, swap the E2 truth (component files) for each fallback rung; report kWh/km and % vs truth and vs VECTO. Inputs: `Tmax_in`, gear ratios, axle ratio, motor full-load curve, motor type, motor count, ADC ratio, `r_dyn`.
- **D5. All fallbacks together** for a "fleet owner knows only make/model, motor power and torque, tyre size" case. Report kWh/km vs truth.
- **D6. Direction check.** For each fallback: does it under- or over-estimate energy? Bob's rule: HDEV must not underestimate. Flag every fallback that underestimates.
- **D7. Drag table in the driver model.** Rerun the D2-of-PR-#21 comparison (coast %, seconds > 85 km/h, speed RMS, wheel energy vs VECTO) with the corrected standard-value drag table, using a test-only copy of `driver_model` with the agreed edits: `drag_v=(0.0,), drag_F=(0.0,)` defaults, `coast_acc` and `coast_distance` read `interp1(v, drag_v, drag_F)`, `g = 9.80665`, inputs already in m/s.

Every test: script in `docs/research/drivetrain-inputs-fallbacks-2026-11/`, results as CSV, summary table in the report.

---

## 6. Part E — Recommendation

Based on A–D, give Bob:

- **E1. Minimal user input set** that is realistic for a fleet owner (no niche data), with the fallback rung used for everything else.
- **E2. Error band** that set produces vs truth, per cycle, and its direction (under/over).
- **E3. Labelling:** which values must be shown to the user as "VECTO example" / "derived" / "assumption" in reports.
- **E4. Open questions** that need Bob's decision, each with 2–3 options and the trade-off in one line each.
- **E5. Where it lives:** confirm all of this is parser / `defaults.py` work; the engine only receives finished tables (`drag_v`, `drag_F`, loss maps). Do not propose engine changes beyond the agreed driver-model edits.

---

## 7. Deliverables

1. `docs/research/drivetrain-inputs-fallbacks-2026-11.md` — the report, sections A–E, every number tagged.
2. Test scripts + CSVs in `docs/research/drivetrain-inputs-fallbacks-2026-11/`.
3. A "Bob to fetch" list (title, link, why it is needed).
4. A 10-line plain-English summary at the top of the report: the answer to "what does a user have to enter, what do we fill in, and how wrong can it be?"
5. PR against `main`, no changes to `src/engine/`.
