# Kiro prompt — driver model review, follow-up fixes (3 Nov 2026)

Owner: Bob. Repo: `mohgsaad-art/hdev`. **Today is 3 November 2026.** Continue on the PR #21 branch. All rules from `claude/kiro-prompt-driver-model-review-2026-11-02.md` §0 still apply: no engine edits, no invented numbers, tag every statement, don't decide open design choices for Bob.

Claude (via Bob) checked PR #21 against the VECTO files in `docs/research/vecto/` and the VECTO source (`mohgsaad-art/VECTO`, branch `IEPC-experiments`). Several Part D/E conclusions don't hold yet. Fix them in this order, one PR commit per item, then update the review doc.

---

## F1 — LongHaul was simulated with the wrong vehicle

`BEV_E2.vsum` shows the LongHaul runs are a **different vehicle** from Regional/Urban:

| | LongHaul low | LongHaul ref | Regional/Urban low | Regional/Urban ref |
|---|---|---|---|---|
| Loading [kg] | 1303.9 | 9841.2 | 603.9 | 3019.6 |
| Total vehicle mass [kg] | 11273.9 | 19811.2 | 7173.9 | 9589.6 |
| CdxA [m²] | **6.13** | **6.13** | 4.83 | 4.83 |

So LongHaul for group 2 carries extra mass (11273.9 − 4670 − 1303.9 = 5300 kg, i.e. body + trailer is my reading, **not verified**) and a different CdxA. Kiro used the rigid-truck reference vehicle (9589.6 kg, CdxA 4.83) for LongHaul.

- Find in the VECTO source/resources exactly what the group-2 LongHaul vehicle is (segment table row, body/trailer, trailer axles, tyres, RRC, wheel inertia, CdxA and which crosswind parameter set: `VCDV_parameters` rigid-solo vs rigid-trailer). Cite file + line.
- Rebuild the LongHaul vehicle from those sources. If any trailer value can't be sourced, mark LongHaul `BLOCKED` — do **not** fall back to the rigid truck.
- Re-run every LongHaul number (Part D metrics, Part E, the 66.7 vs 106.1 kWh traction gap) or withdraw it.

## F2 — Low-load runs compared at the wrong mass

`measure_part_d.py` runs the HDEV driver at the reference mass for the **low-load** `.vmod` files too (line ~77). VECTO's low-load total is 7173.9 kg (Regional/Urban).
- Re-run the low-load comparisons with the driver at the low-load mass.
- Part E anchor (the actual question): driver trace built at **reference** mass, energy evaluated at **7173.9 kg** → compare with VECTO's low-load `.vmod`/`.vsum` energies (E_air, E_roll, positive/negative wheel energy). That shows the real cost of the fixed-mass assumption against VECTO, not only HDEV vs HDEV.
- Part E "empty" should also report 7173.9 kg (VECTO low load) next to 6570 kg (no payload).

## F3 — Coasting drag compared apples to oranges

The review compares VECTO's `(P_air + P_roll + P_gbx_loss + P_axle_loss)/v` on coast rows (2.0–3.4 kN) with the EU standard-value **drivetrain-only** drag (0.63–0.85 kN). Air and rolling resistance must not be in the VECTO figure; the electric-motor drag is missing from it.

Claude's check, `−P_wheel_in / v` on DriverAction Coast/Roll rows (= what the drivetrain pulls back at the wheels), median per band:

| Band [km/h] | Regional ref | Urban ref |
|---|---|---|
| 40–50 | 1.72 kN (n 6) | 1.43 kN (n 73) |
| 50–60 | 1.55 kN (n 47) | 1.52 kN (n 159) |
| 60–70 | 1.70 kN (n 24) | 1.62 kN (n 35) |
| 70–80 | 1.81 kN (n 9) | 0.98 kN (n 4) |
| 80–90 | – | 2.10 kN (n 10) |

- Reproduce this. Cross-check it against the sum of the component columns on the same rows (`P_gbx_loss`, `P_axle_loss`, and the motor side: `P_E2-em_mech`, `P_E2-em_loss`, `P_E2-em_inertia_loss`, `P_gbx_inertia`) and explain any difference.
- Build the VECTO drivetrain drag table vs speed (wheel side) from these rows, plus independently from the E2 component files (`GenericDrag_125kW_485Nm.vemd`, `Gear_2.vtlm`, axle `.vtlm`, ratios from `.vgbx`/`.vveh`) at zero torque in gear 2. Both should agree; report how close.
- Correct the review text: the comparison is VECTO example drivetrain ~1.4–2.1 kN vs EU standard value 0.63–0.85 kN.

## F4 — Run the decisive test D2 (and then D3–D8)

h1 ("drag magnitude is the dominant cause") is stated as confirmed, but D2 was never run. It is the test that separates drag from logic.
- **D2:** code of record with the VECTO drivetrain drag table from F3, passed in as drag force vs speed in both `coast_acc` and `coast_distance` (test-only wrapper in `variants.py`; the harness add-on's `DragPower` trick shows one way). Everything else unchanged.
- Report for Regional and Urban (reference and low load at the right mass): coast share, number and length of coast phases, start of each coast phase before its slowdown point, seconds above 85 km/h, max overspeed, speed RMS every 10 m, positive and negative wheel energy.
- **Reading:** if D2 lands close to VECTO, drag was the cause. If a clear gap remains, list where (phase by phase) and test h4–h7 against it.
- Then D3 (EU standard-value drag from `hdev_addon_std_drag_v1.py`; check its formulas against the regulation), D5 (g = 9.80665), D6 (step-average air drag in `coast_acc`), D7 (rotor inertia, only if F3/Q8 shows VECTO includes it in the coast step), D8 (all VECTO-sourced changes together). One change at a time.

## F5 — Time shares: use VECTO's own definitions

The review says the 22 Oct share comparison was "an artefact of VECTO's non-existent cruise code". That's only half right. The `.vsum` shares are not DriverAction counts. VECTO computes them in `VectoCore/VectoCore/OutputData/ModalDataContainerExtensions.cs` (branch `IEPC-experiments`, lines ~60–112 and ~528–554):
- acceleration: `acc > 0.125 m/s²`; deceleration: `acc < −0.125`; cruise: `v ≥ 0.1 km/h` and `−0.125 ≤ acc ≤ 0.125`; stop: `v < 0.1 km/h` — all time-weighted with `dt`;
- coasting and braking: by `DrivingBehavior` (not DriverAction).

Tasks:
- Re-read these lines on the stable branch / 5.1.6 if available and cite.
- Apply the same threshold rules to HDEV rows and put them next to the `.vsum` values (Regional ref: accel 7.01, decel 6.96, cruise 73.35, stop 12.68, coasting 1.28, braking 5.66 %).
- Find how `DrivingBehavior` is assigned (it is a different enum from `DrivingAction`) and how it relates to HDEV modes 3 and 4.
- Rewrite the Metric 2 text accordingly. Note VECTO computes shares over its variable simulation steps, not the 1 Hz output.

## F6 — `P_brake_in` resolved

`Σ P_brake_loss · dt` = 0.083 kWh (Regional ref), which equals `.vsum` `E_brake` 0.0828 kWh, so **`P_brake_loss` is the friction-brake energy**. `P_brake_in` is the power flowing into the brake component, not braking energy. Confirm in the source, then report VECTO's split of negative wheel energy into regen and friction braking.

## F7 — Corrections to the review document

Update the summary, Part D, Part E, the hypothesis ranking, proposed-change ranking (P3) and deviation register so they match F1–F6. In particular withdraw or redo: all LongHaul numbers, the 2.0–3.4 kN drag figure, "h1 confirmed", the "false alarm" wording, and Part E's LongHaul +11.5 %.

## F8 — Graphs

Overlay VECTO `v_act` on the speed-vs-distance stretches (downhill overspeed, look-ahead coast, stop) for D1, D2 and D8.

---

## Deliverables
Updated `docs/research/driver-model-review-2026-11.md`, scripts and tests on the PR #21 branch, and a PR comment listing: what changed per F-item, every withdrawn number, and the D2 verdict in one sentence.
