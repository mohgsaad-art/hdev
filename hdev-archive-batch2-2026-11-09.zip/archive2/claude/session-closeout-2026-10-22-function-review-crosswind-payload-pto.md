# Session close-out — function-by-function review: crosswind, payload, PTO (22–26 Oct 2026)

In a new chat, read this file first. Related files:
- `claude/ui-input-list-2026-10-26.md` (the full input list made in this chat)
- `claude/session-closeout-2026-10-22-vecto-bev-comparison.md` (previous close-out)
- `claude/crosswind-verification-2026-10-06.md`

VECTO reference: repo `mohgsaad-art/VECTO`, branch `IEPC-experiments`.

## 0. Goal of this review

- Go through each engine function and check whether anything major or minor is missing for realism.
- Validate every choice against VECTO, EU regulations, ISO, NREL or another established standard, so each choice points to a valid source.
- Standard values and fallbacks go in `defaults.py` or the parser. The functions stay physics only.
- Heavy testing goes to Kiro, but only when a test is genuinely useful. Claude writes the prompt.
- Inputs will later be split into a client UI and an OEM UI on the **same engine**. Only the UI differs.

---

## 1. `crosswind_engine` — DECIDED: stays as it is

### Checked against VECTO
- The function does the same physics as `AirdragDataAdapter.cs` (lines 20–89): wind grows with height, it is averaged over height slices and wind directions, and the extra drag at an angle comes from the a1/a2/a3 curve.
- In this branch, VECTO builds the table from 60 to **130** km/h, in 5 km/h steps (`Constants.cs`, lines 355–357). Use 60–130 in the parser.
- VECTO constants: 3 m/s at 4 m, Hellmann exponent 0.2 (`Physics.cs`, lines 56–66). VECTO gives no citation for 0.2.

### Ideas looked at
| Idea | Result |
|---|---|
| Wind direction per row (VECTO `CrosswindCorrectionVAirBeta.cs` mode) | **Parked.** DMI has `wind_dir` (10 m, 10-min mean), but VDRI cycles have no road heading. Only useful for GPS routes. Estimate: ~10–15 lines in the consumption engine. |
| Eurocode terrain wind profile (EN 1991-1-4, Table 4.1) | **Not adopted.** See the Kiro test below. |
| OEM measured angle → extra-drag table (VECTO engineering mode `ReadCdxABetaTable`) | **Later, OEM side.** It is a list of (angle °, extra drag m²) pairs, or the OEM's own a1/a2/a3. US certification only measures to ±9° (40 CFR 1037.525). |
| 10° yaw clamp | Stays as decided 6 Oct, stated in every report. |

### Kiro test: Eurocode terrain profile
- The formulas checked out as correct against EN 1991-1-4 (Eq. 4.4, Eq. 4.5, Table 4.1; base wind at 10 m in category II).
- **Effect on total kWh/km:** under 1 % with category II. Up to −2.7 % on Long Haul with category IV.
- **Station category:** changing it alone moves the result by up to +4.4 %. That's the biggest lever.
- **Verdict:** it swaps one assumption (the 0.2 exponent) for **two** (route terrain and station terrain). It is a building standard used for something it wasn't written for, and no truck-height wind measurements show either rule is better.
- Kiro's run used ERA5 wind and a guessed mass. Use it only as a sensitivity check, not in reports.
- A sensitivity run is still possible today through the existing `wind_exp` argument.

### Small items for the parser
- No 0 km/h in the speed list (it divides by zero).
- Speed grid up to 130 km/h (relevant for coaches).
- Optional Kiro test: the cost of holding the 60 km/h value below 60 km/h on an urban cycle.

---

## 2. `payload_engine` — no physics missing

- Payload is mass, and it changes only at stops. That's realistic.
- The tyre effect is already covered by `m^β` in the consumption engine.

**To do**
- **Parser:** cap payload between 0 and max payload, where max payload = gross vehicle weight − curb mass − trailer curb mass. Same as VECTO, `TruckSegments.cs`, lines 233–234 and 276–277.
- **Engine guard:** `shape="linear"` without `payload_end` should give a clear error.
- **Keep flagged:** the linear shape stays labelled as an HDEV assumption. There is no standard for it; VECTO always uses a constant payload.

**Open decision (Bob):** the default payload for sizing.
- VECTO reference payload: 10, 50 or 75 % of max, depending on class, from `Payloads.csv`.
- Or max payload (conservative).

---

## 3. PTO — reviewed, plan agreed

### PTO types (Bob's scheme, agreed)
| Type | Constant | Profile |
|---|---|---|
| While stopped | ✔ (one-value profile) | ✔ (done, `pto_engine`) |
| While driving | ✔ (= sweeping, held from a start to an end waypoint) | ✔ (e.g. compaction, runs for its own duration) |
| Always on | ✔ (one W number; fridge model per hour later) | – |

- This covers all VECTO PTO modes (`DrivingCycleData.cs`, lines 306–312): stop, road sweeping (`RoadSweeperAuxiliary.cs`) and while driving (`PTODriveAuxiliary.cs`, lines 37–78).
- Driving PTO uses the same `t`/`W` profile shape as stop PTO.
- **How it ends:**
  - one value → held until the end waypoint (sweeping);
  - several values → runs once for the profile's own duration.
- **Design shown:** two new waypoint columns ("drive PTO start" and "drive PTO end") plus one driving profile. The engine lays it on the moving rows. Not yet confirmed by Bob, and no code yet.
- **Small deviation to flag:** VECTO interpolates sweeping power by distance between waypoints. HDEV holds it (forward fill). The result is identical when the value is constant.
- **Flag:** user PTO values are taken as electric W (efficiency 1.0).

### Item status
| # | Item | Where | Status |
|---|---|---|---|
| 1 | Guard: PTO start ≥ 0 | `pto_engine` | **Done** (code below) |
| 2 | `pto_t`/`pto_w` same length, increasing whole seconds | parser | When writing the parser |
| 3 | PTO while driving and sweeping, off by default | consumption engine + waypoint flags | Next design step |
| 4 | PTO shaft drag | consumption engine | **Waits for the drivetrain work** (see below) |
| 5 | Fridge truck (reefer) physics, off by default | new helper like `HVAC_thermal` | After 3 |

### Item 1: code added to `pto_engine` (just before `return`)
```python
  bad = np.where(pto_start_col < 0)[0]    # stops shorter than the PTO profile (NaN rows, PTO off, are skipped)
  if len(bad):
    raise ValueError(f"PTO ({pto_dur:.0f} s) is longer than the stop at waypoint(s) {bad.tolist()}; the parser must extend these stops")  # guard: otherwise PTO lands on driving rows before the stop
```
Test: `pto_engine([0, 100, 0, 300], 1, [0, 60, 120], [5000, 3000, 0])` should raise.

### Item 4: what VECTO does for a BEV (checked)
- It uses the **torque loss** column of `PTO-tech.csv` (Nm), not the W column (`PowertrainBuilderBase.cs`, lines 352–354).
- The loss sits on the motor shaft, between the motor and the gearbox (`PowertrainBuilder.cs`, lines 757–761).
- It is only active while a gear is engaged and the shaft turns (`PEVPTO.cs`, lines 64–78). Loss = torque × motor speed.
- No gearbox means no PTO loss. VECTO throws an error if a PTO type is given anyway (`PTODataAdapter.cs`, lines 64–66).
- → It needs motor speed (gear and axle ratios), so it comes after the drivetrain standard values.

### Item 5: fridge truck model (agreed as an option)
**Kiro research results**
- `K = W / (S × ΔT)` is exactly the ATP definition (Annex 1, Appendix 2).
- S = √(inner surface × outer surface), per ATP.
- K limits: IN ≤ 0.70, IR ≤ 0.40 W/m²·K.
- The 1.75 factor is a sizing margin, not a running-power multiplier.
- OEM sheets give capacity at about 30 °C ambient, but rarely COP at several temperatures.
- Door openings can be about 34 % of the load on an urban delivery truck (one Brunel thesis).

**Model**
- Outside warmer than set temperature → cooling: heat leak ÷ cooling COP.
- Outside colder than set temperature → **heating**: heat leak ÷ heating efficiency.
- Heating is realistic: Thermo King sells a heating option (about 6 kW) plus a 1,900 W electric heater bar on electric standby.
- If the heating efficiency is missing → fall back to 0 W in heat mode, flagged as an underestimate in winter (our choice).

**Inputs**
| Input | Source | If missing |
|---|---|---|
| K | ATP certificate | ATP class limit (0.40 or 0.70), conservative, flagged |
| Inner + outer box dimensions | spec sheet | required |
| Set temperature | client | required |
| COP points (outside temp, COP) | OEM | use the constant-W path instead |

**Rejected Kiro suggestions** (they would be new assumptions)
- A default COP of 1.5. COP is required instead.
- A 1.3× door uplift. Doors are left out, and urban multi-drop results are labelled "lower bound". Possible later sources: USDA TB-1375, Int. J. Refrigeration 2015.

**Knock-on:** `consumption_engine` needs to accept `PTO_always_on` per hour, the same way `HVAC` works.

### Item 3: sources found by Kiro (possible reference profiles later)
- Refuse e-PTO load cycles: Ban & Stipetić, IEEE ACEMP-OPTIM 2019.
- Electric sweepers: Caltrans field studies.
- Not usable: the "30–40 % sweeping share", which comes from a company website.

---

## 4. UI input list
- Made on 26 Oct and saved as `claude/ui-input-list-2026-10-26.md`.
- It lists every user input per section (route, payload, vehicle, tyres, drivetrain, aux, HVAC thermal, PTO, weather), with who enters it (client / OEM / standard default), the default, and which argument it feeds.
- It also lists the automatic values, the hidden constants and the planned inputs.

**Code checks flagged there**
- `P_aux` default `HVAC_eff = 1.25` must be 1.0 in thermal mode.
- `PTO_always_on` must become per hour.
- Payload is entered in tonnes and the engine uses kg; convert in the parser.

---

## 5. Next steps (one at a time)
1. Bob confirms the driving-PTO design (two waypoint columns plus one profile), then codes item 3.
2. Fridge helper (item 5).
3. Parser items: PTO checks, payload cap, crosswind speed grid, and the reference vs max payload decision.
4. Continue the function-by-function review: next is `driver_model`, then `force_engine`, `P_aux` and its helpers, and `consumption_engine`.
5. PTO shaft drag after the drivetrain standard-values work.

## Sources used
- VECTO: `AirdragDataAdapter.cs`, `CrosswindCorrectionVAirBeta.cs`, `CrosswindCorrectionCdxALookup.cs`, `Constants.cs`, `Physics.cs`, `TruckSegments.cs`, `Payloads.cs`, `DrivingCycleData.cs`, `PTODriveAuxiliary.cs`, `RoadSweeperAuxiliary.cs`, `PEVPTO.cs`, `PTODataAdapter.cs`, `PowertrainBuilder.cs`, `PowertrainBuilderBase.cs`, `PTO-tech.csv`
- [NBN EN 1991-1-4](https://www.buildwise.be/media/5mzdt0am/nbn-en-1991-1-4.pdf)
- [40 CFR 1037.525](https://www.law.cornell.edu/cfr/text/40/1037.525)
- [DMI Meteorological Observations](https://www.dmi.dk/friedata/dokumentation/meteorological-observations-data)
- [ATP amendment, Trb. 2013, 71](https://zoek.officielebekendmakingen.nl/trb-2013-71.html)
- [Thermo King T-Series Heating Option](https://europe.thermoking.com/truck/t-series/t-series-heating-option)
