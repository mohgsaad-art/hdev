# HDEV session close-out: VECTO BEV_E2 run vs HDEV, aux fix, overspeed/coast-drag root cause, temperature evidence (22 Oct 2026, afternoon)

Hand-over for a new chat. Same tags as earlier close-outs:

- **[VECTO]**: read from Bob's repo `mohgsaad-art/VECTO` (branch `IEPC-experiments`), file + line given, or from Bob's own VECTO 5.1.6 run files.
- **[SOURCE]**: external source, linked.
- **[DECIDED]**: Bob agreed.
- **[ASSUMPTION] / [SIMPLIFICATION]**: HDEV or comparison choice, must be flagged in reports.
- **[CALC]**: Claude's own arithmetic from sourced inputs (not a measured value).
- **[OPEN]**: not resolved.

Previous close-out (same day, morning): `claude/session-closeout-2026-10-22-consumption-harness.md` (consumption engine code, driver mode fix, harness v1.5, Öko comparison). Earlier: `claude/session-closeout-2026-10-21-pto-driver.md`, `claude/session-closeout-2026-10-19-paux-hvac.md`.

Current harness: **`claude/hdev_test_harness_v1.7.py`** (v1.6 kept for reference only).

---

## 0. Working rules confirmed this session

- **[DECIDED] Validation workflow:** the Colab harness only produces HDEV outputs. VECTO files never go into Colab. Bob runs the harness, sends `hdev_outputs.zip` + the SUMMARY block, and Claude does the comparison against the VECTO `.vsum`/`.vmod` in its own workspace.
- Answers must be plain, short tables, with no rabbit holes. Bob was frustrated by long and complex replies; lead with the answer.
- Don't treat a single study (e.g. Öko-Institut) as truth; give several sources.

---

## 1. VECTO run (Bob, 22 Oct 2026)

- **Tool:** VECTO-RC 5.1.6-RC, Declaration Mode, on Windows.
  - The first start failed with HRESULT 0x80131515 (Windows blocked the downloaded DLLs). Fixed with `Get-ChildItem ... -Recurse | Unblock-File`.
- **Job:** `Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/BEV_E2.vecto`. Options: "Write modal results" and "Modal results in 1Hz" ON.
- **Output folder (Bob's PC):** `C:\Users\mdib2\Desktop\vecto e2\`. Files: `BEV_E2.vsum` plus `BEV_E2_<cycle>_<LowLoading|ReferenceLoad>_1Hz.vmod` for LongHaul, RegionalDelivery and UrbanDelivery (6 runs), plus XML reports.
  - The "XML validation of manufacturer record failed: CertificationMethod NOT CERTIFIED" message only concerns the report (generic axle not certified). It doesn't affect the energy results.
- **Vehicle facts [VECTO]:**
  - Group 2; curb 4670 kg + body 1900 kg.
  - Reference loading 3019.6 kg, total 9589.6 kg (same as HDEV). Low loading 603.9 kg.
  - CdxA 4.83.
  - AMT, 2 gears (3.86 / 1.93), axle 2.59.
  - 2 × 125 kW E2 motors with ADC ratio 2.0. The `.vsum` reports "EM total rated power 500 kW" [OPEN: not checked why 500].
  - Battery 324 Ah.
- **Declaration mode starts and ends at 50 % SoC** (`.vsum`), not the `InitialSoC: 80` in the `.vveh`.
- **LongHaul is not comparable:** VECTO group-2 LongHaul adds a trailer (2 trailer axles, loading 9841 kg, CdxA 6.13, total 19.8 t). HDEV ran it as a rigid truck.
- **Sign rules in the `.vmod` (checked):**
  - `P_wheel_in` > 0 = traction.
  - `P_E2-em_el` < 0 = motor drawing power; > 0 = generating.
  - `P_REESS_T` < 0 = battery discharging.
  - `DriverAction`: 0 Halt, 2 Roll, 4 Coast, 6 Accelerate, −5 Brake (`Driver.cs` 51–58).
  - 1 Hz rows are time averages of VECTO's steps. The vmod sums match the vsum totals to 0.01 kWh (air, roll, gearbox, axle, motor, brakes).
- **VECTO results, reference load [VECTO `.vsum`]:**
  - Regional: `EC_el_final` 1.062 kWh/km (106.2 kWh/trip); at battery terminals 1.050.
  - Urban: 0.853 kWh/km (85.2 kWh); terminals 0.840.
  - LongHaul (with trailer): 1.550.
  - Low loading: Regional 1.0022, Urban 0.7566.

---

## 2. Aux fix (harness error, not engine error)

- **Cause:** harness v1.5 used different aux *technology rows* than the `BEV_E2.vecto` job.
- **Fixed in v1.6/v1.7 [VECTO]:**
  - **PS** "Vacuum pump + elec. driven": `PS-Table.csv` line 39, `_el` columns. Values: LH 237, RD 200, UD 162, MU 162, Constr 162 W, used as-is for a fully electric PS (`HeavyLorryAuxiliaryDataAdapter.cs` 139–143). Was "Small + elec. driven" at 750/813 W.
  - **Steering** "Full electric steering gear": `SP-Tech.csv` line 9 (U+F 0 / B 0.143 / S 1.429) × `SP-Table.csv` group 2, then × 0.7 (`HeavyLorryAuxiliaryDataAdapter.cs` 220; `DeclarationData.cs` 123 AlternatorEfficiency 0.7). Gives 23.0 W Regional and 32.0 W Urban; VECTO's `.vmod` shows 23.0 / 32.0 W while moving, 0 standing.
- **Already matching:**
  - ES 1000 W electric (VECTO vmod 1000 W).
  - HVAC 250 / 187.5 W (HVAC-Table Default × 1.25).
  - Cond 600 / 550 W.
- **Cond rule [VECTO]:** constant W whenever *any motor is not EmOff* (or ePTO on) (`Conditioning.cs` 83–91). In the vmod it is 0 when standing and when the EM is off (coasting). HDEV rule: on when moving or during stop PTO. The difference is small: Regional 0.856 vs 0.838 kWh, Urban 1.554 vs 1.481 kWh. Ties to the old open item `EmOffPrev`.
- **After the fix, aux totals match VECTO:** Regional 3.26 vs 3.24 kWh (+0.7 %), Urban 6.75 vs 6.63 kWh (+1.9 %; mostly Cond plus 1 % longer trip).
- **HDEV kWh/km after the aux fix (VECTO-equivalent weather):** Regional 0.712 (was 0.724), Urban 0.574 (was 0.603).

---

## 3. HDEV vs VECTO, part by part (reference payload, kWh per 100 km trip)

Source: Bob's `hdev_outputs.zip` (harness v1.7 run) vs his `.vsum`/`.vmod`. The comparison script ran in Claude's workspace.

| Part | VECTO RD | HDEV RD | VECTO UD | HDEV UD |
|---|---|---|---|---|
| Trip time [s] | 5885 | 5896 (+0.2 %) | 13489 | 13625 (+1.0 %) |
| Standing time [s] | 736 | 746 | 3245 | 3349 |
| Air drag | 39.49 | 39.45 (−0.1 %) | 16.50 | 16.14 (−2.2 %) |
| Rolling | 18.93 | 18.93 (0.0 %) | 18.93 | 18.93 (0.0 %) |
| Grade | 0.19 | 0.19 | 0.26 | 0.26 |
| Wheel energy, driving | 67.21 | 65.66 (−2.3 %) | 79.59 | 78.58 (−1.3 %) |
| Wheel energy, braking | 8.60 | 7.08 (**−18 %**) | 43.90 | 43.25 (−1.5 %) |
| Motor electric in, driving | 106.64 | 74.12 | 109.19 | 88.54 |
| Regen returned (electric) | 4.89 | 6.18 | 31.84 | 37.88 |
| Regen share of wheel braking | 57 % | 87 % | 73 % | 88 % |
| Drivetrain losses total | 43.06 | 9.37 | 40.79 | 15.18 |
| of which gearbox + axle (VECTO) | 23.03 | – | 22.39 | – |
| of which motor (VECTO) | 20.02 | – | 18.40 | – |
| Battery loss | 0.92 (vmod) / 0.96 (vsum) | 0 (not built) | 1.03 / 1.07 | 0 |
| Aux total | 3.24 | 3.26 | 6.63 | 6.75 |
| **kWh/km at battery terminals** | **1.050** | **0.712 (−32 %)** | **0.840** | **0.574 (−32 %)** |

**What-if: HDEV run with VECTO's own trip-average efficiencies from the `.vsum`**
- Values used:
  - Regional: motor drive 0.8228, gen 0.8663, gearbox 0.8193, axle 0.9361.
  - Urban: motor drive 0.8675, gen 0.9209, gearbox 0.8852, axle 0.9525.
- [ASSUMPTION] averages used as constants; inverter set to 1.0 (assumed included in VECTO's motor map); same gearbox × axle average for regen.
- **Result:** Regional 1.025 kWh/km (**−2.4 %** vs VECTO), Urban 0.806 (**−4.1 %**).

**Conclusions**
1. **Wheel physics matches VECTO:** rolling is exact, air is within 0–2 %, grade is exact, positive wheel energy is within 1–2 %.
2. **The 32 % gap is almost all drivetrain efficiency.**
   - HDEV's constant 0.95 × 0.95 × 0.98 (wheel/electric about 0.886) vs VECTO's per-second maps (wheel/electric 0.630 Regional, 0.729 Urban).
3. **Why VECTO's gearbox loss is so big [VECTO]:**
   - The generic `Gear_1.vtlm`/`Gear_2.vtlm` have a fixed drag loss even at zero torque (e.g. 44 Nm at 2000 rpm, about 50 Nm at 2500 rpm, plus about 4 Nm per 100 Nm).
   - At the low motor-side torques of the E2, the drag dominates: average gearbox efficiency 0.82 (Regional) / 0.89 (Urban).
   - The loss maps are read per second by `TransmissionLossMap.cs`.
   - These are *generic* maps sized for diesel input torques up to 5500 Nm. They may be pessimistic for a real e-truck gearbox, so VECTO generic is not "truth" for a real truck.
4. **Regen overestimated in HDEV:** fixed 88 % of wheel braking energy vs VECTO 57 % (Regional) / 73 % (Urban). That is +6 kWh/trip on Urban (about 7 % of the trip), about 1 % on Regional.

**Check vs Öko-Institut formula at E2 conditions** [CALC; ASSUMPTION: 7.7 t excl. body is below Öko's 11–18 t range]
- Inputs: avg speed 61.2 / 26.7 km/h, 24 °C (= VECTO ρ 1.188), climb 7.3 / 9.9 m.
- Result: Regional 0.55, Urban 0.61 kWh/km.
- So real eActros trucks use *less* than VECTO's generic truck; HDEV sits between the two.

---

## 4. Overspeed / coasting difference: ROOT CAUSE FOUND

**Symptom**
- HDEV reaches 87.0 km/h on Regional (177 rows > 85); VECTO stays at 85.0 at 74–85 km/h targets.
- HDEV coasts 7.8 % of the time (VECTO 1.3 %).
- HDEV braking wheel energy on Regional is −18 %.

**VECTO overspeed is on in declaration [VECTO]:** `DriverDataAdapter.cs` 48–53 (Enabled = true); `DeclarationData.cs` 731–733 (MinSpeed 50 km/h, AllowedOverSpeed 2.5 km/h). `MaxVehicleSpeed` is not limiting for E2: [CALC] about 155 km/h from `.vemo` max 9845 rpm / ADC 2 / (1.93 × 2.59) × r_dyn (`Vehicle.cs` 113–132, `ElectricMotor.cs` 62).

**Rule [VECTO] `DefaultDriverStrategy.cs` 1097–1110 (FirstAccelerateOrCoast)**
- When speed ≥ target and overspeed is allowed, VECTO tries **Coast** toward target + 2.5.
- If the coast response gives **deceleration** and speed ≤ target, it switches to **Accelerate at target**, i.e. it holds the target speed with the motor (FAOC-2).

**Coasting in VECTO has drivetrain drag [VECTO]**
- In Coast/Roll the BEV controller returns null (`BatteryElectricMotorController.cs` 43–46).
- `ElectricMotor.cs` 289 then sets EM torque = drag curve + inertia. Drag curve `GenericDrag_125kW_485Nm.vemd`: −6.06 Nm at 0 rpm to −30.31 Nm at 7364 rpm (motor shaft).
- Gearbox and axle loss maps still apply at zero torque.

**Coast drag measured from Bob's `.vmod` coast rows** (DriverAction 4, all three cycles; median P_wheel_in / v):

| Speed band | Drag at wheels |
|---|---|
| 40–50 km/h | 1.43 kN |
| 50–60 km/h | 1.53 kN |
| 60–70 km/h | 1.63 kN |
| 70–80 km/h | 1.94 kN |
| 80–90 km/h | 2.05 kN |

**Consistency check [CALC]**

| Slope | Slope push beyond air + rolling | Coast drag | Result | VECTO data |
|---|---|---|---|---|
| −4 % at 84 km/h | ≈ 1.5 kN | ≈ 2.05 kN | coast would decelerate → VECTO holds 84 with the motor | 35–39 km: DriverAction 6, v = 84.0, P_wheel negative |
| −6.3 % at 68 km/h | ≈ 4.2 kN | ≈ 1.8 kN | coast accelerates → VECTO overspeeds | 16.5–17 km: v 70.5 |

- VECTO does overspeed on 95 rows in Regional (max +2.5 km/h), on steep slopes at lower targets only.

**HDEV:** coasting has **zero drivetrain drag** (P_trac = 0, nothing at the wheels). So it coasts and overspeeds where VECTO holds speed, and it also over-extends look-ahead coasting before stops.

**Fix needed [OPEN, not designed yet]**
1. Driver model coast acceleration must include the drivetrain drag force at the wheels.
2. Consumption: coast rows count that drag as a loss.

Ties to the old open item "motor drag loss". Bob must decide how to parametrise it: VECTO drag curve + gearbox/axle zero-torque loss, or a simpler drag-vs-speed input.

**Also seen:**
- **Standing time:** VECTO 736 / 3245 s vs HDEV 746 / 3349 s (Regional / Urban). HDEV equals the cycle stop times exactly (T03 PASS). Likely VECTO's 1 Hz rows averaging speed in the second the truck stops or starts. [ASSUMPTION, not verified]
- **Speed trace vs distance (every 10 m):** Regional mean −0.07 km/h, RMS 1.28; Urban mean −0.45, RMS 2.00.
- **Time shares (stop / accel / cruise / coast / brake %):**
  - Regional: VECTO 12.7 / 7.0 / 73.4 / 1.3 / 5.7; HDEV 12.7 / 7.3 / 63.8 / 7.8 / 8.4.
  - Urban: VECTO 24.8 / 19.6 / 36.8 / 1.7 / 17.3; HDEV 24.6 / 21.7 / 29.1 / 5.2 / 19.5.
  - [ASSUMPTION] VECTO's share definitions may differ from HDEV modes.

---

## 5. Temperature and HVAC: clean answers given to Bob

**VECTO has no temperature effect at all:** fixed ρ 1.188 (`DeclarationData.cs` 74) and constant HVAC. So HDEV cannot be "low vs VECTO" on temperature; it is the only one that responds.

**HVAC thermal (harness reference model, placeholder cab) vs VECTO constant 250 W (Regional)** [ASSUMPTION: placeholder cab 20 m² surface, 4 m² glass, bus U-value 3.0, 6.5 m³ volume, bus 5 kW limits]:

| Outside temp | Electric heater (HD9) | R-744 heat pump (HD1) | vs VECTO 250 W |
|---|---|---|---|
| −10 to −5 °C | 1524 W | 715 W | higher |
| −5 to 0 °C | 1208 W | 510 W | higher (2–5×) |
| 0 to 5 °C | 936 W | 357 W | higher |
| 5 to 10 °C | 622 W | 217 W | higher / similar |
| 10 to 15 °C | 261 W | 93 W | similar / lower |
| 15 to 20 °C | 55 W | 42 W | lower |
| 20 to 25 °C | 119 W | 118 W | lower |
| 25 to 35 °C | 253 W | 277 W | similar |

- **Why the yearly totals barely differ:** HVAC is tiny next to driving, which averages about 40 kW. The heater at −5 °C adds about 2 kWh to a 71 kWh trip (about 3 %).
- **HDEV year results with DMI 2025 weather (T16, v1.7 run):**

| Cycle | HVAC mode | Year mean kWh/km | Temperature slope (kWh/km per °C) |
|---|---|---|---|
| Regional | VECTO constant | 0.722 | −0.0015 |
| Regional | electric heater | 0.726 | −0.0026 |
| Regional | heat pump | 0.721 | −0.0019 |
| Urban | VECTO constant | 0.577 | −0.0005 |
| Urban | electric heater | 0.587 | −0.0027 |
| Urban | heat pump | 0.576 | −0.0013 |

- **Monthly Regional, electric heater:** Jan 0.755, Jul 0.702 kWh/km, i.e. **+7.5 % winter swing** (air density + HVAC only).
- **Payload slopes (kWh/km per t):**

| Cycle | VECTO (its two runs) | HDEV (0 to max payload) | Öko measured |
|---|---|---|---|
| Regional | 0.025 | 0.027 | 0.018 |
| Urban | 0.040 | 0.035 | 0.018 |

**Other evidence on cold-weather consumption (not only Öko)** [SOURCE]:

| Source | Vehicles | Finding |
|---|---|---|
| [Öko-Institut](https://www.oeko.de/fileadmin/oekodoc/Real-world-data-analysis-of-battery-electric-trucks-operating-in-Germany.pdf) | 19 eActros, Germany | −0.013 kWh/km per °C (≈ 34 % between 0 and 25 °C at 0.96 kWh/km). One regression, R² 0.473; seasonal confounding possible |
| [ViriCiti 2020 via ChargedEVs](https://chargedevs.com/newswire/new-report-analyzes-real-world-performance-of-100-e-buses-in-hot-and-cold-weather) | ~100 e-buses, Netherlands | cold (−10 to +14 °C) +14 % (12 m) / +21 % (18 m); hot (20–29 °C) +9 % / +12 % |
| [Vehviläinen et al., Applied Sciences 2022, 12(6) 2762](https://www.mdpi.com/2076-3417/12/6/2762) | e-buses, Tampere, Finland | winter 40–45 % above summer; below 0 °C about 0.04 kWh/km per °C; slush +0.2 kWh/km (median) |
| [Dollinger & Fischerauer, Energies 2021, 14(18) 5804](https://www.mdpi.com/1996-1073/14/18/5804) | model; cars and small trucks | winter range −9 % (small truck); includes cold-tyre Crr (ref tyre temp 60 °C, warm-up can cut Crr ~45 %), battery temperature model, HVAC; battery preheating ≈ 4 % of winter consumption |
| [KTH, Hyttinen 2023 thesis](https://www.kth.se/en/2.266/modelling-and-experimental-testing-of-truck-tyre-rolling-resistance-1.1276113) | truck tyres, −30 to +25 °C | "considerable increase" in rolling resistance at lower tyre/ambient temperature; numbers only in the full thesis (urn:nbn:se:kth:diva-335323) |
| [Smithers via Tyrepress](https://tyrepress.com/2022/12/rolling-resistance-higher-at-colder-temperatures-smithers-study) | lab tyre tests | rolling resistance higher at low temperature; numbers in their whitepaper |
| [Daimler Truck press release](https://www.daimlertruck.com/en/newsroom/pressrelease/electrified-inbound-logistics-real-world-operational-data-reveal-the-potential-of-battery-electric-trucks-53507078) | eActros 600 routes, Nov–Feb | 100 and 92 kWh/100 km (no temperature split) |

**Net picture**
- HDEV's +7.5 % winter swing is about the size of the one modelling study (9 %) and **below every measured data set** (14–45 %).
- Buses aren't directly comparable (big cabins, door openings), but the direction is the same.
- Missing in HDEV: cold tyres (Crr), battery heating and battery losses, snow/slush, depot pre-heating.

---

## 6. Harness v1.7 (`claude/hdev_test_harness_v1.7.py`)

- v1.5 base, plus:
  - aux fix (section 2);
  - HVAC thermal on Regional + Urban + Municipal (`HVAC_CYCLES`);
  - `AUX_G4` for the eActros-like tests also uses vacuum-pump PS (162/200 W) [ASSUMPTION: eActros aux technology unknown].
- **T19 = export only:**
  - `HDEV_rows_<cycle>_<base|vecto_avg_eff>.csv`: 1 Hz t, s, v, a, grade, mode; P_wheel split into air, roll, grade and inertia (air = P_wheel − m·k_lin − m^β·k_roll − k_rot); P_trac; each aux; P_aux; P_battery.
  - `HDEV_parts_for_vecto_compare.csv` and `HDEV_monthly_kWh_km_by_hvac.csv`.
  - All zipped to `/content/hdev_outputs.zip`.
  - `VECTO_AVG_EFF` holds the `.vsum` averages typed in.
- **Last run (Bob, 22 Oct):** 71 PASS, 45 INFO, 7 WARN (known), 0 FAIL.
  - T00 shows aux W: Regional ES 1000, PS 200, HVAC 250, SP 23.01, Cond 600; Urban ES 1000, PS 162, HVAC 187.5, SP 32.01, Cond 550.
  - The SP helper returns the raw value (32.87 / 45.73) and the ×0.7 is applied via `SP_alteff`.
- **v1.6** (has a VECTO-reading T19–T21 inside Colab) is superseded by the workflow decision in section 0.
- Claude's comparison script (not in the project): reads the `.vsum`/`.vmod` with `skiprows=1`, `encoding="utf-8-sig"`, and drops the `#@ SHA256` line. It picks the reference row as the larger "Loading [kg]" per cycle.

---

## 7. Open items / next steps (in order; Bob was asked to choose between 1 and 2)

1. **Coast drivetrain drag** (driver model + consumption). Root cause of the overspeed, coasting and braking-energy difference (section 4). Decide the input form: VECTO drag curve + zero-torque gearbox/axle loss, or drag force vs speed.
2. **Cold-weather effects**, sourced one by one: cold-tyre Crr (find numbers in the KTH thesis / Smithers whitepaper), battery temperature (Ri, heating, preheating ≈ 4 % per Dollinger), snow/slush. The empirical alternative is an optional flagged term.
3. **Drivetrain maps instead of constants:** gearbox/axle loss maps (`.vtlm`) + motor map (`.vemo`) per second. This is 90 % of the 32 % gap. Flag that VECTO's generic gearbox maps are diesel-sized and may be pessimistic for real e-trucks.
4. **Regen limits:** motor generating torque (`ElectricMotor.cs` 485–509), battery charge power (`Battery.cs` 212–224), full battery.
5. **Battery engine** (OCV + Ri, SOC, charge limits); VECTO battery loss ≈ 1 kWh/trip here.
6. **Cond rule:** on when motor not EmOff (`Conditioning.cs` 83–91) vs HDEV moving rule.
7. **Standing-time difference** (≈ 1 s per stop): confirm it is 1 Hz averaging.
8. **Still open from before:**
   - Bob writes `climate_lookup` + `HVAC_thermal` sections 2–6 (needs real cab data);
   - parser items (`dh = height/10`, stop extension, PTO checks, Crr_eff, payload t → kg);
   - eActros VECTO customer information file;
   - 1 km/h driver overshoot;
   - explain `interp1` / `decel_distance` / `coast_distance` / `driver_model` to Bob;
   - "EM total rated power 500 kW" in the `.vsum` vs 2 × 125 kW.

---

## 8. Files

**Project**
- `claude/hdev_test_harness_v1.7.py` (current)
- `claude/hdev_test_harness_v1.6.py` (superseded)
- this close-out

**Bob's PC:** `C:\Users\mdib2\Desktop\vecto e2\` (VECTO outputs).

**Bob uploaded to this chat** (re-upload in a new chat if needed for further comparison):
- `BEV_E2.vsum`
- `BEV_E2_RegionalDelivery_ReferenceLoad_1Hz.vmod`
- `BEV_E2_UrbanDelivery_ReferenceLoad_1Hz.vmod`
- `BEV_E2_LongHaul_ReferenceLoad_1Hz.vmod`
- `hdev_outputs.zip`
- harness v1.7 SUMMARY text
