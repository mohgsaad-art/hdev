# Session close-out — 2026-10-12 — Kiro setup and master-plan spec

Read this first in the next chat. It covers what was done with Kiro, where everything lives, what is decided, what is still open, and the exact next step.

Owner: Bob (always "Bob" in every file). Working name: HDEV (final name undecided; do not use EVsyst).

---

## 1. Where things live

- **GitHub repo (private):** `mohgsaad-art/hdev`. Kiro Web works on this repo and opens PRs. Bob merges.
- **The bundle** (`hdev-kiro-bundle.zip`) was unzipped into the repo. It contains:
  - `README.md` (index + "What this is about"), `KIRO_PROMPT_1_STEERING.md`
  - `src/engine/`: `crosswind_engine.py` (DONE, verified 0.006 %), `payload_engine.py` (`payload_engine` + `fill_payload`), `force_engine.py`, `p_aux.py` (stub), `driver_model.py` (under audit)
  - `src/charging/`: `ev_charging_env.py`, `flexibility_setpoints.py`, `allocators_edf_es.py`, `run_allocator_21h.py`, `tester_21h_maddpg.py`
  - `src/data_fetch/`: `dmi_weather_climatology.py` (draft; violates the no-cross-year-averaging rule), `dmi_wind_plot_old.py`
  - `src/deprecated/`: `charging_physics_engine_exponential.py`, `simulate_driver_alt.py` (has `parse_vdri_text` / `parse_vacc_text`)
  - `docs/decisions/` (6 close-outs, 6–8 Oct), `docs/design/` (payload stop rows, year-and-day problem, status-and-known-contradictions), `docs/context/` (product-and-scope, input-layer-and-json, tco-and-reference-excels, business-model-and-design-implications)
  - `reference/excel/` (3 reference Excels), `reference/vecto/`, `reference/regulation/ADD_THESE_FILES.md`
- **Added by Kiro (all merged):**
  - PR #1: `.kiro/steering/*.md` (product, tech, structure, engine-rules, etc.)
  - VECTO reference copy: `reference/vecto/cs`, `cs/declaration`, `resources` (56 files, stable v5.1.3, commit d16ba783c)
  - PR #2 + PR #4: `.kiro/specs/hdev-master-plan/{requirements,design,tasks}.md`
  - PR #3 + PR #4: `docs/research/vecto/01–13` + `index.md`

## 2. Kiro working rules (agreed)

- Bob writes all code. Kiro only plans, explains, reviews, and writes tests when asked.
- One task per Kiro run. Each run costs roughly 3–4 credits for a small job (Kiro plan: 500 credits, 49 days left as of the start of this session).
- Kiro must use the VECTO **stable** branch (v5.1.3, d16ba783c), not IEPC-experiments.
- VECTO cannot build in Kiro's sandbox (NuGet 403). Any real VECTO run is Bob's job, on his own machine.

## 3. Decided in this session

- **Year structure:** Option 1 = simulate every operating date of the year directly. Option 3 (hybrid) only as a fallback. A timing gate comes first: one year of consumption + one year of charging, at coarse and fine dt.
- **Weather spread ≠ Monte Carlo.** Weather spread = percentiles of daily results across the weather year. MC P10/P50/P90 is a separate, optional layer.
- **Start with daily weather (option A).** Choose B vs C after the timing gate.
- **Charging time step is an argument.** Two-resolution option: `dt_base`, `dt_fine`, plus a list of windows. Neutral case: `dt_fine == dt_base`. The actual resolutions must come from Energinet product specs (still to be sourced; no number assumed).
- **Session hand-over object** from consumption → charging: `{arrival, departure, energy_need_kWh, arrival_SOC}`.
- **Any stage can run on its own** (consumption, charging, flexibility, TCO, or combinations) from user-supplied data. `runner.run(base, changes)` picks the start stage and refuses if the entry contract is incomplete. Engines stay pure.
- **Slots:** OEMs, CPOs and aggregators plug open-ended spec-sheet or price data into the "slots" of a client's fixed operational project (for bid comparison or tender creation). Proposed slot shape: `{value, unit, source, date, label, provided_by, locked, version}` (Bob still has to confirm it — M6.7). Each slot is reported as provided-unused, defaulted or missing. Operational slots can be locked for bid comparison.
- **Capability gating:** no smart charging → ASAP charging only (Decided). Other gates are still suggestions (M6.16).

## 4. Pattern input vs full-year simulation (answered at the end of this session)

There is no contradiction:
1. **Input = pattern.** Per vehicle or group (with a count): route, days (e.g. Mon–Fri), departure and return times, plus exceptions (holidays, half-day Saturdays). The user does not type 365 rows.
2. **Calendar expand** → every dated operating day per vehicle.
3. **Consumption per vehicle per date**, using that date's weather (payload → crosswind → driver → force → weather → power → P_aux → kWh).
4. **Sessions:** one hand-over object per vehicle-date.
5. **Depot charging:** one run over the whole year with all sessions. Shared chargers and grid limit; an SOC shortfall carries over to the vehicle's next day.
6. **Optional MC** on arrival/departure spread (from data, or a clearly labelled assumption). It repeats the year run; it does not replace it.

Vehicle level = depot run with N = 1 (same engine). A change-set reruns only the downstream stages (e.g. a charger change reruns only charging; a battery change reruns from consumption because mass changes).

**This flow is not yet written in the spec as one explicit section.** See next steps.

## 5. VECTO findings (from the Kiro research, corrected in `13-followups.md`)

- **Grade:** the VECTO force balance uses an **altitude secant per step**: `atan((alt(prev+ds) − alt(prev)) / ds)` (`DistanceBasedDrivingCycle.cs:412-433`). `<grad>` is only integrated into altitude at load (`DrivingCycleDataReader.cs:236`). Research file 08 was wrong. **M0.12 is NOT resolved.**
- `Truck.vacc` is the same for BEVs. EmOffPrev ⇔ `EMTorque == null`.
- Payload cap = GVW − (curb + body + trailer curb).
- IMC ΔCdxA = 0 (0.6 m² pantograph). CdxA defaults come from `SegmentTable.csv` (Group 5: 8.7 m²).
- Battery: OCV + Ri model, I²·Ri loss always applied (drive and regen).
- **0.95 / 0.95 efficiencies have no VECTO basis.** VECTO uses a speed × torque → P_el map. 0.98 is a clamp fallback; ADC 0.98 / 0.96. Wording in the spec is now "HDEV placeholder with no VECTO equivalent".
- VECTO does **not** simulate charging. `StationaryChargingPower.csv` (500/250/100 kW, 0.5 h/event) is OVC-HEV accounting, **not** a charger spec. Do not use it as a charger default.
- `P_PTO_el` is in kW. Bus SSM COP goes down to −20 °C.
- `Payloads.csv` copies are byte-identical (the earlier "truncated" claim was wrong).
- Component validation anchors: `BatteryTest.cs`, `ElectricMotorEfficienyMapTest.cs`.

## 6. Spec state after PR #4 (merged)

- `requirements.md` §8–§11 = Requirements A–D (stage entry points, open slots/registry, comparison/fit, TCO), plus fixes for M0.12, the efficiency gap wording, and the M5.3 off-sandbox note.
- `design.md` Part 4 = stage map, entry-contract table (charging entry = session list), runner stage selection and refusal, slot schema and registry (`STAGE_SLOTS`), change-sets and lock, capability gating, sanity checks, comparison/fit JSON, TCO data model, §4J engine purity.
- `tasks.md` = M5.6 (Bob runs VECTO off-sandbox) + M6.1–M6.25.
- Kiro reported no conflicts with existing Decided items.

## 7. Open — Bob's decisions (🔒)

- **M0.12:** match VECTO's altitude secant now, or record the difference as a flagged gap (now confirmed to be real).
- **M6.6:** resolution-mismatch rule per stage. Kiro suggests reject for charging↔flexibility and energy-conserving resample for TCO. This is a suggestion, not decided.
- **M6.7:** confirm the slot field shape.
- **M6.16:** which capability gates to build beyond ASAP-only (V2G → no export, connectors → max simultaneous, min-power → no deep modulation; all suggestions).
- **M6.20:** confirm the fit-verdict field set.
- **M6.21:** build the inverse "smallest battery/charger that fits" sweep or not.
- **M6.24–25:** TCO headline metrics and CO₂ sources (no numbers until sourced).
- **M5.6:** Bob runs `BEV_E2.vecto` off-sandbox and brings back per-mission kWh/km, SoC start/end, and E_REESS_LOSS.
- Later: adopting the EM efficiency map instead of the 0.95 / 0.95 placeholder.

## 8. Pending with Kiro

- A correction was sent (or is due to be sent) after PR #4: the spec wrongly assumed Bob already has consumption, parser and resolver code. **That code is not written yet.** Kiro is to add an **M0.0 task (waypoint + `.vacc` parser)** and treat those modules as fresh writes. **Waiting for Kiro's reply; review it before merging.**

## 9. Next steps (one at a time)

1. Review Kiro's reply and PR for the M0.0 correction; merge if correct.
2. Send Kiro a short message to add the flow in §4 above (pattern → calendar → per-vehicle-per-date consumption → sessions → year-long depot charging run with SOC carry-over → optional MC) as one explicit design section, with matching tasks.
3. Bob decides the 🔒 items (M0.12 first, because it affects the force engine).
4. Bob starts coding with **M0.0 (waypoint + `.vacc` parser)**.
5. Timing gate (one year of consumption + charging at coarse and fine dt) once the consumption chain runs end to end.

## 10. Known file issues (carried over)

- `dmi_weather_climatology.py` averages across years, which breaks the no-cross-year-averaging rule. It needs rework before use.
- `driver_model.py` is still under audit.
- `p_aux.py` is a stub.
