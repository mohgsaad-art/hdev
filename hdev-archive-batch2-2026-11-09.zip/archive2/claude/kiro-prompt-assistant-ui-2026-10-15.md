# Kiro prompt — AI assistant UI, demo mode and missing engine functions

Owner: Bob. Repo: `mohgsaad-art/hdev`. Working name: HDEV (final name undecided — show `[TOOL NAME]` in the UI, never "EVsyst").

Read first: `.kiro/steering/*`, `.kiro/specs/hdev-master-plan/{requirements,design,tasks}.md`, `docs/design/status-and-known-contradictions.md`, `docs/decisions/*`. The UI reference is `docs/design/ui-mockup/fleet-assistant-demo.html` (Bob will add it) — match its layout, flow and look exactly.

---

## 0. Rules for this job (read before anything else)

1. **This job changes the earlier rule "Bob writes all code".** For this job you may write code, in small PRs, one task per PR. Bob reviews and merges every PR.
2. **Never decide an open item.** Anything marked 🔒 in `tasks.md` (M0.12, M6.6, M6.7, M6.16, M6.20, M6.21, M6.24–25, M5.6) stays open. If a function depends on one, write the interface and a stub that raises `NotImplementedError("blocked by M0.xx")`, and list it in the PR description.
3. **No invented numbers.** Every default value comes from a source already in the repo (VECTO stable v5.1.3 `d16ba783c`, `docs/research/vecto/*`, `reference/excel/*`, the 2026-10-07 defaults note). If there is no source, leave it empty and flag it. Demo fixtures are the only exception, and they must be labelled "illustrative" everywhere they appear (see §7).
4. **All logic in Python. The UI is a dumb client.** JavaScript only renders what the server sends and posts raw JSON back. No calculations, no defaults, no resolver logic, no scenario maths in JS. (The mock-up HTML contains stand-in JS formulas — these must move to Python, see §7.)
5. **Engine purity.** Engine functions are pure: every parameter comes in as an argument, nothing hard-coded, so the tool works for any country. No I/O inside engine functions.
6. **The method stays hidden.** The UI, the assistant's text and the report never show parameter names, formulas, coefficient names, data source names for the physics, or method/strategy technical names. See §8 for the full list.
7. **VECTO:** use the stable branch only. VECTO cannot build in your sandbox; anything that needs a real VECTO run is Bob's job.
8. Refer to the owner only as "Bob" in every file.

---

## 1. What we are building

One local web app with two modes behind the same UI:

| | **Demo mode** | **Real mode** |
|---|---|---|
| Purpose | Show the tool to a partner on Bob's laptop | Run real client cases |
| Engine | `demo_engine.py` (illustrative numbers, same interface) | The real pipeline via `runner.run()` |
| Assistant | Scripted replies + suggestion buttons, works offline | LLM via an adapter, with tool calls |
| Data | `demo/sample_case/` fixtures | The client's project JSON |

**Build demo mode first, end to end.** Real mode plugs into the same interfaces as the engine gets finished. Switching modes is one setting (`HDEV_MODE=demo|real`), not a code change.

---

## 2. Architecture

```
Browser (static HTML/CSS/JS, dumb)
   │  JSON over HTTP, localhost only
Local server (FastAPI, bound to 127.0.0.1)          ← Bob to confirm FastAPI now vs later
   ├─ /api/intake        files + message → extracted inputs
   ├─ /api/inputs        get / patch the project's inputs
   ├─ /api/run           run a scenario → results JSON
   ├─ /api/chat          assistant turn (demo: scripted, real: LLM + tools)
   ├─ /api/scenarios     save / list / compare
   ├─ /api/audit         input sources + run log
   └─ /api/report        build PDF / Excel
Python services
   ├─ intake/            file readers + AI extraction → input registry slots
   ├─ registry/          input registry (sections, subgroups, fields, visibility)
   ├─ validate/          checks every patch and every lever change
   ├─ runner/            runner.run(base, changes) → picks start stage, reruns only downstream
   ├─ engine/            the pure engine (existing + missing functions, §6)
   ├─ demo/              demo_engine.py + sample case fixtures
   ├─ explain/           turns results JSON into plain-language text (templates; LLM only rephrases)
   ├─ audit/             input-source tracking + run log
   └─ report/            PDF + Excel export
Project state: one project JSON file per project, saved server-side (already decided).
```

---

## 3. Data contracts

### 3.1 Input registry

One Python registry defines every input. The UI draws sections and fields **only** from this registry.

```python
Field = {
  "id": "operation.shift_end",
  "section": "operation",          # one of the 8 sections in §5.4
  "subgroup": "schedule",
  "label": "Shift end",            # plain words, client-facing
  "type": "time|number|enum|text|bool",
  "unit": "km" | None,
  "visibility": "open" | "collapsed" | "hidden",
  "editable_in_demo": bool,
}
```

- `open`: label and value are shown when the section is expanded.
- `collapsed`: counted in the section and subgroup totals, never listed by name in the UI.
- `hidden`: internal; never counted or shown.
- **Default rule:** every vehicle-physics, weather-physics, charging-physics and drivetrain field is `collapsed`. Only Operation and Energy prices fields may be `open`. Bob reviews the list in the PR.

Each field's value is stored in a **slot** using the proposed shape `{value, unit, source, date, label, provided_by, locked, version}`. That shape is still 🔒 M6.7, so wrap it in one class so it can change in one place.

`source` is one of: `file:<filename>`, `message`, `user_edit`, `standard`, `standard_approved`, `missing`.

### 3.2 Levers (what the assistant and the scenario bar may change)

```python
LEVERS = {
  "fleet_size":        {"type": "int",  "min": 1, "max": "from project"},
  "charging_priority": {"type": "enum", "options": ["lowest_cost", "grid_friendly", "ready_earliest"]},
  "electricity_price": {"type": "enum", "options": ["low", "expected", "high"]},
  "weather_year":      {"type": "enum", "options": ["normal", "cold_winter"]},
  "ownership_years":   {"type": "enum", "options": [8, 10, 12]},
}
```

- Plus any `open` + `editable_in_demo` field (e.g. `operation.shift_end`).
- The validator rejects any lever or value not in this list.
- How each lever maps to engine inputs is defined in Python (`runner/levers.py`), never in JS or in the LLM.
- The internal mapping of the three charging priorities (to ASAP / JIT / cost-based setpoints) stays in Python. The client-facing names are the only names that leave the server.

### 3.3 Results JSON (one per run)

```json
{
  "run_id": 3, "timestamp": "...", "mode": "demo|real", "illustrative": true,
  "settings": {"fleet_size": 6, "charging_priority": "lowest_cost", ...},
  "verdict": {"can_electrify": true, "headline": "...", "reason": "..."},
  "kpis": {"battery_kwh": ..., "charger_kw": ..., "charger_count": ..., "ready_by": "05:00",
           "grid_peak_kw": ..., "grid_limit_kw": ..., "grid_fits": true,
           "tco_diff_dkk": ..., "break_even_year": ..., "co2_saved_t_per_year": ...},
  "energy":   {"monthly_avg_kwh": [12], "avg_day_kwh": ..., "hardest_day_kwh": ..., "per_vehicle": [{"id": "T1", "avg": ..., "hardest": ...}]},
  "charging": {"soc_profile": [[hour, pct], ...], "strategies": [{"priority": "...", "charger_kw": ..., "peak_kw": ..., "cost_per_year_dkk": ..., "fits_grid": true, "ready_by": "..."}]},
  "grid":     {"load_24h_kw": [24], "limit_kw": ..., "flex_24h_kw": [24], "flex_mwh_per_day": ...},
  "tco":      {"years": 10, "categories": [{"name": "Owning", "diesel": ..., "electric": ...}, ...], "cumulative": {"diesel": [...], "electric": [...]}},
  "co2":      {"diesel_t_per_year": ..., "electric_t_per_year": ..., "cumulative_saved_t": [...]},
  "plan":     [{"when": "Year 1", "text": "..."}, ...],
  "inputs_summary": {"from_data": 29, "standard": 83, "missing": 0, "total": 112}
}
```

- TCO categories, in this order: Owning, Running, Infrastructure, Policy & taxes, Hidden costs, Climate.
- The TCO structure follows `reference/excel/eltiltrucks-beregner-ark.xlsx`. Headline metrics and CO₂ sources are 🔒 M6.24–25. Until they're decided, real mode returns `null` for those fields and the UI shows "Not yet available".

### 3.4 Run log entry

`{run_id, timestamp, settings_summary, changed_from_previous: [...], key_result_summary, mode, engine_version}`. This is append-only and stored in the project JSON.

---

## 4. The assistant

### 4.1 Extraction (intake)

- **Input:** dropped files (xlsx, csv, pdf, docx, txt) + the user's message.
- **Output:** values for registry fields only, each with its `source`.
- **Hard rule: extract only what is stated.** If a value is not in the files or the message, the slot stays `missing`. The AI never estimates, never fills defaults and never converts units on its own. Python does unit handling and defaults.
- Python then fills `standard` values from documented defaults and lists what is still `missing`.
- Route descriptions without waypoints go to the planned AI waypoint adapter (§6, item 12). Until that exists, they stay `missing`.

### 4.2 Conversation tools (real mode)

The LLM can call only these tools:

| Tool | Does |
|---|---|
| `ask_missing(fields)` | Ask the user for missing fields, in plain words |
| `apply_standard(fields)` | Mark missing fields as `standard_approved` (only after the user says yes) |
| `set_inputs(patch)` | Change field values the user stated |
| `run_scenario(levers)` | Validate → run → results JSON |
| `compare_runs(run_ids)` | Return a diff table of two or more runs |
| `save_scenario(name)` | Save the current run |
| `build_report(format)` | PDF or Excel |

### 4.3 What the assistant may say

- **Every number it writes comes from a results JSON or the input registry.** The `explain/` module builds the text from templates, and the LLM may only rephrase it. Add a check that rejects any reply containing a number not present in the run's results JSON.
- It explains **results**, never **methods**. "Winter needs more energy" is fine. Why physically, how it's calculated, and which parameters or data are used are not.
- If asked about the method: "That's the engineering side. The results and every input source are in the report."

### 4.4 Demo mode assistant

- Scripted replies, no internet needed.
- Opening message: "Hi. Drop in whatever you have – fuel logs, route lists, spreadsheets – and tell me what you want to find out. No GPS needed."
- Flow:
  1. Files plus a message.
  2. "Reading…", then the input sections fill.
  3. "I found 110 of 112 inputs… two are missing", with buttons *Use standard values* / *I'll add them myself*.
  4. "Running the analysis now."
  5. A summary built from the results JSON.
  6. Suggestion buttons.
- **Suggestion buttons after results** (each calls the same server endpoints as real mode):
  - Compare charging strategies → opens the Charging tab
  - What if electricity costs more? → price = high, rerun, opens TCO
  - Add 4 more trucks → fleet_size + 4, rerun, opens Grid
  - Cold winter → weather = cold, rerun, opens Energy
  - Save as scenario → Scenarios tab
  - Show me the inputs → Inputs tab, Operation expanded
  - Show the audit trail → Audit tab
  - Make the report → Report tab
- **Typed questions in demo mode:** keyword match (strategy/compare/charg → strategies; price/cost/expens → price; truck/add/more → trucks; cold/winter/weather → winter). Anything else gets: "In this demo I can answer the suggested questions below. In the full tool you can ask anything about your fleet."
- **Editing a field** (e.g. shift end) triggers a rerun and a reply naming what changed and what didn't, plus "Logged as run #N in the audit trail."

---

## 5. UI specification (match the mock-up)

### 5.1 Look

| Token | Value |
|---|---|
| navy | `#0E1B33` (header, verdict, chat header) · navy-2 `#16284A` · navy-3 `#1A2A48` |
| signal blue | `#1F5FD1` (primary, electric series) · hover `#174BAA` · light `#E6EEFB` · mid `#9FB9EA` |
| amber | `#F2A93B` (standard values, limits, highlights) · text-safe `#B87404` · bg `#FFF4E2` · line `#F2D29C` |
| ink | `#0E1B33` · ink-2 `#46526A` · ink-3 `#5A6680` |
| neutral | line `#DDE3EC` · page bg `#F3F5F8` · card `#FFFFFF` · diesel series `#9AA5B8` · gridlines `#E7EBF2` |
| missing | text `#8A1C1C`, border `#D89A9A`, bg `#FFF8F8` |

- **Type:** Barlow (400/500/600/700) for body, Barlow Condensed (600/700) for headings and big numbers. Self-host the fonts so the demo works offline.
- **Radii:** cards 14 px, tiles 12 px, inputs and buttons 8 px, pills 999 px.
- **Touch targets:** at least 44 px.
- **Charts:** hand-drawn SVG, no chart library (matches the dashboard decision).
- **No emoji.** Icons are inline stroke SVG.
- **Contrast:** text at least 4.5:1. Never use colour alone for meaning. Pair it with a label (e.g. "Standard value" tag).

### 5.2 Layout

- **Header (navy):** logo mark + `[TOOL NAME]` + "Fleet electrification assistant". Right side: an amber pill "Sample case · … · illustrative values" in demo mode only.
- **Body:** max width 1240 px, two columns.
  - **Left, the assistant column** (360–420 px). Sticky, full viewport height minus header. Chat header "Assistant" with an amber dot. Scrolling message list. Suggestion buttons above the composer. Composer has a drop zone ("Drop files here – any format" + "Add sample files" in demo), a text input and a send icon button.
  - **Right, the workspace** (fills the rest). Title (Workspace → Inputs → Results) and an input counter "N of 112 inputs".
  - Below 900 px the columns stack and the chat is no longer sticky.
- **Messages:**
  - Bot bubbles: `#EEF2F8`, radius 12/12/12/4.
  - User bubbles: blue with white text, radius 12/12/4/12. Attached files show as chips inside the user bubble.
  - A typing indicator (3 pulsing dots) appears before each bot reply.

### 5.3 Workspace states

1. **Empty:** dashed card "Drop your files and describe the problem in the assistant. Your inputs, analysis and results will appear here."
2. **Filling:** the 8 section cards fill one after another. The active card gets a blue glow ring, its counter ticks up and its meter grows (blue = from data, amber = standard). The header counter ticks up to the total.
3. **Missing:** the cards with a missing input show "N missing" in the missing colour.
4. **Running:** a card "Running your fleet through a full year / Every working day, every season, every truck." It has a progress bar and 9 checklist lines that tick in order:
   - Reading routes and stops
   - Simulating 250 working days per truck
   - Adding weather for every day of the year
   - Sizing batteries to the hardest day
   - Testing charging strategies
   - Checking the depot grid connection
   - Finding flexibility
   - Calculating total cost of ownership
   - Calculating CO₂

   It ends with "Done in X s · N truck-days simulated", using real timing and counts from the server.
5. **Results:** the tab bar and scenario bar appear, and the Overview tab opens.

### 5.4 Input sections (Inputs tab)

8 cards in a responsive grid (min 250 px). Each card shows:
- name and "n / total" counter
- a one-line plain summary
- the two-colour meter
- the legend "X from your data · Y standard"
- **subgroup chips with counts**

| Section | Subgroups (count) | Expandable |
|---|---|---|
| Operation | Schedule 5 · Routes 5 | Yes: field list, Shift end is a dropdown |
| Vehicles | Body 6 · Drivetrain 5 · Battery 4 · Wheels 3 · Equipment 6 | No |
| Depot & grid | Site 4 · Connection 5 · Building load 4 · Chargers on site 5 | No |
| Charging | Strategy 3 · Charger types 4 · Time windows 4 | No |
| Energy prices | Electricity 5 · Grid tariffs 3 · Diesel 2 · Trends 2 | Yes: plain fields only |
| Weather | Location 2 · Daily records 4 · Seasons 3 | No |
| Costs & finance | Purchase 5 · Leasing 4 · Maintenance 5 · Finance 6 | No |
| Policy & taxes | Taxes 4 · Subsidies 4 | No |

**These counts and subgroup names are the mock-up's.** Generate them from the registry. When the registry differs, the registry wins and the UI follows. In an expanded section, an edited field gets an amber background.

### 5.5 Scenario bar (above the tabs)

Controls:
- Trucks: range slider plus value
- Charging priority: Lowest cost / Grid-friendly / Ready earliest
- Electricity price: Low / Expected / High
- Weather: Normal year / Cold winter
- Ownership period: 8 / 10 / 12
- A *Save scenario* button

Any change posts to `/api/run`. While the request runs, an overlay covers the results panel: "Recalculating", a progress bar and rotating lines ("Re-running the year…", "Re-sizing chargers…", "Checking the grid…", "Updating costs…"). When the assistant changes a lever, the bar updates to match.

### 5.6 Tabs and their content

Every tab has a row of KPI tiles (label, big number, one-line note; blue = good, amber = warning) and two charts side by side (they stack under 340 px each).

| Tab | Tiles | Charts / content |
|---|---|---|
| Inputs | — | Section cards (§5.4) |
| Overview | Battery per truck · Chargers · Ready by 06:00 · Grid connection · N-year cost vs diesel · CO₂ saved | Navy verdict card (eyebrow "Verdict", headline, reason, "Based on" box: from-data vs standard counts, "250 working days · weather included"); "Your electrification plan" numbered list; "Cost over time" line chart (diesel grey vs electric blue, break-even marker) |
| Energy | Average day · Hardest day · Winter vs summer % · Fleet energy MWh/yr | Monthly energy line with hardest-day reference line; grouped bars per truck (average vs hardest) |
| Charging | Charger size · Battery left at return · Full again by · Yearly charging cost | Battery level over a working day (0–100 %, amber dashed line at 06:00); strategy table (strategy, charger kW, depot peak, cost/yr, grid fits), current row highlighted, cheapest labelled |
| Grid & flexibility | Depot peak · Connection limit · Headroom · Flexible energy MWh/day | Depot load over 24 h with amber dashed limit line; flexibility bars per hour |
| Costs (TCO) | Diesel total · Electric total · Difference · Break-even | Grouped bars by the 6 categories; cumulative cost lines with break-even marker |
| CO₂ | Diesel fleet t/yr · Electric fleet t/yr · Reduction % · Saved over N years | Yearly emissions bars; cumulative saved line |
| Scenarios | — | Table of saved scenarios: settings + battery, peak, TCO saving, CO₂ saved |
| Report | — | "Your report is ready" card with *Download PDF* and *Download data (Excel)*; 9 page thumbnails: Summary, Your fleet & inputs, Energy, Charging, Grid & flexibility, Total cost, CO₂, Plan, Inputs & sources |
| Audit trail | — | "Where every input came from" (source → count → status, total row) + note "Every value can be changed. Changes are logged with who and when."; "Run log" table (run #, time, settings, key result), newest first |

**Fields that don't exist yet:** in real mode, any results field that is `null` shows "Not yet available" in the tile, never a made-up value.

### 5.7 Accessibility and behaviour

- Real `<button>`, `<label>` and `<input>` elements. Tabs use `role="tab"` and `aria-selected`.
- The chat list has `aria-live="polite"` and icon buttons have `aria-label`.
- Charts have `role="img"` and an `aria-label`.
- Keyboard: Enter sends a message. All controls are reachable by Tab.

---

## 6. Missing engine functions — write the decided ones, stub the blocked ones

Follow `design.md` and the decision notes. Each function is pure and has tests, and takes every parameter as an argument.

| # | Function / module | Status in repo | What to do |
|---|---|---|---|
| 1 | Waypoint + `.vacc` parser (M0.0) | Not written (`simulate_driver_alt.py` has old `parse_vdri_text` / `parse_vacc_text` for reference) | Write fresh |
| 2 | `defaults.py` | Not written; values collected in the 2026-10-07 VECTO defaults note | Write, with a source per value |
| 3 | Typed-input resolver (total distance, stops, avg stop duration → waypoints) | Sept version not in repo | Write fresh per input-layer decisions (default speeds, dwell, flat grade, speed wins over end time) |
| 4 | Driver model fixes | `driver_model.py` under audit, 6 known bugs | **List fixes in the PR, don't rewrite silently.** Grade handling is 🔒 M0.12 — leave it as is and flag |
| 5 | `weather_for_rows` (rho_rows, cdxa_rows, 60–105 km/h clamp here) | Not written, design decided | Write |
| 6 | Power step `P_wheel = m·k_lin + m^β·k_roll + k_rot + ρ·CdxA_eff·L` | Not written as a function | Write (neutral defaults β = 1, Θ_red = 0) |
| 7 | `p_aux` | Stub; VECTO logic traced; some decisions pending | Write the decided parts only; no aux during depot charging; weather layer on aux = stub until Bob gives the W/°C source |
| 8 | Consumption (battery power by sign, efficiencies, regen → kWh) | Not in repo | Write; efficiencies 0.95/0.95/0.98 are **HDEV placeholders with no VECTO equivalent** and must be flagged in results |
| 9 | Calendar expand (pattern → every dated operating day; Danish holidays) | Not written | Write per the "pattern input vs full-year" flow |
| 10 | Session hand-over `{arrival, departure, energy_need_kWh, arrival_SOC}` | Decided | Write |
| 11 | Battery sizing (mode A datasheet / mode B iterate) | Not written | Write |
| 12 | AI waypoint adapter (coordinates/descriptions → waypoints, map-API road distance) | Planned | Interface + stub only; map provider not chosen |
| 13 | Charging: sizing mode (`P = E/t` minimum power) and simulation mode (per-timestep OCV + Ri), `dt` as an argument | Decided, not written | Write both; dt values must come from Energinet specs, so no default dt |
| 14 | Year-long depot charging run with shared chargers, grid limit, SOC carry-over | Existing env has a 21 h limit and random reset | Plan the adaptation in the PR first; don't change thesis code in place |
| 15 | `runner.run(base, changes)` — start-stage selection, reruns only downstream, refuses on incomplete entry contract | Decided | Write |
| 16 | Flexibility output (up/down energy-neutral, per hour) | Partly in thesis code | Wrap existing logic behind a pure function |
| 17 | TCO | Structure from the reference Excel; metrics 🔒 M6.24 | Data model + category sums only; no prices hard-coded |
| 18 | CO₂ | Sources 🔒 M6.25 | Interface + stub |
| 19 | `explain/` text templates | New | Write (§4.3) |
| 20 | `audit/` source tracking + run log | New | Write (§3.4) |

---

## 7. Demo mode specifics

- `demo/sample_case/`: the sample input (message text, two sample files `fuel_log_2025.xlsx` and `collection_routes.pdf`, the extracted field values with sources) for a municipal refuse fleet: 6 trucks, about 120 km/day, many stops, 06:00–15:00, Mon–Fri.
- `demo/demo_engine.py`: implements the same `run_scenario(levers) → results JSON` interface. **Port the stand-in formulas from the mock-up's JS into this file**, so that changing levers and the shift end changes the results in the same direction as the mock-up. Every results JSON from it has `"illustrative": true` and `"mode": "demo"`.
- **Better option once the engine runs:** replace `demo_engine` output with real engine runs on the sample case saved as fixtures. The demo stays offline and the numbers become real. Keep the illustrative label until Bob removes it.
- The demo must never show a number that wasn't produced by `demo_engine` or a fixture.

---

## 8. Never shown anywhere in the UI, the assistant text or the report

- Parameter or coefficient names. This includes air drag, CdA, rolling resistance, Crr, efficiencies, regen, rotating mass, yaw, OCV, internal resistance, k_lin and similar.
- Formulas, equations, or step-by-step method descriptions.
- Names of reference standards, cycles or data sources used inside the physics (e.g. VECTO, regulation numbers, mission profile names, DMI).
- Technical charging strategy names (ASAP, JIT, EDF, ES, cost-based). Only the three client-facing names.
- Field names of `collapsed` or `hidden` registry fields.
- Intermediate results (per-second rows, force traces, per-row values).

The input-sources table in the Audit tab shows **source types and counts only** ("Standard Danish values · 81"), never which fields.

---

## 9. Order of work (one PR each)

1. **Registry + slot class + validator** (§3.1, §3.2). Tests.
2. **Local server skeleton + static UI shell** (§5.1, §5.2): header, chat column, empty workspace.
3. **Demo intake + filling animation + missing flow** (§4.4, §5.3 states 1–3), driven by server fixtures.
4. **`demo_engine.py` + `/api/run` + results JSON** (§3.3, §7). Tests on the JSON shape.
5. **Run screen + results tabs + charts + scenario bar + overlay** (§5.3 state 4–5, §5.5, §5.6).
6. **Suggestion buttons + keyword match + field edit rerun** (§4.4).
7. **Scenarios, audit trail, run log** (§3.4, §5.6).
8. **Report export** (PDF + Excel) from the results JSON.
9. **Engine functions** in the order of §6, one per PR, each with tests against VECTO where possible.
10. **Real-mode assistant:** LLM adapter (provider is Bob's choice; keep it behind one interface), tool calls (§4.2), number check (§4.3).

**Acceptance for the demo (after PR 7):**
- On Bob's laptop, offline, the full flow runs without errors: files, message, fill, missing, standard values, run, results, every suggestion button, the shift edit, save scenario, audit trail and report tab.
- No JS calculations.
- The illustrative label is shown.

**In every PR description,** list:
- the open 🔒 items touched
- any value without a source
- anything from §8 that came close to being shown
