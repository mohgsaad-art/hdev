# Kiro prompt — redesign the UI mock-up (26 Oct 2026)

Owner: Bob. Read the repo `mohgsaad-art/hdev` for context only. Don't change it.

## What I want

Redesign the attached HTML mock-up (`docs/design/ui-mockup/ev-scope-workbench-2.html`) of the tool I am building. It already works end to end: inputs, Run, results, scenarios, report and an assistant. Keep that flow, but make it better.

This is a design test. You have full creative freedom on layout, visuals and how the data is shown. The guidance below is direction, not a spec.

## Read first

1. The attached mock-up. Click through all of it before you change anything.
2. `docs/design/ui-input-list-2026-10-26.md`: the full input list. A summary is in section A below.
3. `.kiro/steering/*`, `.kiro/specs/hdev-master-plan/*`, `docs/design/status-and-known-contradictions.md` and `docs/decisions/*`.
4. §8 of `KIRO_PROMPT_assistant_ui_and_engine.md` ("Never shown"). It still applies.

---

## A. The inputs (from my engine code)

Who enters each input:
- **Client** = the fleet owner or operator.
- **OEM** = the vehicle or charger maker, from a spec sheet. An OEM value overrides the client or standard value.
- **Std** = a standard value filled in automatically. It is shown collapsed, and the user can override it.

Constants and numerical settings are never shown in the UI (see the input list, Part 3).

| Group | Input | Who | Default / note |
|---|---|---|---|
| Route | Route source: standard test route / typed in / GPS file / from addresses (assistant) | Client | – |
| Route | Standard test route pick (by type of work) | Client | – |
| Route | Typed route: total distance, number of stops, average stop time | Client | Default stop time 45 min (design default); speeds 30 / 50 / 80 km/h for deep urban / urban / non-urban; flat road |
| Route | GPS file upload | Client | – |
| Route | Stop table: one row per stop with stop time, load after the stop, equipment on/off | Client | Editable columns depend on the source. Standard route: stop time and load (distances locked). Typed: everything. GPS: load only |
| Route | Shift start time | Client | – |
| Route | Operating dates over the year | Client | – |
| Load | How the load changes: constant / linear / per stop | Client | Constant |
| Load | Start load, end load (linear), load per stop (custom), in tonnes | Client | Start load = standard reference load (Std). Open decision: reference load or maximum load |
| Vehicle | Vehicle type / class (rigid, tractor, van…) | Client | Picks all the standard values |
| Vehicle | Empty weight, gross vehicle weight | Client (registration) / OEM | – |
| Vehicle | Vehicle height | Client / OEM | Std by class |
| Vehicle | Air drag area (certified), crosswind coefficients | OEM | Std by class |
| Tyres | Rolling resistance (EU tyre label), tyre size, wheel inertia | Client / OEM | Std |
| Drivetrain | Motor rated power | Client (spec sheet) / OEM | – |
| Drivetrain | Max regeneration power, motor / inverter / gearbox efficiency, regen efficiency, rotating inertia, drivetrain drag | OEM | Placeholders today: 0.95 / 0.95 / 0.98, no cap, 0, 0. To be replaced by standard maps |
| On-board systems | Electrical system: technology or custom W, plus a conversion factor | Client / OEM | Std; factor 0.7. Show the label "0.7 = standard; set 1.0 if your value is already electric" |
| On-board systems | Air system: electric technology or custom W, factor | Client / OEM | Std; factor 1.0 |
| On-board systems | Steering: number of steered axles, technology per axle | Client / OEM | Std |
| On-board systems | Cab climate mode: standard value or from the weather (cab model) | Client | Standard value |
| On-board systems | Cab climate standard value (W), battery/motor cooling (W) | Client / OEM | Std |
| On-board systems | Always-on equipment, e.g. chiller or mixer (W) | Client | 0 |
| Cab model (only when cab climate = from the weather) | Cab size (wall area, window area, volume), insulation, people in the cab, heater type, max heating and cooling power, electric heater efficiency | OEM / Client | Cab size is a placeholder today; heater shares and efficiencies are Std; heater efficiency 0.93 |
| Equipment at stops | On/off per stop (stop-table column), power profile over time or one constant value | Client / OEM | Std refuse-body profile, 0.150 kWh per stop over 23 s |
| Equipment at stops | Option: "use the stop time as the equipment time" | Client | Off (standard: stop time + equipment time) |
| Weather | Location (→ nearest weather station), weather year | Client | – |
| Planned | Battery capacity and battery model; charger inputs; fridge unit; gearbox data; cold-tyre factor | Client / OEM | Not in the code yet. Show these as "coming soon", not as working fields |

Notes:
- **Units.** Load is entered in tonnes. The conversion happens in Python, not in the UI.
- **Inputs without a home in this list.** The mock-up also has depot, grid, charging, prices, costs, taxes and CO₂ inputs. They are not in the engine yet and come from the reference Excel sheets (charging, cost and CO₂ structure). Keep them, but mark them as later stages.

## B. What the engine does today (from my Colab notebook)

Pipeline, in order:
1. **Crosswind correction:** effective air drag area by speed and wind.
2. **Load and stop-equipment pre-steps:** fill in the load and the equipment use at each stop.
3. **Driver model:** produces 1-second rows of speed, distance, acceleration, slope and driving mode (stop, accelerate, cruise, coast, brake).
4. **Force step.**
5. **On-board power:** power drawn by on-board systems.
6. **Consumption engine:** energy drawn from the battery per row.

The weather is real hourly data (temperature, wind, sun) for a full year.

**Outputs that exist now**, so the results pages can be built around them:
- Per second along the route:
  - speed, distance and driving mode
  - power at the wheels, split into air, rolling, slope and acceleration
  - traction power, with regeneration shown as negative
  - power of each on-board system: electrical, air, cab climate, steering, cooling, stop equipment
  - total battery power
- Per trip:
  - kWh and kWh/km
  - share of energy by cause (air, rolling, slope, on-board systems, stop equipment)
  - energy recovered by braking
  - time spent stopped, accelerating, cruising, coasting and braking
- Per day for a full year with real weather:
  - kWh per trip each day
  - monthly kWh/km and the winter-to-summer swing
  - the worst day
  - how much wind and temperature drive the result
  - comparison of cab climate options (standard value, electric heater, heat pump)
- Sensitivities: kWh/km per extra tonne of load, and per °C.

**Being tested, not final:** battery losses (open-circuit voltage + internal resistance), cold tyres, extra heating for fresh air, drivetrain standard maps and coasting drag. Results may show them as "in testing".

**Not built yet.** The mock-up must still show these as full, designed results pages with illustrative numbers, just like the built ones. This is a mock-up of the finished tool. Label the numbers illustrative; don't leave pages empty or "Not yet available":
- battery sizing, state of charge over the day and the week
- charger sizing and the year-long depot charging run with a grid limit
- flexibility
- cost of ownership, CO₂, the input parser and the calendar

**Rule for the client-facing UI:** it shows results, never the method. That means no parameter names, formulas or standard names (§8).

---

## C. The three things to improve

### 1. Look and feel

- **The feel I want:** trustworthy, clean, simple and easy to understand. It should read as a serious industry tool, like software a consultancy or a bank would put out. It must not look like a flashy website, a generic AI chat app or a dated Windows program. It must not be soulless either.
- **Style reference: Apple's "Apple Devices" app for Windows** (screenshot attached). What I like about it:
  - Light, calm surfaces. A pale sidebar on the left, and the content on a slightly lighter panel.
  - A device header at the top: a simple line icon, a bold name and one quiet line of facts under it ("iPhone 12 mini · 122.48 GB (15.58 GB available)").
  - The sidebar holds grouped sections ("Settings", "On my device"). Each item has a thin line icon and a plain label. The selected item is marked by a short accent bar and a soft highlight, nothing heavier.
  - The content reads like a settings page: short section headings ("Options"), checkboxes and radio buttons with one-line explanations under them, and small bordered buttons ("Back Up Now", "Restore Backup…"). Buttons that can't be used yet are greyed out.
  - Status is shown in plain words ("Last backup: Never"). A slim progress bar at the bottom shows long tasks, with the time remaining and a Stop button.
  - Lots of white space, one accent colour, no shadows or gradients to speak of. It looks native and calm, not like a web page.
- Use that subtlety. You don't have to copy the layout.
- **Keep from the current mock-up:**
  - inputs and results on separate pages, with a Run button
  - an assistant panel the user can hide
  - icons in the menu
  - red and green used only where they mean something (over the limit, not ready, fits, cheaper)
  - "Illustrative sample data" visible at all times

### 2. Inputs

The input pages still feel like placeholders. Make them real, usable forms, built from section A.

- **Use the right control for each input:**
  - number fields with units
  - dropdowns for technology choices
  - the stop table as an editable table, following the editability rules in section A
  - file upload for GPS and standard routes
  - fields that only appear when they apply (for example the cab model)
- **Mark where every value came from:** your files, standard value, assumption, edited or missing. Missing inputs block Run. Edited values can be reset.
- **Basic vs advanced.** Each group shows the basic inputs first. More detailed inputs sit behind an "Advanced" control. Standard values are shown collapsed and can be overridden.
- **Two views of the same inputs: fleet owner and OEM.** My logic:
  - **Fleet owner:** sizing the battery and the chargers comes from how the trucks operate, not from exact product specs. So the fleet owner view is mostly routes, stops, timings, load, depot, grid and location.
  - **OEM** (vehicle or charger maker): takes the operations the fleet owner already entered as fixed, and enters their exact product specs to show how their product performs on that case. This is a bit like bidding on a tender. Product specs include mass, air drag, tyres, drivetrain, on-board systems, battery and charger data. Their values override the standard values.
  - The "Who" column in section A is my first split, but I am not sure it is right. Propose how it should work and explain your choice in the design note:
    - Should the OEM see the fleet owner's inputs locked?
    - How should a "Client / OEM" input behave?
    - How do several OEM offers sit side by side on the same case?
- **Engineering names stay hidden.** No parameter names, formulas or source names in the client views (§8). If you add an internal engineering view, it must be off by default.

### 3. Results

Right now each results page is a few numbers and one chart. Use what the engine really produces (section B) to show more useful data, better.

- Work out what a fleet owner, a municipality and an OEM each need in order to decide. Show that, in that order: the answer first, then why, then the detail.
- Suggest better visuals where they help. Not everything should be a chart, and not every chart should be a bar chart. Some data reads better as a table, a timeline, a single number with context, or a comparison.
- Some ideas you may use or drop:
  - where the energy goes on a trip (air, rolling, slope, on-board systems, stop equipment, recovered by braking)
  - a day profile of speed and battery power
  - the year at a glance: kWh per day, the worst days and why they are the worst
  - winter vs summer
  - the effect of the cab climate choice
  - load sensitivity
  - depot timeline, peak against connection, charging strategies compared, cost over time, an OEM offer compared on the same operations
  - what changed since the last run
- **Design full pages for every result,** including charging, battery, flexibility, cost (TCO), CO₂ and the OEM comparison. Use illustrative numbers and label them, but give these pages the same depth as the energy results.

## Rules

- **No invented numbers.** All numbers in the mock-up are illustrative. Use the existing sample case and the stand-in formulas already in the mock-up, and keep the "Illustrative sample data" label. If you need a new number, label it illustrative and list it in the design note.
- **The method stays hidden** (§8): no parameter names, formulas, standards, data source names or technical strategy names in the client-facing UI, the assistant text or the report.
- **One self-contained HTML file.** No build step and no external libraries apart from fonts. Hand-drawn SVG for charts. It must work offline on my laptop.
- **Readable on a laptop** (1366 × 768) and a desktop (1920 × 1080). Nothing overlaps, gets cut off or forces sideways scrolling.

## Deliverables

- **One HTML file, `hdev-ui-v3.html`, given straight to me.** Don't commit it, don't push it to GitHub and don't open a PR.
- At the end, tell me in plain text:
  - the design choices you made and why
  - how the fleet owner and OEM views work
  - which results you added and what decision each one helps with
  - every new illustrative number
  - anything from §8 that came close to being shown

Don't touch the engine code or the repo.
