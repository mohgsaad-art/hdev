# HDEV code snapshot (12 Oct 2026)

Bob's code as pasted on 12 Oct 2026, one section per file. Status headers inside each file. Also in the Kiro bundle zip.

## `src/charging/allocators_edf_es.py`

```python
# STATUS: CURRENT. EDF (earliest deadline first) and ES (equal share, water-filling) split the site target between vehicles.
# Pure functions of env state (do not mutate env).

import numpy as np

# --- EDF: earliest-deadline-first (import/export symmetric) ---
def edf_actions(env):
    """
    Return normalized actions in [-1,1] (non-V2G clipped to [0,1]) for all EVs.
    Uses env.* only; does not mutate env.
    """
    dt = float(env.dt)
    n  = env.number_evs
    present = env.present

    # per-EV import/export bounds (kW)
    need_kwh = np.where(present, np.maximum(env.power_needed, 0.0), 0.0)
    pmax_imp = np.minimum(need_kwh / dt, env.max_charging_rate)              # ≥ 0
    v2g_mask = present & env.v2g_capable & (env.soc_current > env.min_soc_v2g)
    v2g_head = np.where(v2g_mask,
                        np.maximum((env.soc_current - env.min_soc_v2g) * env.battery_capacity, 0.0),
                        0.0)
    pmax_exp = -np.minimum(v2g_head / dt, env.max_charging_rate)             # ≤ 0

    target_kw = float(env.station_capacity)
    alloc_kw  = np.zeros(n, dtype=float)

    if target_kw >= 0.0:
        # IMPORT: serve smallest time_left first
        order = np.argsort(np.where(present, env.time_left, np.inf))
        rem = target_kw
        for i in order:
            if not present[i] or rem <= 1e-9: break
            take = min(pmax_imp[i], rem)
            alloc_kw[i] = max(0.0, take)
            rem -= take
    else:
        # EXPORT: among V2G-capable with headroom, serve smallest time_left first
        valid = v2g_mask & (pmax_exp < -1e-9)
        order = np.argsort(np.where(valid, env.time_left, np.inf))
        rem = target_kw  # negative
        for i in order:
            if not valid[i] or rem >= -1e-9: break
            give = max(pmax_exp[i], rem)   # both ≤ 0
            alloc_kw[i] = min(0.0, give)
            rem -= give

    # kW -> normalized action
    a = alloc_kw / env.max_charging_rate
    a = np.where(env.v2g_capable, np.clip(a, -1.0, 1.0), np.clip(a, 0.0, 1.0))
    a = np.where(present, a, 0.0)
    return a.astype(np.float32)

# --- ES: equal-share with saturation (“water-filling”) ---
def es_actions(env):
    """
    Return normalized actions in [-1,1] (non-V2G clipped to [0,1]) for all EVs.
    """
    dt = float(env.dt)
    n  = env.number_evs
    present = env.present

    need_kwh = np.where(present, np.maximum(env.power_needed, 0.0), 0.0)
    pmax_imp = np.minimum(need_kwh / dt, env.max_charging_rate)              # ≥ 0
    v2g_mask = present & env.v2g_capable & (env.soc_current > env.min_soc_v2g)
    v2g_head = np.where(v2g_mask,
                        np.maximum((env.soc_current - env.min_soc_v2g) * env.battery_capacity, 0.0),
                        0.0)
    pmax_exp = -np.minimum(v2g_head / dt, env.max_charging_rate)             # ≤ 0

    target_kw = float(env.station_capacity)
    alloc_kw  = np.zeros(n, dtype=float)

    if target_kw >= 0.0:
        S = {i for i in range(n) if present[i] and pmax_imp[i] > 1e-9}
        rem = target_kw
        while S and rem > 1e-9:
            share = rem / len(S)
            gained = 0.0
            done = []
            for i in list(S):
                head = pmax_imp[i] - alloc_kw[i]
                inc  = min(share, max(0.0, head))
                alloc_kw[i] += inc
                gained += inc
                if alloc_kw[i] >= pmax_imp[i] - 1e-12:
                    done.append(i)
            rem = max(0.0, rem - gained)
            for i in done: S.discard(i)
    else:
        S = {i for i in range(n) if v2g_mask[i] and pmax_exp[i] < -1e-9}
        rem = target_kw  # negative
        while S and rem < -1e-9:
            share = rem / len(S)  # negative
            gained = 0.0
            done = []
            for i in list(S):
                # move alloc_kw[i] toward pmax_exp[i] (more negative), not beyond
                inc = max(share, pmax_exp[i] - alloc_kw[i])  # both ≤ 0
                alloc_kw[i] += inc
                gained += inc
                if abs(alloc_kw[i] - pmax_exp[i]) <= 1e-12:
                    done.append(i)
            rem = rem - gained
            for i in done: S.discard(i)

    a = alloc_kw / env.max_charging_rate
    a = np.where(env.v2g_capable, np.clip(a, -1.0, 1.0), np.clip(a, 0.0, 1.0))
    a = np.where(present, a, 0.0)
    return a.astype(np.float32)```

## `src/charging/ev_charging_env.py`

```python
# STATUS: CURRENT (thesis gym-style depot env). Pasted by Bob 12 Oct 2026.
# Physics-only env: presence, need, charger rate, site cap. Policies (ASAP/JIT/cheapest-first) set the site target outside the env.
# MADDPG/MARL is no longer part of HDEV; reward + observation code is thesis legacy (only needed by MARL).
# Known: reset() randomises everything (thesis training); hard-coded /21 normalisation; 21 h episode end in testers.
# Needs `import gym, numpy as np, from gym import spaces`.

###----ENVIRONMENT-----############
class EVChargingEnv(gym.Env):

    def __init__(self,
                 number_evs,                 # number of agents
                 max_station_capacity,       # Station capacity (kW)
                 max_steps,                  # max number of time steps in an episode
                 max_charging_rate,          # Max charging rate per EV (kW)
                 max_battery_capacity,       # Max possible battery capacity (kWh)
                 v2g_probability,            # V2G distribution in fleet
                 min_soc_v2g,                # Min SOC for V2G
                 max_soc_v2g,                # Max SOC for V2G
                 max_time,                   # max time horizon in hours (e.g., 12h)
                 dt):                        # time step in hours, e.g., 5/60
        super().__init__()

        # Initialize fixed variables
        self.number_evs = number_evs
        self.max_station_capacity = max_station_capacity
        self.max_steps = max_steps
        self.max_charging_rate = max_charging_rate
        self.max_battery_capacity = max_battery_capacity
        self.v2g_probability = v2g_probability
        self.min_soc_v2g = min_soc_v2g
        self.max_soc_v2g = max_soc_v2g
        self.max_time = max_time                    # <-- fixed (was simulation_time)
        self.dt = dt

        # Initialize arrays for multi-agent variables - to be initialized in reset()
        self.soc_arrival = np.zeros(self.number_evs, dtype=np.float32)
        self.soc_current = np.zeros(self.number_evs, dtype=np.float32)
        self.soc_required = np.zeros(self.number_evs, dtype=np.float32)
        self.time_left = np.zeros(self.number_evs, dtype=np.float32)
        self.battery_capacity = np.zeros(self.number_evs, dtype=np.float32)
        self.power_needed = np.zeros(self.number_evs, dtype=np.float32)
        self.v2g_capable = np.zeros(self.number_evs, dtype=bool)   # v2g flag
        self.station_capacity = 0.0
        self.current_step = 0
        self.departed_flag = None
        self.activation_mask = None

        # NEW: arrivals / departures / presence / episode clock
        self.arrival_time = np.zeros(self.number_evs, dtype=np.float32)   # hours since episode start
        self.depart_time  = np.zeros(self.number_evs, dtype=np.float32)   # hours since episode start
        self.present      = np.zeros(self.number_evs, dtype=bool)         # plugged/inside window flag
        self.time_now     = 0.0
        self.feasible_import = 0.0
        self.feasible_export = 0.0
        self.schedule      = np.zeros(self.max_steps, dtype=np.float32)


        ## Observation space - flattened observation for ALL EVs
        # Per-EV features: [need_norm, signed_time, station_norm, feasible_import, feasible_export, v2g_flag]
        self.observation_space = spaces.Box(low=-1.0, high=1.0, shape=(self.number_evs * 6,), dtype=np.float32)

        ## Action space - flattened action for ALL EVs (normalized)
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.number_evs,), dtype=np.float32)

    ###----RESET-----############
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        rng = np.random.default_rng(seed)


        ## Value assigning
        self.soc_arrival = rng.uniform(0.1, 0.99, size=self.number_evs).astype(np.float32)
        self.soc_current = self.soc_arrival.copy()
        self.soc_required = rng.uniform(self.soc_arrival, 1.0, size=self.number_evs).astype(np.float32)

        # Episode clock
        self.time_now = 0.0

        # Arrivals during this episode window; departures up to max_time
        abs_arrival_time = rng.uniform(0.0, 5.0, size=self.number_evs).astype(np.float32)
        abs_depart_time = rng.uniform(14.0, 18.0, size=self.number_evs).astype(np.float32)
        dwell = abs_depart_time - abs_arrival_time

        snippet_time = rng.uniform(0.0, 21.0-1.0)

        self.arrival_time = abs_arrival_time - snippet_time
        self.depart_time  = abs_depart_time  - snippet_time

        self.present = (self.arrival_time <= self.time_now) & (self.time_now < self.depart_time)

        # Presence at t=0 and time_left (only for present EVs)
        ##---self.present = (self.arrival_time <= self.time_now) & (self.time_now < self.depart_time)
        self.time_left = np.where(self.present, self.depart_time - self.time_now, 0.0).astype(np.float32) # used for book keeping i guess

        self.battery_capacity = rng.choice([380,480,600], size=self.number_evs).astype(np.float32)
        self.power_needed = (self.soc_required - self.soc_arrival) * self.battery_capacity
        self.inital_power_needed = self.power_needed.copy()

        #self.v2g_probability = rng.choice([0.0, 0.2 ,0.5, 0.75, 1.0])
        self.v2g_capable = rng.random(self.number_evs) < self.v2g_probability

       #--self.station_capacity = rng.uniform(-300, 300)  # kW

        self.current_step = 0

        #self.station_capacity = float(self.schedule[0]) if (self.activation_mask and self.schedule.size) else 0.0
        number_present_evs = np.sum(self.present)
        is_v2g_present = np.where(self.present & self.v2g_capable, 1.0, 0.0)
        number_v2g_present = np.sum(is_v2g_present)
        self.station_capacity = rng.uniform(-(number_v2g_present*self.max_charging_rate) ,self.number_evs * self.max_charging_rate)

        #Calculate feasible headrooms
        per_ev_power_need = np.where(self.present, np.maximum(self.power_needed,0.0), 0.0)
        capped_power_per_ev = np.minimum(per_ev_power_need/self.dt, self.max_charging_rate)
        sum_capped_power = np.sum(capped_power_per_ev)
        self.feasible_import = float( np.minimum(sum_capped_power, self.max_station_capacity))

        per_ev_headroom = np.where(self.present & self.v2g_capable & (self.soc_current > self.min_soc_v2g), (self.soc_current-self.min_soc_v2g) * self.battery_capacity, 0.0)
        capped_headroom_per_ev = np.minimum(per_ev_headroom/self.dt, self.max_charging_rate)
        sum_capped_headroom = np.sum(capped_headroom_per_ev)
        self.feasible_export = - float(np.minimum(sum_capped_headroom, self.max_station_capacity))

        # Signed time

        time_to_arrival = np.maximum(0.0, self.arrival_time - self.time_now)
        time_to_depart  = np.maximum(0.0, self.depart_time  - self.time_now)
        signed_time = np.where(self.present, time_to_depart, -time_to_arrival) / 21
        signed_time = signed_time.astype(np.float32)


        # Build observation
        normalized_power_needed = np.where(self.present, self.power_needed / self.max_battery_capacity, 0.0).astype(np.float32) #mask need for absent EVs
        normalized_station_capacity = np.full(self.number_evs, (self.station_capacity / self.max_station_capacity), dtype=np.float32)
        normalized_feasible_import = np.full(self.number_evs, (self.feasible_import / self.max_station_capacity), dtype=np.float32)
        normalized_feasible_export = np.full(self.number_evs, (self.feasible_export / self.max_station_capacity), dtype=np.float32)

        normalized_v2g = self.v2g_capable.astype(np.float32)


        obs_2d = np.stack([normalized_power_needed, signed_time, normalized_station_capacity, normalized_feasible_import, normalized_feasible_export, normalized_v2g], axis=-1)
        obs = obs_2d.flatten().astype(np.float32)

        return obs, {}

    ###----REWARD-----############
    def calculate_reward(self, power_delivered: np.array, net_exec_kw: np.array,overshoot_ev: np.array):

        weight_step_reward = 0.00
        weight_step_penalty = -1
        weight_terminal_reward = 0
        weight_terminal_penalty = -0
        cost_of_degradation = -0.125
        weight_grid_following = -2


        #grid following penalty
        feasible_tracking = np.clip (self.station_capacity, self.feasible_export, self.feasible_import)
        err_kw = max(0.0, abs(float(net_exec_kw) - float(feasible_tracking)) -0.125) #-0.5
        grid_following_penalty = weight_grid_following * err_kw
        #commented out -- grid_following_penalty = (np.abs(feasible_tracking - net_exec_kw) - 0.5) * weight_grid_following #deadnband of .5kW

        # over shoot penalty - overshoot SOC, overshoot raw more than whats feasible or legal prior to scaling
        overshoot_penalty = np.sum(overshoot_ev)
        #station_cap_penalty = np.clip(np.abs(np.sum(self.raw_power_delivered)) - np.abs(self.max_station_capacity), 0.0, None)
        step_penalty = ( overshoot_penalty) * weight_step_penalty

        # Cycling penalty
        #--cycling_penalty = cost_of_degradation * np.sum(np.abs(power_delivered))
        cycling_penalty = cost_of_degradation * np.sum(np.clip(power_delivered, 0.0, None)) + cost_of_degradation * (1.0 + float(feasible_tracking >= 0.0)) * np.sum(np.clip(-power_delivered, 0.0, None))

        #step rewards
        step_reward = np.sum(np.clip(power_delivered, 0.0, None)) * weight_step_reward # reward positive Kwh provided

        '''# Terminal rewards (kept as-is; based on time_left transitions) -- inactive for now
        success = np.isclose(self.power_needed, 0, atol=0.5)
        matches = self.departed_flag & success
        misses = self.departed_flag & ~success
        terminal_reward = np.sum(matches) * weight_terminal_reward
        terminal_penalty = np.sum(np.abs(self.power_needed[misses])) * weight_terminal_penalty  '''
        terminal_reward = 0.0
        terminal_penalty = 0.0

        total_reward = terminal_reward + terminal_penalty + step_reward + step_penalty + cycling_penalty + grid_following_penalty

        return total_reward, terminal_reward, terminal_penalty, step_reward, step_penalty, cycling_penalty,  grid_following_penalty

    ###----STEP-----############
    def step(self, action: np.array):

        #Presence BEFORE acting
        present_prev = self.present.copy()

        # Clip - no action if EV not present
        action = np.where(present_prev, action, 0.0)

        # Clip - action for V2G / non-V2G
        action = np.where(self.v2g_capable, np.clip(action, -1, 1), np.clip(action, 0, 1))

        # Clip - action if no time left
        action = np.where(self.time_left <= 0, 0, action)

        # SOC padding for V2G lower limit + full battery clamp
        action = np.where((self.soc_current <= self.min_soc_v2g) & (action < 0), 0, action)

        action = np.where((self.soc_current >= 1) & (action > 0), 0, action) # now blocks only charge not discharge
        #action = np.where(self.soc_current >= 1, 0, action)

        # Convert to kW
        action_kw = action * self.max_charging_rate

        prev_time_left = self.time_left.copy()

        # Energy delivered this step (kWh)
        raw_power_delivered = action_kw * self.dt

        # Raw charge and discharge delivered
        raw_charge_delivered = np.clip (raw_power_delivered, 0.0, None)
        raw_discharge_delivered = np.clip (-raw_power_delivered, 0.0 , None)

        charge_need = np.where(present_prev, np.clip(self.power_needed, 0.0, None), 0.0)
        charge_headroom = np.where(present_prev , np.clip((1-self.soc_current)*self.battery_capacity,0.0,None), 0.0)

        v2g_mask = present_prev & self.v2g_capable & (self.soc_current > self.min_soc_v2g)
        discharge_headroom = np.where(v2g_mask, np.clip ((self.soc_current-self.min_soc_v2g)*self.battery_capacity, 0.0,None),0.0)

        #effective charge delivered
        charge_delivered = np.minimum (raw_charge_delivered, np.minimum(charge_need, charge_headroom))
        discharge_delivered = np.minimum (raw_discharge_delivered, discharge_headroom)

        power_delivered = charge_delivered - discharge_delivered # constructing back the array after clips and giving discharge back the -ve sign
        overshoot_ev = (raw_charge_delivered - charge_delivered) + (raw_discharge_delivered - discharge_delivered)  # kWh ≥ 0: array containing overshoots for each EV

        #Calculate feasible headrooms + calculate each step as did in reset()
        per_ev_power_need = np.where(self.present, np.maximum(self.power_needed,0.0), 0.0)
        capped_power_per_ev = np.minimum(per_ev_power_need/self.dt, self.max_charging_rate)
        sum_capped_power = np.sum(capped_power_per_ev)
        self.feasible_import = float( np.minimum(sum_capped_power, self.max_station_capacity))

        per_ev_headroom = np.where(self.present & self.v2g_capable & (self.soc_current > self.min_soc_v2g), (self.soc_current-self.min_soc_v2g) * self.battery_capacity, 0.0)
        capped_headroom_per_ev = np.minimum(per_ev_headroom/self.dt, self.max_charging_rate)
        sum_capped_headroom = np.sum(capped_headroom_per_ev)
        self.feasible_export = - float(np.minimum(sum_capped_headroom, self.max_station_capacity))

        # Station capacity scaling
        net_action_kw = np.sum(power_delivered/self.dt)

        if abs(net_action_kw) > self.max_station_capacity:
            power_delivered = power_delivered * (self.max_station_capacity / abs(net_action_kw))

        #cache , power_delivered is in kWh ,net_action_kw is in kW total site usage, action_kw_per_ev is kW per ev,
        net_exec_kw = float(np.sum(power_delivered/self.dt))
        action_kw_per_ev = power_delivered / self.dt

        fi_used = self.feasible_import
        fe_used = self.feasible_export

        # Reward (unchanged interface) to be worked on next ignore for now
        reward, terminal_reward, terminal_penalty, step_reward, step_penalty, cycling_penalty, grid_following_penalty =  self.calculate_reward(power_delivered, net_exec_kw, overshoot_ev)

        # Update power need and SOC ; np.max helps tiny negative floating points i hope
        self.power_needed = np.maximum(self.power_needed - power_delivered, 0.0) # effective chagre reduces power_need, effective dischrge increase power_need
        self.soc_current = np.clip(self.soc_current + power_delivered / (self.battery_capacity + 1e-9), 0, 1.0)

        # Advance clock and recompute presence / time_left
        self.time_now += self.dt
        self.present = (self.arrival_time <= self.time_now) & (self.time_now < self.depart_time)
        self.time_left = np.where(self.present, self.depart_time - self.time_now, 0.0).astype(np.float32)

        # Who departed exactly this step
        self.departed_flag = (~self.present) & present_prev

        self.current_step += 1

        #Calculate feasible headrooms + calculate each step as did in reset()
        per_ev_power_need = np.where(self.present, np.maximum(self.power_needed,0.0), 0.0)
        capped_power_per_ev = np.minimum(per_ev_power_need/self.dt, self.max_charging_rate)
        sum_capped_power = np.sum(capped_power_per_ev)
        self.feasible_import = float( np.minimum(sum_capped_power, self.max_station_capacity))

        per_ev_headroom = np.where(self.present & self.v2g_capable & (self.soc_current > self.min_soc_v2g), (self.soc_current-self.min_soc_v2g) * self.battery_capacity, 0.0)
        capped_headroom_per_ev = np.minimum(per_ev_headroom/self.dt, self.max_charging_rate)
        sum_capped_headroom = np.sum(capped_headroom_per_ev)
        self.feasible_export = - float(np.minimum(sum_capped_headroom, self.max_station_capacity))

        # Build observation (same as in reset)
        normalized_power_needed = np.where(self.present, self.power_needed / self.max_battery_capacity, 0.0).astype(np.float32)

        time_to_arrival = np.maximum(0.0, self.arrival_time - self.time_now)
        time_to_depart = np.maximum(0.0, self.depart_time  - self.time_now)
        signed_time = np.where(self.present, +time_to_depart, -time_to_arrival) / 21.0
        signed_time = signed_time.astype(np.float32)


        normalized_station_capacity = np.full(self.number_evs, (self.station_capacity / self.max_station_capacity), dtype=np.float32)

        normalized_feasible_import = np.full(self.number_evs, (self.feasible_import / self.max_station_capacity), dtype=np.float32)
        normalized_feasible_export = np.full(self.number_evs, (self.feasible_export / self.max_station_capacity), dtype=np.float32)


        normalized_v2g = self.v2g_capable.astype(np.float32)

        obs_2d = np.stack([normalized_power_needed, signed_time, normalized_station_capacity, normalized_feasible_import, normalized_feasible_export, normalized_v2g], axis=-1)
        obs = obs_2d.flatten().astype(np.float32)

        # Termination: episode horizon only
        terminated = (self.current_step >= self.max_steps)
        truncated = False

        info = {
            "cycling_penalty": cycling_penalty,
            "soc_current": self.soc_current.copy(),
            "soc_arrival": self.soc_arrival.copy(),
            "soc_required": self.soc_required.copy(),
            "power_needed": self.power_needed.copy(),
            "battery_capacity": self.battery_capacity.copy(),
            "time_left": self.time_left.copy(),
            "arrival_time": self.arrival_time.copy(),
            "depart_time": self.depart_time.copy(),
            "present": self.present.copy(),
            "v2g_capable": self.v2g_capable.copy(),
            "station_capacity": self.station_capacity,
            "power_delivered": power_delivered.copy(),
            "terminal_reward": terminal_reward,
            "terminal_penalty": terminal_penalty,
            "step_reward": step_reward,
            "step_penalty": step_penalty,
            "reward": reward,
            "prev_time_left": prev_time_left.copy(),
            "departed_flag": self.departed_flag.copy(),
            "terminated": terminated,
            "grid_following_penalty": grid_following_penalty,
            "net_exec_kw": net_exec_kw,
            "feasible_import": self.feasible_import,
            "feasible_export": self.feasible_export,
            "fi_used": fi_used,
            "fe_used": fe_used,
            "overshoot_ev": overshoot_ev,


        }

        return obs, reward, terminated, truncated, info```

## `src/charging/flexibility_setpoints.py`

```python
# STATUS: CURRENT ("my flexibility code", pasted by Bob 12 Oct 2026).
# Site setpoint policies (JIT, ASAP) + feasibility headroom (import/export). These live OUTSIDE the env (decided).
# Flexibility (thesis): energy-neutral up/down headroom between feasible_export and feasible_import.
# Planned: a cheapest-first setpoint using hourly prices (Energidataservice spot + tariffs) - not written.
# Note: overlaps with helpers in tester_21h_maddpg.py (duplicate definitions).
import numpy as np

# --- physics feasibility (import/export heads) ---
def refresh_feasibility(env):
    per_ev_need_kwh = np.where(env.present, np.maximum(env.power_needed, 0.0), 0.0)
    cap_imp = np.minimum(per_ev_need_kwh / env.dt, env.max_charging_rate)
    Pmax = float(min(np.sum(cap_imp), env.max_station_capacity))

    v2g_mask = env.present & env.v2g_capable & (env.soc_current > env.min_soc_v2g)
    v2g_head = np.where(v2g_mask,
                        np.maximum((env.soc_current - env.min_soc_v2g) * env.battery_capacity, 0.0),
                        0.0)
    cap_exp = np.minimum(v2g_head / env.dt, env.max_charging_rate)
    Pmin = -float(min(np.sum(cap_exp), env.max_station_capacity))

    env.feasible_import = Pmax
    env.feasible_export = Pmin
    return Pmin, Pmax

# --- build the 6-feature obs your Actor expects ---
def build_obs_from_env(env):
    time_to_arr = np.maximum(0.0, env.arrival_time - env.time_now)
    time_to_dep = np.maximum(0.0, env.depart_time  - env.time_now)
    signed_time = np.where(env.present, +time_to_dep, -time_to_arr) / env.max_time

    refresh_feasibility(env)  # make sure feas_* reflect THIS state
    need_norm  = np.where(env.present, env.power_needed / env.max_battery_capacity, 0.0).astype(np.float32)
    stat_norm  = np.full(env.number_evs, env.station_capacity / env.max_station_capacity, dtype=np.float32)
    feas_imp_n = np.full(env.number_evs, env.feasible_import / env.max_station_capacity, dtype=np.float32)
    feas_exp_n = np.full(env.number_evs, env.feasible_export / env.max_station_capacity, dtype=np.float32)
    v2g_float  = env.v2g_capable.astype(np.float32)

    obs_2d = np.stack([need_norm, signed_time.astype(np.float32), stat_norm, feas_imp_n, feas_exp_n, v2g_float], axis=-1)
    return obs_2d.flatten().astype(np.float32)

# --- baselines ---
def jit_setpoint(env):
    """Per-EV avg power to finish exactly by departure; cap by physics/site."""
    present = env.present
    need_kwh = np.where(present, np.maximum(env.power_needed, 0.0), 0.0)
    t_left   = np.where(present, np.maximum(env.time_left, env.dt), env.dt)
    per_ev   = np.minimum(need_kwh / t_left, env.max_charging_rate)  # kW
    refresh_feasibility(env)
    return float(min(per_ev.sum(), env.feasible_import, env.max_station_capacity))

def asap_setpoint(env):
    """Fast-as-possible import (no export)."""
    refresh_feasibility(env)
    return float(max(0.0, env.feasible_import))

def site_target(env, mode="JIT"):
    mode = (mode or "JIT").upper()
    return jit_setpoint(env) if mode == "JIT" else asap_setpoint(env)
```

## `src/charging/run_allocator_21h.py`

```python
# STATUS: CURRENT RUNNER (EDF/ES/MARL selectable; MARL path is legacy). Fixed 21 h horizon = known limitation.

import numpy as np
import matplotlib.pyplot as plt

# Optional tiny wrapper so MARL matches the same call
class MARLController:
    def __init__(self, maddpg): self.maddpg = maddpg
    def select_actions(self, obs): return self.maddpg.select_actions(obs, add_noise=False)

def run_allocator_21h(env, *, allocator="EDF", baseline="JIT",
                      custom_params=None, maddpg=None, time_in_hours=False):


    # --- bind allocator ---
    alloc_name = (allocator or "EDF").upper()
    if alloc_name == "MARL":
        assert maddpg is not None, "MARL selected but maddpg=None"
        controller = MARLController(maddpg)
    elif alloc_name == "EDF":
        controller = "EDF"
    elif alloc_name == "ES":
        controller = "ES"
    else:
        raise ValueError("allocator must be EDF, ES or MARL")

    # --- day horizon ---
    day_steps = int(round(21.0 / env.dt))
    env.max_steps= day_steps
    env.max_time= 21.0

    # --- reset + (optional) overwrite with custom sampler params ---
    obs, _ = env.reset(seed=42)
    if custom_params:
        env.time_now  = float(custom_params.get('time_now', 0.0))
        env.arrival_time = np.array(custom_params['arrival_time'],dtype=np.float32)
        env.depart_time = np.array(custom_params['depart_time'], dtype=np.float32)
        env.soc_arrival= np.array(custom_params['soc_arrival'],dtype=np.float32)
        env.soc_required= np.array(custom_params['soc_required'], dtype=np.float32)
        env.battery_capacity= np.array(custom_params['battery_capacity'],dtype=np.float32)
        env.v2g_capable = np.array(custom_params['v2g_capable'], dtype=bool)
        env.soc_current = env.soc_arrival.copy()
        env.power_needed= (env.soc_required - env.soc_current) * env.battery_capacity
        env.inital_power_needed = env.power_needed.copy()

    # anchor earliest arrival at t=0
    shift = max(0.0, -float(np.min(env.arrival_time)))
    env.arrival_time+= shift
    env.depart_time += shift
    env.time_now = 0.0
    env.present   = (env.arrival_time <= env.time_now) & (env.time_now < env.depart_time)
    env.time_left = np.where(env.present, env.depart_time - env.time_now, 0.0).astype(np.float32)
    env.current_step = 0

    # keep absolute hours for plotting
    arrivals_h   = env.arrival_time.copy()
    departures_h = env.depart_time.copy()

    # initial setpoint + obs
    env.station_capacity = site_target(env, baseline)
    obs = build_obs_from_env(env)

    # --- traces ---
    n = env.number_evs
    soc_traces   = [[env.soc_current[i]] for i in range(n)]
    power_traces = [[] for _ in range(n)]
    reward_tr    = []
    net_kw_tr    = []
    sp_kw_tr     = []
    times        = [0]
    dep_step     = [None]*n
    soc_arrival_plot  = env.soc_arrival.copy()
    soc_required_plot = env.soc_required.copy()

    # --- loop ---
    t, done = 0, False
    while not done and t < day_steps:
        env.station_capacity = site_target(env, baseline)

        if alloc_name == "MARL":
            actions = controller.select_actions(obs).flatten()
        elif alloc_name == "EDF":
            actions = edf_actions(env).flatten()
        else:
            actions = es_actions(env).flatten()

        next_obs, reward, terminated, truncated, info = env.step(actions)
        obs, done = next_obs, (terminated or truncated)
        t += 1
        times.append(t)

        # logs
        reward_tr.append(reward)
        net_kw_tr.append(info["net_exec_kw"])
        sp_kw_tr.append(env.station_capacity)
        for i in range(n):
            power_traces[i].append(info["power_delivered"][i])
            if dep_step[i] is None and bool(info["departed_flag"][i]):
                dep_step[i] = t
            soc_traces[i].append(env.soc_current[i])

    # --- plots ---
    plot_hdev_day(times, soc_traces, power_traces,
                  net_kw_tr, sp_kw_tr, reward_tr,
                  soc_arrival_plot, soc_required_plot,
                  arrivals_h, departures_h,
                  env.max_station_capacity, env.dt, time_in_hours=time_in_hours)

# --- compact plotting, side-by-side per HDEV; net power in separate fig ---
def plot_hdev_day(times, soc_traces, power_traces,
                  net_power_traces, setpoint_traces, reward_traces,
                  soc_arrival, soc_required, arrivals_h, departures_h,
                  max_station_capacity, dt, *, time_in_hours=False):


    x_soc  = np.asarray(times)      * (dt if time_in_hours else 1.0)
    x_step = np.asarray(times[1:])  * (dt if time_in_hours else 1.0)
    xlab   = "Hour" if time_in_hours else "Step"

    def hour_to_axis(h):
        return float(h) if time_in_hours else float(h)/float(dt)

    n = len(soc_traces)
    # CHANGE 1: Swapped (2, n) to (n, 2) and adjusted figsize for a vertical layout.
    fig, axs = plt.subplots(n, 2, figsize=(12, 4 * n), squeeze=False)

    for i in range(n):
        # CHANGE 2: Updated subplot index from [0, i] to [i, 0] for the SOC plot (left column).
        ax = axs[i, 0]
        ax.plot(x_soc, soc_traces[i], label=f'HDEV {i+1} SOC')
        ax.axhline(soc_arrival[i],  color='gray',   linestyle='--', label='Arrival SOC')
        ax.axhline(soc_required[i], color='orange', linestyle='--', label='Requested SOC')
        ax.axvline(hour_to_axis(arrivals_h[i]),  color='green', linestyle=':', label='Arrival')
        ax.axvline(hour_to_axis(departures_h[i]),color='red',   linestyle=':', label='Departure')
        ax.set_ylabel('SOC'); ax.set_xlabel(xlab)
        ax.set_title(f'HDEV {i+1} SOC ')
        ax.set_ylim(0, 1.05); ax.grid(True); ax.legend(loc='lower right')

        kw = np.asarray(power_traces[i]) / float(dt)
        # CHANGE 3: Updated subplot index from [1, i] to [i, 1] for the Power plot (right column).
        axp = axs[i, 1]
        axp.step(x_step, kw, where='post', color='green', label=f'HDEV {i+1} Power (kW)')
        axp.axvline(hour_to_axis(arrivals_h[i]),  color='green', linestyle=':')
        axp.axvline(hour_to_axis(departures_h[i]),color='red',   linestyle=':')
        axp.axhline(0.0, color='k', lw=0.8)
        axp.set_ylabel('kW'); axp.set_xlabel(xlab)
        axp.set_title(f'HDEV {i+1} Power per Step')
        axp.grid(True); axp.legend()
        axp.set_ylim(0,155)

    plt.tight_layout(); plt.show()

    # --- This part of the code remains unchanged ---
    plt.figure(figsize=(12,5))
    plt.step(x_step, net_power_traces, where='post', label='Net Power (kW)')
    plt.step(x_step, setpoint_traces,  where='post', linestyle='--', label='Target (kW)')
    for i in range(n):
        plt.axvline(hour_to_axis(arrivals_h[i]),  color='green', alpha=0.15, linestyle=':')
        plt.axvline(hour_to_axis(departures_h[i]),color='red',   alpha=0.15, linestyle=':')
    plt.axhline(0.0, color='k', lw=0.8)
    plt.ylabel('kW'); plt.xlabel(xlab)
    plt.title('Site Net Power vs. Target ')
    plt.ylim(-max_station_capacity, max_station_capacity*1.1)
    plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()

    plt.figure(figsize=(10,5))
    plt.plot(x_step, reward_traces, color='b', label='Total Reward')
    plt.xlabel(xlab); plt.ylabel('Reward'); plt.title('Per-step Reward')
    plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()
```

## `src/charging/tester_21h_maddpg.py`

```python
# STATUS: THESIS TESTER (uses maddpg). Kept for reference: jit_setpoint, refresh_feasibility, site_target, plotting.
# The 21 h fixed episode is the known problem for multi-day sessions (see docs/design/year-and-day-simulation-problem.md).

import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# JIT site setpoint (kW) helper
# -----------------------------
def jit_setpoint(env):
    """
    Compute the physics-only JIT site target (kW) from the *current* env state.
    Does NOT modify the env—caller sets env.station_capacity explicitly.
    """
    present = env.present
    need_kwh = np.where(present, np.maximum(env.power_needed, 0.0), 0.0)
    t_left   = np.where(present, np.maximum(env.time_left, env.dt), env.dt)  # hours
    per_ev_avg_kw = np.minimum(need_kwh / t_left, env.max_charging_rate)
    # Cap by physics
    return float(min(per_ev_avg_kw.sum(), env.feasible_import, env.max_station_capacity))

# --- helpers for testing (unchanged semantics) ---
def refresh_feasibility(env):
    """Recompute env.feasible_import/export from CURRENT state (pre-step)."""
    # Charge (import) cap
    per_ev_need_kwh = np.where(env.present, np.maximum(env.power_needed, 0.0), 0.0)
    cap_charge_kw_per_ev = np.minimum(per_ev_need_kwh / env.dt, env.max_charging_rate)
    Pmax = float(min(np.sum(cap_charge_kw_per_ev), env.max_station_capacity))  # ≥ 0

    # Discharge (export) cap
    v2g_mask = env.present & env.v2g_capable & (env.soc_current > env.min_soc_v2g)
    v2g_headroom_kwh = np.where(
        v2g_mask,
        np.maximum((env.soc_current - env.min_soc_v2g) * env.battery_capacity, 0.0),
        0.0
    )
    cap_discharge_kw_per_ev = np.minimum(v2g_headroom_kwh / env.dt, env.max_charging_rate)
    Pmin = -float(min(np.sum(cap_discharge_kw_per_ev), env.max_station_capacity))  # ≤ 0

    env.feasible_import = Pmax
    env.feasible_export = Pmin
    return Pmin, Pmax

def build_obs_from_env(env):
    """Build the 6-feature observation per EV to match Actor(obs_dim=6)."""
    # Signed time
    time_to_arrival = np.maximum(0.0, env.arrival_time - env.time_now)
    time_to_depart  = np.maximum(0.0, env.depart_time  - env.time_now)
    signed_time = np.where(env.present, +time_to_depart, -time_to_arrival) / env.max_time
    signed_time = signed_time.astype(np.float32)

    # Other features
    need_norm = np.where(env.present, env.power_needed / env.max_battery_capacity, 0.0).astype(np.float32)
    station_norm = np.full(env.number_evs, env.station_capacity / env.max_station_capacity, dtype=np.float32)
    v2g_float = env.v2g_capable.astype(np.float32)

    # Make sure feasibility is up-to-date for THIS state
    refresh_feasibility(env)
    feas_imp_norm = np.full(env.number_evs, env.feasible_import / env.max_station_capacity, dtype=np.float32)
    feas_exp_norm = np.full(env.number_evs, env.feasible_export / env.max_station_capacity, dtype=np.float32)

    obs_2d = np.stack(
        [need_norm, signed_time, station_norm, feas_imp_norm, feas_exp_norm, v2g_float],
        axis=-1
    )
    return obs_2d.flatten().astype(np.float32)

# -----------------------------
# Site target selector (JIT/ASAP)
# -----------------------------
def site_target(env, mode="JIT"):
    """
    mode = "JIT"  -> jit_setpoint()
    mode = "ASAP" -> charge as fast as physics allows (import cap, non-negative)
    """
    refresh_feasibility(env)
    mode = (mode or "JIT").upper()
    if mode == "ASAP":
        return float(max(0.0, env.feasible_import))
    return float(jit_setpoint(env))

# -------------------------------------------------
# MAIN TESTER: 21-hour baseline (JIT or ASAP) w/ logging
# -------------------------------------------------
def test_policy_21h_with_logging(env, maddpg, baseline_mode="JIT",
                                 n_days=1, custom_params=None):
    """
    Runs a *single 21-hour* episode per day. The tester computes the site target each step
    (JIT or ASAP) and writes env.station_capacity BEFORE env.step(...).
    Optional activation can be passed via custom_params:
        {'activate_at': int, 'A': float, 'activation_steps': int}
    All other custom_params fields match your previous tester.
    """
    # Force a 21h day (continuous episode)
    day_steps = int(round(21.0 / env.dt))
    env.max_steps = day_steps
    env.max_time  = 21.0

    for day in range(n_days):
        # Reset environment (random), then *anchor start-of-day at t=0*
        obs, _ = env.reset(seed=44 + day)

        # Optional: override with custom_params (same fields as before)
        if custom_params:
            # --- override core fields ---
            if 'time_now' in custom_params:
                env.time_now = float(custom_params['time_now'])

            if 'arrival_time' in custom_params:
                env.arrival_time = np.array(custom_params['arrival_time'], dtype=np.float32)
            if 'depart_time' in custom_params:
                env.depart_time  = np.array(custom_params['depart_time'], dtype=np.float32)

            if 'soc_arrival' in custom_params:
                env.soc_arrival = np.array(custom_params['soc_arrival'], dtype=np.float32)
                env.soc_current = env.soc_arrival.copy()
            if 'soc_required' in custom_params:
                env.soc_required = np.array(custom_params['soc_required'], dtype=np.float32)
            if 'battery_capacity' in custom_params:
                env.battery_capacity = np.array(custom_params['battery_capacity'], dtype=np.float32)
            if 'v2g_capable' in custom_params:
                env.v2g_capable = np.array(custom_params['v2g_capable'], dtype=bool)

            # derived
            env.power_needed = (env.soc_required - env.soc_current) * env.battery_capacity
            env.inital_power_needed = env.power_needed.copy()

        # Anchor the day so earliest arrival is at/after t=0
        shift = max(0.0, -float(np.min(env.arrival_time)))
        env.arrival_time += shift
        env.depart_time  += shift
        env.time_now = 0.0
        env.present   = (env.arrival_time <= env.time_now) & (env.time_now < env.depart_time)
        env.time_left = np.where(env.present, env.depart_time - env.time_now, 0.0).astype(np.float32)
        env.current_step = 0

        # Initial target & obs
        env.station_capacity = site_target(env, baseline_mode)
        obs = build_obs_from_env(env)

        # Activation knobs (optional)
        activate_at = None if not custom_params else custom_params.get('activate_at', None)
        A = 0.0 if not custom_params else float(custom_params.get('A', 0.0))
        activation_steps = 3 if not custom_params else int(custom_params.get('activation_steps', 3))
        act_left = 0

        # ---- day header ----
        print("="*60)
        print(f"Day {day+1}  (21h, baseline={baseline_mode})")
        print("V2G flags:            ", env.v2g_capable)
        print("Battery capacities:   ", np.round(env.battery_capacity, 1))
        print("Initial SOCs:         ", np.round(env.soc_arrival, 3))
        print("Requested SOCs:       ", np.round(env.soc_required, 3))
        print("Initial present:      ", env.present)
        print("Initial target (kW):  ", np.round(env.station_capacity, 2))
        print("-"*60)

        # ---- traces ----
        soc_traces = [[] for _ in range(env.number_evs)]
        power_traces = [[] for _ in range(env.number_evs)]
        timeleft_traces = [[] for _ in range(env.number_evs)]
        reward_traces = []
        net_power_traces = []
        setpoint_traces = []  # target each step
        reward_breakdowns = {k: [] for k in ["terminal_reward", "terminal_penalty", "step_reward", "step_penalty", "cycling_penalty", "grid_following_penalty"]}
        times = []
        departures = [None for _ in range(env.number_evs)]
        t = 0
        done = False

        # Store arrivals/targets for plotting
        soc_arrival_plot = env.soc_arrival.copy()
        soc_required_plot = env.soc_required.copy()

        # seed traces at t=0
        for i in range(env.number_evs):
            soc_traces[i].append(env.soc_current[i])
            timeleft_traces[i].append(env.time_left[i])
        times.append(0)

        # Print header for the table-like output
        header = [
            "Step", "Actions (Norm)", "Power Delivered (kWh)", "Net Power (kW)",
            "target_used(kW)", "Prev Time Left (h)", "Time Left (h)", "Departure Flag",
            "Terminated", "SOCs", "Total Reward", "Terminal Penalty", "Terminal Reward",
            "Step Penalty", "Step Reward", "Cycling Penalty", "grid_following_penalty",
            "fi_used", "fe_used"
        ]
        print(" | ".join(header))
        print("-" * (len(" | ".join(map(str, header))) + 2 * len(header)))  # separator line

        while not done and t < day_steps:
            # 1) Compute baseline site target
            refresh_feasibility(env)
            base_kw = site_target(env, baseline_mode)

            # 2) Optional activation
            if (activate_at is not None) and (env.current_step == int(activate_at)):
                act_left = int(activation_steps)
            desired_kw = np.clip(base_kw + (A if act_left > 0 else 0.0),
                                 env.feasible_export, env.feasible_import)
            act_left = max(0, act_left - 1)

            # 3) Feed the target into env BEFORE acting
            env.station_capacity = float(desired_kw)

            # 4) Policy acts (maddpg style)
            actions = maddpg.select_actions(obs, add_noise=False)
            action_vec = actions.flatten()

            # 5) Step
            next_obs, reward, terminated, truncated, info = env.step(action_vec)
            obs = next_obs
            done = terminated or truncated
            t += 1
            times.append(t)
            reward_traces.append(reward)

            # 6) Logs
            net_power_traces.append(info["net_exec_kw"])     # kW
            setpoint_traces.append(desired_kw)               # kW

            for k in reward_breakdowns:
                reward_breakdowns[k].append(info[k])

            for i in range(env.number_evs):
                power_traces[i].append(info['power_delivered'][i])
                if departures[i] is None and info["time_left"][i] <= 1e-8:
                    departures[i] = t
            for i in range(env.number_evs):
                soc_traces[i].append(env.soc_current[i])

            target_used = float(np.clip(env.station_capacity, info['fe_used'], info['fi_used']))

            # 7) Print row
            row_data = [
                t,
                np.round(action_vec, 3),
                np.round(info['power_delivered'], 3),
                np.round(net_power_traces[-1], 3),
                np.round(target_used, 3),
                np.round(info['prev_time_left'], 3),
                np.round(info['time_left'], 3),
                info['departed_flag'],
                info['terminated'],
                np.round(env.soc_current, 3),
                np.round(reward, 3),
                np.round(info['terminal_penalty'], 3),
                np.round(info['terminal_reward'], 3),
                np.round(info['step_penalty'], 3),
                np.round(info['step_reward'], 3),
                np.round(info['cycling_penalty'], 3),
                np.round(info['grid_following_penalty'], 3),
                np.round(info['fi_used'], 3),
                np.round(info['fe_used'], 3),
            ]
            print(" | ".join([str(item) for item in row_data]))

        # After 21h, plot results:
        plot_soc_power_reward_departure(
            times, soc_traces, power_traces, net_power_traces, setpoint_traces,
            reward_traces, soc_arrival_plot, soc_required_plot, departures,
            reward_breakdowns, env.max_station_capacity
        )
        print("="*60)
        print("Day finished (21h).")
        print("Final SOCs:        ", np.round(env.soc_current, 3))
        print("Final Power needed:", np.round(env.power_needed, 3))
        print("Arrival times (h):    ", np.round(env.arrival_time, 3))
        print("Departure times (h):  ", np.round(env.depart_time, 3))
        print("Present mask:         ", env.present)

# ---------------------------------------------------------
# Plotting (adds target trace to the Net Power subplot)
# ---------------------------------------------------------
def plot_soc_power_reward_departure(times, soc_traces, power_traces, net_power_traces, setpoint_traces,
                                    reward_traces, soc_arrival, soc_required, departures,
                                    reward_breakdowns, max_station_capacity):
    n_evs = len(soc_traces)
    fig, axs = plt.subplots(n_evs, 3, figsize=(21, 4 * n_evs))
    if n_evs == 1:
        axs = axs.reshape(1, -1)

    # Per-EV SOC and Power
    for i in range(n_evs):
        # SOC Progression
        axs[i,0].plot(times, soc_traces[i], label=f'EV {i+1} SOC')
        axs[i,0].axhline(y=soc_arrival[i], color='gray', linestyle='--', label="Arrival SOC")
        axs[i,0].axhline(y=soc_required[i], color='orange', linestyle='--', label="Requested SOC")
        if departures[i] is not None:
            axs[i,0].axvline(x=departures[i], color='red', linestyle=':', label="Departure Time")
        axs[i,0].set_ylabel('SOC')
        axs[i,0].set_title(f'EV {i+1} SOC Progression (21h)')
        axs[i,0].set_ylim(0, 1.05)
        #axs[i,0].set_xlim(0,24)
        axs[i,0].grid()
        axs[i,0].legend(loc="lower right")

        # Power Delivered per Step (kWh)
        axs[i,1].plot(times[1:], power_traces[i], color='green', label=f'EV {i+1} Power (kWh/step)')
        if departures[i] is not None:
            axs[i,1].axvline(x=departures[i], color='red', linestyle=':', label="Departure Time")
        axs[i,1].set_ylabel('kWh / step')
        axs[i,1].set_title(f'EV {i+1} Energy per Step')
        axs[i,1].grid()
        #axs[i,1].set_xlim(0,24)
        axs[i,1].legend()

    # Site Net Power vs. Target (kW)
    axs[0, 2].plot(times[1:], net_power_traces, label='Net Power (kW)')
    axs[0, 2].plot(times[1:], setpoint_traces, linestyle='--', label='Target (kW)')
    axs[0, 2].set_ylabel('kW')
    axs[0, 2].set_title('Site Net Power vs. Target (21h)')
    axs[0, 2].set_ylim(-max_station_capacity, max_station_capacity * 1.1)
    axs[0, 2].grid()
    axs[0, 2].legend()

    if n_evs > 1:
        fig.delaxes(axs[1, 2])  # remove extra axes if present

    # Total reward per step + breakdown
    plt.figure(figsize=(10, 5))
    plt.plot(times[1:], reward_traces, color='b', label='Total Reward')
    for k, trace in reward_breakdowns.items():
        plt.plot(times[1:], trace, linestyle='--', marker='.', label=k)
    plt.xlabel("Step")
    plt.ylabel("Reward")
    plt.title("Per-step Reward (Total & Components)")
    plt.legend(loc='best')
    plt.grid()
    plt.tight_layout()
    plt.show()

    plt.tight_layout()
    plt.show()

# -----------------------------------------
# Example calls
# -----------------------------------------
# 1) Full 21h with random reset, JIT baseline
# test_policy_21h_with_logging(env, maddpg, baseline_mode="JIT", n_days=1)

# 2) Full 21h with custom params, ASAP baseline, and a 15-min +300 kW activation at the start
custom_initial_params = {
    'time_now': 0.0,
     'arrival_time': [0.0, 0.0],
     'depart_time':  [2.0, 2.0],
     'soc_arrival':  [0.2, 0.2],
     'soc_required': [0.8, 0.8],
     'battery_capacity': [100, 100],
     'v2g_capable': [True, True],
     'activate_at':3,          # step index where activation begins
     'A': -300,                # kW delta during activation window
     'activation_steps': 3,     # 15 min if dt = 5 min
 }
test_policy_21h_with_logging(env, maddpg, baseline_mode="ASAP", n_days=1, custom_params=custom_initial_params)

# Or without custom params (random reset):
#test_policy_21h_with_logging(env, maddpg, baseline_mode="ASAP", n_days=1)```

## `src/data_fetch/dmi_weather_climatology.py`

```python
# STATUS: DRAFT. DMI fetch (daily mean wind + temperature, nearest station). Pasted by Bob 12 Oct 2026.
# KNOWN ISSUE vs decisions (6 Oct close-out section 4): this averages each calendar day ACROSS YEARS, which was decided
# against ("Do not average by calendar day across years - removes extremes; crosswind is non-linear").
# Decided split: fetch_dmi(...) (download once, save raw) + build_weather(...) (pure). Also check wind measurement height vs h_ref.

import requests
import pandas as pd
import math

BASE = "https://opendataapi.dmi.dk/v2/climateData/collections"
DENMARK_BBOX = "7,54,16,58"  # min_lon, min_lat, max_lon, max_lat

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))

def fetch_json(url, params):
    r = requests.get(url, params=params, timeout=90)
    if not r.ok:
        print(f"FAILED URL: {r.url}\nSTATUS: {r.status_code}")
    r.raise_for_status()
    return r.json()

def get_climate_stations():
    data = fetch_json(f"{BASE}/station/items",
                      {"status": "Active", "bbox": DENMARK_BBOX, "limit": 300000})
    rows = []
    for f in data.get("features", []):
        props = f["properties"]
        lon, lat = f["geometry"]["coordinates"]
        rows.append({"station_id": props["stationId"],
                     "station_name": props.get("name"),
                     "lat": lat, "lon": lon})
    return pd.DataFrame(rows)

def get_daily_param(station_id, parameter_id, start_iso, end_iso):
    """Daily values of one parameter for one station, indexed by local date."""
    data = fetch_json(f"{BASE}/stationValue/items", {
        "stationId": station_id,
        "parameterId": parameter_id,
        "timeResolution": "day",
        "datetime": f"{start_iso}/{end_iso}",
        "limit": 300000,
    })
    rows = [{"date": f["properties"]["from"], "value": f["properties"]["value"]}
            for f in data.get("features", [])]
    if not rows:
        return pd.Series(dtype=float)

    df = pd.DataFrame(rows)
    df["date"] = (pd.to_datetime(df["date"], utc=True)
                    .dt.tz_convert("Europe/Copenhagen")
                    .dt.tz_localize(None).dt.normalize())
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df.dropna().drop_duplicates("date").set_index("date")["value"]


def get_wind_temp_climatology(lat, lon,
                              start_iso="2023-10-01T00:00:00Z",
                              end_iso="2024-10-01T00:00:00Z",
                              min_days=364,
                              keep_leap_day=False):
    """
    Finds the nearest station that has BOTH wind and temperature data, then
    averages each calendar day (Jan 1, Jan 2, ...) across all years.

    Returns a DataFrame with 365 rows (366 if keep_leap_day=True):
        month_day | avg_wind_speed_mps | avg_temp_c
    """
    stations = get_climate_stations()
    stations["dist_km"] = stations.apply(
        lambda r: haversine_km(lat, lon, r.lat, r.lon), axis=1)
    stations = stations.sort_values("dist_km").reset_index(drop=True)

    for _, st in stations.iterrows():
        try:
            wind = get_daily_param(st["station_id"], "mean_wind_speed", start_iso, end_iso)
            temp = get_daily_param(st["station_id"], "mean_temp", start_iso, end_iso)
        except Exception as e:
            print(f"Failed: {st['station_name']} ({st['station_id']}) - {e}")
            continue

        if len(wind) < min_days or len(temp) < min_days:
            print(f"Skipped: {st['station_name']} - wind rows {len(wind)}, temp rows {len(temp)}")
            continue

        print(f"Using: {st['station_name']} ({st['station_id']}), {st['dist_km']:.2f} km away")

        df = pd.concat([wind.rename("wind"), temp.rename("temp")], axis=1)
        df["month_day"] = df.index.strftime("%m-%d")
        if not keep_leap_day:
            df = df[df["month_day"] != "02-29"]

        out = (df.groupby("month_day")
                 .agg(avg_wind_speed_mps=("wind", "mean"),
                      avg_temp_c=("temp", "mean"))
                 .reset_index())
        return out

    raise RuntimeError("No station with sufficient wind + temperature data found.")


# Usage
clim = get_wind_temp_climatology(55.6800, 12.4500)
print(clim.head())
print(len(clim))  # 365

# If you want plain numpy arrays:
month_day = clim["month_day"].to_numpy()
wind = clim["avg_wind_speed_mps"].to_numpy()
temp = clim["avg_temp_c"].to_numpy()```

## `src/data_fetch/dmi_wind_plot_old.py`

```python
# STATUS: OLD EXPLORATION SCRIPT (daily mean wind, one station, plot). Pasted by Bob 12 Oct 2026.
# Superseded by dmi_weather_climatology.py for wind+temperature. Kept for the station search pattern.
# Note: comment says "7-day" but rolling window is 30; title says 2024 but range is 2022-2025.
import requests
import pandas as pd
import matplotlib.pyplot as plt
import math

BASE = "https://opendataapi.dmi.dk/v2/climateData/collections"
DENMARK_BBOX = "7,54,16,58"

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))

def fetch_json(url, params):
    r = requests.get(url, params=params, timeout=90)
    if not r.ok:
        print(f"FAILED URL: {r.url}\nSTATUS: {r.status_code}")
    r.raise_for_status()
    return r.json()

def get_climate_stations():
    url = f"{BASE}/station/items"
    params = {"status": "Active", "bbox": DENMARK_BBOX, "limit": 300000}
    data = fetch_json(url, params)
    rows = []
    for f in data.get("features", []):
        props = f["properties"]
        lon, lat = f["geometry"]["coordinates"]
        rows.append({"station_id": props["stationId"], "station_name": props.get("name"), "lat": lat, "lon": lon})
    return pd.DataFrame(rows)

def get_daily_mean_wind_speed(station_id, start_iso, end_iso):
    url = f"{BASE}/stationValue/items"
    params = {
        "stationId": station_id,
        "parameterId": "mean_wind_speed",
        "timeResolution": "day",
        "datetime": f"{start_iso}/{end_iso}",
        "sortorder": "from,DESC",
        "limit": 300000,
    }
    data = fetch_json(url, params)
    rows = []
    for f in data.get("features", []):
        props = f["properties"]
        rows.append({"from": props["from"], "mean_wind_speed_10m_mps": props["value"]})
    df = pd.DataFrame(rows)
    if not df.empty:
        df["from"] = pd.to_datetime(df["from"], utc=True)
        df["mean_wind_speed_10m_mps"] = pd.to_numeric(df["mean_wind_speed_10m_mps"], errors="coerce")
        df = df.dropna().sort_values("from").reset_index(drop=True)
    return df

input_lat, input_lon = 55.6800, 12.4500
start_iso, end_iso = "2022-01-01T00:00:00Z", "2025-01-01T00:00:00Z"

stations = get_climate_stations()
stations["dist_km"] = stations.apply(lambda r: haversine_km(input_lat, input_lon, r.lat, r.lon), axis=1)
stations = stations.sort_values("dist_km").reset_index(drop=True)

df = pd.DataFrame()
chosen_station = None
for _, station in stations.head(10).iterrows():
    try:
        temp = get_daily_mean_wind_speed(station["station_id"], start_iso, end_iso)
        if len(temp) > 300:
            df, chosen_station = temp, station
            break
    except:
        continue

if not df.empty:
    # Calculate weekly smoothed average (7-day rolling mean)
    df["weekly_smooth"] = df["mean_wind_speed_10m_mps"].rolling(window=30, center=True).mean()

    print(f"Using: {chosen_station['station_name']} ({chosen_station['station_id']})")
    plt.figure(figsize=(16, 5))
    plt.plot(df["from"], df["mean_wind_speed_10m_mps"], alpha=0.3, label="Daily Mean", color="steelblue")
    plt.plot(df["from"], df["weekly_smooth"], label="Weekly Smoothed (7d)", color="darkorange", linewidth=2)

    plt.title(f"Wind Speed 2024 - {chosen_station['station_name']} (10m Height)")
    plt.ylabel("Wind Speed [m/s]")
    plt.xlabel("Date")
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.6)
    plt.tight_layout()
    plt.show()
else:
    print("No data found for the nearest stations in 2024.")
```

## `src/deprecated/charging_physics_engine_exponential.py`

```python
# STATUS: DEPRECATED - to be replaced. Pasted by Bob 12 Oct 2026 ("from old code").
# Decision (earlier sessions): replace the exponential CC-CV taper with the VECTO OCV + internal-resistance (Ri) approach,
# and split charger sizing into two functions: sizing mode (P = E/t, division-based minimum power) and
# simulation mode (per-timestep OCV+Ri loop). Not yet coded.
# Every constant below (SOC_THRESHOLD 0.90, K 1.0, ETA 0.95, V2G floor -0.2) is UNSOURCED and hard-coded,
# which breaks the "all parameters as arguments" rule.
import math

def charging_physics_engine(charge_rate_kw, battery_capacity_kwh,
                             current_capacity_kwh, charge_time_min,
                             v2g_flag, soc_floor=0.0):

    SOC_THRESHOLD = 0.90   # NMC CC-CV transition
    K             = 1.0    # exponential decay constant
    ETA           = 0.95   # charger efficiency

    SOC_FLOOR = -0.2 if v2g_flag else 0.0   # V2G allows drawing below normal floor
    SOC_CEIL  = 1.0

    charge_trace = []
    soc_trace    = []

    current_kwh = current_capacity_kwh

    for i in range(charge_time_min):
        soc = current_kwh / battery_capacity_kwh

        if soc >= SOC_CEIL:
            break

        if soc < SOC_THRESHOLD:
            p_delivered = charge_rate_kw * ETA                          # CC phase
        else:
            soc_norm    = (soc - SOC_THRESHOLD) / (1.0 - SOC_THRESHOLD)
            p_delivered = charge_rate_kw * ETA * math.exp(-K * soc_norm)  # CV phase

        kwh_this_min = p_delivered / 60
        current_kwh  = min(current_kwh + kwh_this_min,
                           SOC_CEIL * battery_capacity_kwh)

        charge_trace.append(p_delivered)
        soc_trace.append(current_kwh / battery_capacity_kwh)

    return soc_trace, current_kwh, charge_trace
```

## `src/deprecated/simulate_driver_alt.py`

```python
# STATUS: ALTERNATIVE / OLDER VERSION - do not treat as canonical.
# Memory note (14 April): the DriverModel class is canonical; the older vecto_driver.py port is deprecated.
# This file is a later variant of that port that Bob pasted on 12 Oct 2026. It contains fixes worth comparing during the
# driver-model audit (deceleration-distance guard, standstill start, snap-to-stop near zero speed) and interpolates grade
# between waypoints (VECTO interpolates ALTITUDE, not grade - see engine notes). Bob to confirm what this file is.

"""
Driver Model

Input pasted directly as strings:
  - VDRI_DATA
  - VACC_DATA
"""

import csv
import math
from dataclasses import dataclass
from io import StringIO
from typing import List, Tuple


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class CycleEntry:
    distance_m: float
    speed_kmh: float
    grade_pct: float
    stop_s: float


@dataclass
class AccPoint:
    speed_kmh: float
    acc_ms2: float
    dec_ms2: float


@dataclass
class TraceRow:
    time_s: float
    distance_m: float
    speed_ms: float
    accel_ms2: float
    grade_deg: float


# ---------------------------------------------------------------------------
# Parsers for pasted string data
# ---------------------------------------------------------------------------

def parse_vdri_text(text: str) -> List[CycleEntry]:
    entries = []
    text = text.replace("\ufeff", "")
    reader = csv.reader(StringIO(text.strip()))

    for row in reader:
        row = [c.strip() for c in row]

        if not row or row[0].startswith("<") or row[0].startswith("#"):
            continue

        try:
            s = float(row[0])
            v = float(row[1])
            grad = float(row[2])
            stop = float(row[3])
            entries.append(CycleEntry(s, v, grad, stop))
        except (ValueError, IndexError):
            continue

    if not entries:
        raise ValueError("No valid VDRI entries found in pasted text")

    return entries


def parse_vacc_text(text: str) -> List[AccPoint]:
    points = []
    text = text.replace("\ufeff", "")
    reader = csv.reader(StringIO(text.strip()))

    for row in reader:
        row = [c.strip() for c in row]

        if not row:
            continue

        try:
            v = float(row[0])
            a = float(row[1])
            d = float(row[2])
            points.append(AccPoint(v, a, d))
        except (ValueError, IndexError):
            continue

    if not points:
        raise ValueError("No valid VACC entries found in pasted text")

    return sorted(points, key=lambda p: p.speed_kmh)


# ---------------------------------------------------------------------------
# Acceleration curve
# ---------------------------------------------------------------------------

class AccelerationCurve:
    def __init__(self, points: List[AccPoint]):
        self.points = sorted(points, key=lambda p: p.speed_kmh)

    def lookup(self, speed_ms: float) -> Tuple[float, float]:
        speed_kmh = speed_ms * 3.6
        pts = self.points

        if speed_kmh <= pts[0].speed_kmh:
            return pts[0].acc_ms2, pts[0].dec_ms2

        if speed_kmh >= pts[-1].speed_kmh:
            return pts[-1].acc_ms2, pts[-1].dec_ms2

        for i in range(len(pts) - 1):
            lo = pts[i]
            hi = pts[i + 1]

            if lo.speed_kmh <= speed_kmh <= hi.speed_kmh:
                t = (speed_kmh - lo.speed_kmh) / (hi.speed_kmh - lo.speed_kmh)
                acc = lo.acc_ms2 + t * (hi.acc_ms2 - lo.acc_ms2)
                dec = lo.dec_ms2 + t * (hi.dec_ms2 - lo.dec_ms2)
                return acc, dec

        return pts[-1].acc_ms2, pts[-1].dec_ms2

    def compute_deceleration_distance(self, v0_ms: float, v1_ms: float) -> float:
        if v1_ms >= v0_ms:
            return 0.0

        breakpoints = [v1_ms]

        for pt in self.points:
            v_ms = pt.speed_kmh / 3.6
            if v1_ms < v_ms < v0_ms:
                breakpoints.append(v_ms)

        breakpoints.append(v0_ms)
        breakpoints.sort()

        total_distance = 0.0

        for i in range(len(breakpoints) - 1, 0, -1):
            v_hi = breakpoints[i]
            v_lo = breakpoints[i - 1]
            v_mid = (v_hi + v_lo) / 2.0

            _, dec = self.lookup(v_mid)

            if dec >= 0:
                dec = -0.01

            ds = (v_hi ** 2 - v_lo ** 2) / (2.0 * abs(dec))
            total_distance += ds

        return total_distance


# ---------------------------------------------------------------------------
# Acceleration kernel
# ---------------------------------------------------------------------------

def compute_acceleration(
    v0_ms: float,
    v1_ms: float,
    ds_m: float,
    acc_curve: AccelerationCurve,
) -> float:

    if ds_m <= 0 or (v0_ms + v1_ms) <= 0:
        return 0.0

    dt = 2.0 * ds_m / (v0_ms + v1_ms)

    if dt <= 0:
        return 0.0

    a_required = (v1_ms - v0_ms) / dt

    max_acc, max_dec = acc_curve.lookup(v0_ms)
    a_clamped = max(max_dec, min(max_acc, a_required))

    return a_clamped


# ---------------------------------------------------------------------------
# Grade helpers
# ---------------------------------------------------------------------------

def grade_pct_to_deg(grade_pct: float) -> float:
    return math.degrees(math.atan(grade_pct / 100.0))


def interpolate_grade(entry_lo: CycleEntry, entry_hi: CycleEntry, pos_m: float) -> float:
    if entry_hi.distance_m == entry_lo.distance_m:
        return grade_pct_to_deg(entry_lo.grade_pct)

    t = (pos_m - entry_lo.distance_m) / (entry_hi.distance_m - entry_lo.distance_m)
    grade_pct = entry_lo.grade_pct + t * (entry_hi.grade_pct - entry_lo.grade_pct)

    return grade_pct_to_deg(grade_pct)


# ---------------------------------------------------------------------------
# Main driver simulation
# ---------------------------------------------------------------------------

def simulate_driver(
    cycle: List[CycleEntry],
    acc_curve: AccelerationCurve,
    dt_s: float = 1.0,
) -> List[TraceRow]:

    trace: List[TraceRow] = []

    time_s = 0.0
    pos_m = cycle[0].distance_m
    speed_ms = cycle[0].speed_kmh / 3.6

    # Initial stop
    if cycle[0].stop_s > 0:
        t_elapsed = 0.0

        while t_elapsed < cycle[0].stop_s:
            grade_deg = grade_pct_to_deg(cycle[0].grade_pct)
            trace.append(TraceRow(time_s, pos_m, 0.0, 0.0, grade_deg))

            time_s += dt_s
            t_elapsed += dt_s

        speed_ms = 0.0

    for i in range(len(cycle) - 1):
        left = cycle[i]
        right = cycle[i + 1]

        left_ms = left.speed_kmh / 3.6
        target_ms = right.speed_kmh / 3.6
        seg_end_m = right.distance_m

        while pos_m < seg_end_m:
            remaining_m = seg_end_m - pos_m

            max_acc, max_dec = acc_curve.lookup(speed_ms)

            brake_dist_m = acc_curve.compute_deceleration_distance(speed_ms, target_ms)
            brake_start_m = seg_end_m - brake_dist_m

            # ---------------------------------------------------------------
            # Choose acceleration
            # ---------------------------------------------------------------

            if target_ms < speed_ms and pos_m >= brake_start_m:
                # Braking phase: decelerate to the target speed at the waypoint
                a = compute_acceleration(speed_ms, target_ms, remaining_m, acc_curve)

            else:
                # Cruise / accelerate phase
                #
                # Important:
                # Do NOT drive toward target_ms when target_ms is lower.
                # For example, before a stop, keep driving at the current/left
                # speed until the braking point.
                cruise_ms = max(left_ms, target_ms)

                a = compute_acceleration(speed_ms, cruise_ms, remaining_m, acc_curve)
                a = max(max_dec, min(max_acc, a))

                # Safety for start from standstill
                if speed_ms <= 1e-9 and cruise_ms > 0 and a <= 0:
                    a = max_acc

            grade_deg = interpolate_grade(left, right, pos_m)

            trace.append(TraceRow(time_s, pos_m, speed_ms, a, grade_deg))

            # ---------------------------------------------------------------
            # Kinematic update
            # ---------------------------------------------------------------

            new_speed = speed_ms + a * dt_s
            new_speed = max(0.0, new_speed)

            ds = speed_ms * dt_s + 0.5 * a * dt_s * dt_s
            ds = max(0.0, ds)

            # If this timestep reaches or passes the waypoint, snap exactly there
            if pos_m + ds >= seg_end_m:
                pos_m = seg_end_m
                speed_ms = target_ms
                time_s += dt_s
                break

            # Prevent numerical lo0k-up
            if ds <= 1e-9 and new_speed <= 1e-9:
                if target_ms == 0.0:
                    # This can happen very close to a stop waypoint due to timestep rounding.
                    # Snap to the stop point.
                    pos_m = seg_end_m
                    speed_ms = 0.0
                    time_s += dt_s
                    break

                else:
                    # Start moving toward a positive target speed
                    a = max_acc
                    new_speed = max_acc * dt_s
                    ds = 0.5 * max_acc * dt_s * dt_s

            pos_m += ds
            speed_ms = new_speed
            time_s += dt_s

        # Snap exactly to waypoint
        pos_m = seg_end_m
        speed_ms = target_ms

        # ---------------------------------------------------------------
        # Stop phase
        # ---------------------------------------------------------------

        if right.stop_s > 0:
            speed_ms = 0.0
            t_elapsed = 0.0

            while t_elapsed < right.stop_s:
                grade_deg = grade_pct_to_deg(right.grade_pct)
                trace.append(TraceRow(time_s, pos_m, 0.0, 0.0, grade_deg))

                time_s += dt_s
                t_elapsed += dt_s

    return trace




# ---------------------------------------------------------------------------
# Example usage
# ---------------------------------------------------------------------------

if __name__ == "__main__":

    VDRI_DATA = """
<s>,<v>,<grad>,<stop>
0,0,0.6,45.4
1,34.4,0.6,0
2,34.4,0.6,0
4,34.4,0.7,0
23,34.4,0.8,0
101,29.9,0.8,0
154,22,0.8,0
155,33.6,0.8,0
162,33.6,0.9,0



"""

    VACC_DATA = """
v [km/h],acc [m/s²],dec [m/s²]
0,1,-1
25,1,-1
50,0.642857143,-1
60,0.5,-0.5
120,0.5,-0.5
"""

    cycle = parse_vdri_text(VDRI_DATA)
    acc_pts = parse_vacc_text(VACC_DATA)
    acc_curve = AccelerationCurve(acc_pts)

    trace = simulate_driver(cycle, acc_curve, dt_s=1.0)



    for row in trace[::10]:
        print(
            f"{row.time_s:8.1f} "
            f"{row.distance_m:10.1f} "
            f"{row.speed_ms * 3.6:10.2f} "
            f"{row.accel_ms2:8.3f} "
            f"{row.grade_deg:10.4f}"
        )

    print(f"\nTotal timesteps : {len(trace)}")
    print(f"Total distance  : {trace[-1].distance_m:.1f} m")
    print(f"Total time      : {trace[-1].time_s:.1f} s")

    # Plot speed vs time
    import matplotlib.pyplot as plt

    time_values = [row.time_s for row in trace]
    speed_values = [row.speed_ms * 3.6 for row in trace]

    plt.plot(time_values, speed_values)
    plt.xlabel("Time [s]")
    plt.ylabel("Speed [km/h]")
    plt.title("Speed vs Time")
    plt.grid(True)
    plt.show()
```

## `src/engine/crosswind_engine.py`

```python
# STATUS: DONE and verified (step F). Pasted by Bob 12 Oct 2026.
# Verified: max 0.006% difference vs VECTO Cdv_Generator Excel (docs/decisions/crosswind-verification-2026-10-06.md).
# Output: W1, W2 tables (rows = wind speeds v_ref, columns = vehicle speeds). CdxA_eff = CdxA(0)*W1 + W2 (VECTO AirDrag.cs).
# beta_limit_deg = 10 is an HDEV decision (NOT VECTO). None = VECTO behaviour. Must be stated in every client report.
import numpy as np

###PRE-COMPUTE
##1 Crosswind fucntion(also temperature?)
# pure physics calculates only W1, W2, CdxAeff comes in when we get historical data or something
# outputs W1, W2 lookup table for a given height based on vehicle speeds and wind speeds

def crosswind_engine(vehicle_height, v_ref, h_ref, a1, a2,a3, wind_exp, dh, dphi_deg, v_veh_kmh, beta_limit_deg):

  #check if wind speeds and vehicle speeds are a list or not
  v_ref = np.atleast_1d(np.asarray(v_ref, dtype=float))
  v_veh_kmh = np.atleast_1d(np.asarray(v_veh_kmh, dtype=float))
  v_veh = v_veh_kmh / 3.6 # convert from km/h to m/s

  n_slices = round(vehicle_height / dh) # number of equal heights based on dh
  slice_heights = (np.arange(n_slices) + 0.5) * dh # slide heights but the midpoint of each slice, avoids 0 wind at 0m issue.
  phi = np.radians(np.arange(0, 360, dphi_deg)) # converts 0 to 360 deg to radians

  #the None in brackets only maintain the shape i.e. give each list a dimension to run along so there is not collisions, easy for numpy this way
  v_wind = v_ref[:, None, None, None] * (slice_heights[None, None, None, :] / h_ref) ** wind_exp #Calculates the wind speed at each height slice, wind_exp is how wind grows with height
  v_air_x = v_veh[None, :, None, None] + v_wind * np.cos(phi)[None, None, :, None] # wind hitting the vehicle on the x axis
  v_air_y = v_wind * np.sin(phi)[None, None, :, None] # wind component hitting the vehicle on the y axis
  v_air_sq = v_air_x**2 + v_air_y**2 #total air speed squared

  beta_deg = np.abs(np.degrees(np.arctan2(v_air_y, v_air_x))) #yaw angle the angle between vehicle direction and wind direction, abs since vehicle is symmetric
  if beta_limit_deg is not None: # sets the 10deg clamp so it stays VECTO auditable,above 10 it breaks the curve following
      beta_deg = np.minimum(beta_deg, beta_limit_deg)
  delta_CdxA = a1 * beta_deg + a2 * beta_deg**2 + a3 * beta_deg**3 # extra drag m2 caused by that yaw angle

  W1 = v_air_sq.mean(axis=(2, 3)) / v_veh**2 #how much more air is hitting than with no wind
  W2 = (delta_CdxA * v_air_sq).mean(axis=(2, 3)) / v_veh**2 #how much extra drag the yawed airflow adds in m2
  return W1, W2
```

## `src/engine/driver_model.py`

```python
# STATUS: CURRENT (canonical driver model, post-14 April rewrite). Pasted by Bob 12 Oct 2026.
# PIPELINE STEP: G (driver model). Under audit: 6 known bugs + extra items, see docs/decisions/session-closeout-2026-10-08-payload-force.md section 6.
# NOTE: rows are list of dicts (time, distance, speed, accel, grade, dt_s). Payload column not yet added (decided 8 Oct).
# NOTE: needs `import`s and a Waypoint/vacc structure from the notebook; not standalone.

#driver model -> taked vdri waypoints and vacc files and outputs speed trace events with coasting, cruising and breaking

class DriverModel:
    def __init__(self, waypoints):
        self.waypoints = waypoints

    def get_breaking_distance(self, v0,v1, vacc): # takes in waypoint speed and next waypoint speed calcs breaking distance
      breakpoints = [v1]
      for pt in vacc:
          v_ms = pt.speed / 3.6
          if v1 < v_ms < v0:
              breakpoints.append(v_ms)
      breakpoints.append(v0)
      breakpoints.sort()

      breaking_ds = 0.0
      for i in range(len(breakpoints)-1):
        if v1 <= breakpoints[i] <= v0:
          v_mid = (breakpoints[i] + breakpoints[i+1]) / 2
          dec_at_vmid = self.vacc_lookup(v_mid,vacc)[1]
          breaking_ds += (breakpoints[i+1] ** 2 - breakpoints[i] ** 2) / (2 * abs(dec_at_vmid))
      return breaking_ds


    def vacc_lookup(self,v, vacc): # takes in speed and gives out acc and dec

        v_kmh = v * 3.6
        if v_kmh <= vacc[0].speed:
            return vacc[0].acc, vacc[0].dec
        if v_kmh >= vacc[-1].speed:
            return vacc[-1].acc, vacc[-1].dec
        for i in range(len(vacc) - 1):
            if vacc[i].speed <= v_kmh <= vacc[i+1].speed:
                t = (v_kmh - vacc[i].speed) / (vacc[i+1].speed - vacc[i].speed)
                acc = vacc[i].acc + t * (vacc[i+1].acc - vacc[i].acc)
                dec = vacc[i].dec + t * (vacc[i+1].dec - vacc[i].dec)
                return acc, dec


    def driver_model(self, vacc, dt_s = 1.0):

      rows = []
      time= 0.0
      distance= self.waypoints[0].distance
      speed= self.waypoints[0].speed / 3.6 #kmh to m/s

      if self.waypoints[0].stop > 0.0:# this is exclusively for 1st waypoint
        t_elapsed = 0.0
        while t_elapsed < self.waypoints[0].stop:
          rows.append({
            'time':     time,
            'distance': distance,
            'speed':    0.0,
            'accel':    0.0,
            'grade':    self.waypoints[0].grade_pct,
            'dt_s':     dt_s })
          time      += dt_s
          t_elapsed += dt_s
        speed = 0.0

      for i in range(len(self.waypoints) - 1):
        current= self.waypoints[i]
        target= self.waypoints[i+1]
        target_speed = target.speed / 3.6
        target_distance = target.distance

        while distance < target_distance: #this is if v1 <= v0

          breaking_ds = self.get_breaking_distance(speed, target_speed, vacc) #breaking distance
          breaking_ds_start = target_distance - breaking_ds

          if distance >= breaking_ds_start: #breaking phase
            cruise_speed = target_speed

          else:                               ###crusing / accelerate
            cruise_speed = max(current.speed / 3.6, target_speed)

          max_acc, max_dec = self.vacc_lookup(speed, vacc)

          remaining_distance = target_distance - distance

          if (speed + cruise_speed) > 0 and remaining_distance > 0:
            dt_required = 2 * remaining_distance / (speed + cruise_speed)
            acc_required = (cruise_speed - speed) / dt_required

          else:
            acc_required = 0.0

          acc = max(max_dec, min(max_acc, acc_required))

          new_speed = max (0.0, speed + acc * dt_s)
          ds = speed * dt_s + 0.5 * acc * dt_s **2
          ds = max(0.0, ds)

          if distance + ds >= target_distance:
            rows.append({
            'time':     time,
            'distance': distance,
            'speed':    speed ,
            'accel':    acc,
            'grade':    current.grade_pct,
            'dt_s':     dt_s })

            distance = target_distance
            speed = target_speed
            time += dt_s
            break

          rows.append({
            'time':     time,
            'distance': distance,
            'speed':    speed ,
            'accel':    acc,
            'grade':    current.grade_pct,
            'dt_s':     dt_s })
          distance += ds
          speed = new_speed
          time += dt_s

        if target.stop > 0.0:
          speed = 0.0
          t_elapsed = 0.0

          while t_elapsed < target.stop:

            rows.append({
                'time':     time,
                'distance': distance,
                'speed':    0.0,
                'accel':    0.0,
                'grade':    target.grade_pct,
                'dt_s':     dt_s })
            time      += dt_s
            t_elapsed += dt_s

      return rows
```

## `src/engine/force_engine.py`

```python
# STATUS: DONE and tested (step I). Pasted by Bob 12 Oct 2026.
# Checked against VECTO Vehicle.cs and CrosswindCorrectionCdxALookup.cs (8 Oct close-out section 4).
# Returns mass-, temperature- and CdxA-independent per-row coefficients. The power step (J, not yet written) is:
#   P_wheel = m*k_lin + m**beta * k_roll + k_rot + rho * CdxA_eff * L
# Neutral defaults (beta = 1, theta_red = 0) reproduce the simple equation.
# Tests passed: v=20, a=0, flat, Crr 0.0055 -> (0, 1.0791, 0, 4000, 20); v=10, a=1 -> (10.5, 0.56653, 0, 580.125, 10.5).
import numpy as np

##4 FORCE ENGINE
## takes in rows from the driver model and calculates the force coeff per row independent of mass and temp and CdxA_eff
def force_engine(g, Crr, speed, accel, dt_s, grade, r_dyn, theta_red):

  speed = np.asarray(speed, dtype=float) # speed at start of the step
  accel = np.asarray(accel, dtype=float) # acceleration of the vehicle
  dt_s = np.asarray(dt_s, dtype=float)  # time step, s
  grade = np.asarray(grade, dtype=float) # gradient

  grade = np.arctan(grade / 100) # turns gradient in % into an angle in radians
  v1 = speed
  #v2 = speed + accel * dt_s
  v2 = np.maximum(speed + accel * dt_s, 0.0) # speed cannot go below 0, as in the driver model
  v_avg = (v1 + v2)/2  #speed in m/s

  #K = ((Crr * g * np.cos(grade)) + (g * np.sin(grade)) + accel) * v_avg
  # the K equation is the same with the added term of rotational force, if theta red and rdyn are 0 we get back the simple equation.
  k_lin = (g * np.sin(grade) + accel) * v_avg
  k_roll = Crr * g * np.cos(grade) * v_avg
  k_rot = (theta_red / r_dyn**2) * accel * v_avg if theta_red > 0 else np.zeros_like(v_avg) # no rotating mass unless given
  L = (v1 + v2) * (v1**2 + v2**2) / 8 # exact average of 0.5*v^3 over the step as VECTO CrosswindCorrectionCdxALookup

  return k_lin, k_roll, k_rot, L, v_avg # we are taking out v_avg so we can use it to look up CdxA
```

## `src/engine/p_aux.py`

```python
# STATUS: NOT WRITTEN (stub). Pasted by Bob 12 Oct 2026.
# The VECTO BEV lorry auxiliary logic is fully traced in docs/decisions/session-closeout-2026-10-08-paux.md:
#   P_aux(t) = P_ES + P_HVAC + P_PS + P_SP * [vehicle moving] + P_cond * [electric motor on]
# All five are electric, drawn from the traction battery, DC/DC efficiency = 1.0 in VECTO Declaration Mode.
# Design decisions still pending (Bob): default technologies, blank-cell handling, function structure, non-VECTO extras
# (cabin heating, DC/DC loss, aux during depot charging). Bob wants P_aux vehicle-agnostic (truck, van, bus, car).

##5 Paux
# must take in or read lookup tables and use waypoints to do the math for each of the 5 auxilary consumptions.
```

## `src/engine/payload_engine.py`

```python
# STATUS: DONE and tested (step H). payload_engine pasted by Bob 12 Oct 2026.
# fill_payload is copied from docs/decisions/session-closeout-2026-10-08-payload-force.md (it was not in the 12 Oct paste;
# Bob to confirm it is still the current version in the notebook).
# Design: see docs/design/payload-stop-rows-then-fill.md
import numpy as np

##2 Payload engine
# pure logic, does not care if waypoints came from vdri, typed input or gps
# writes payload only on the start row and on stop rows, everything else stays blank (NaN)
# the blanks get filled forward later so ui can edit stop rows directly

def payload_engine(stop, shape, payload_start, payload_end=None, payload_custom=None): #stop duration column, starting payload

  stop = np.asarray(stop, dtype=float) # stop time of every waypoint/row in s, 0 means no stop; this is just the stop column from vecto or custom inputs

  is_stop = stop > 0 # true where the vehicle stops
  is_stop[0] = False # first row is the depot start, its dwell is not a payload change
  n_stops = int(is_stop.sum()) # number of stops where load can change

  # one payload for the start + one after each stop
  if shape == "constant":
      values = np.full(n_stops + 1, float(payload_start)) # same payload everywhere

  elif shape == "linear":
      if n_stops == 0:
          raise ValueError("linear needs at least one stop")
      values = np.linspace(payload_start, payload_end, n_stops + 1) # equal change at every stop, hdev assumption (unsourced)

  elif shape == "custom":
      values = np.asarray(payload_custom, dtype=float) # user gives start + one value per stop
      if len(values) != n_stops + 1:
          raise ValueError(f"custom needs {n_stops + 1} values, got {len(values)}")
  else:
      raise ValueError(f"unknown shape: {shape}")

  if np.any(values < 0):
      raise ValueError("payload cannot be negative")

  payload = np.full(len(stop), np.nan) # blank payload column, same length as waypoints
  payload[0] = values[0] # start payload always on row 0 so forward fill has something to start from
  payload[is_stop] = values[1:] # payload after each stop written on that stop row
  return payload


##3 Forward fill (runs just before the driver model)  -- from 8 Oct close-out
def fill_payload(payload):
  payload = np.asarray(payload, dtype=float)
  if np.isnan(payload[0]):
      raise ValueError("first row has no payload")
  idx = np.where(~np.isnan(payload), np.arange(len(payload)), 0)
  idx = np.maximum.accumulate(idx)
  return payload[idx]
```

