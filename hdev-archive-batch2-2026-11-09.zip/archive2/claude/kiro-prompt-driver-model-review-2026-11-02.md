# Kiro prompt — driver model deep dive: audit, tests, VECTO comparison, research (2 Nov 2026)

Owner: Bob. Repo: `mohgsaad-art/hdev`. **Today's date is 2 November 2026.** When you research, look for documents up to this date (VECTO releases, regulation amendments, papers from 2025–2026), not only older ones.

This is one job with several parts (A–I). Work through all of them in one run. Open **one PR** with the report and the tests. Do not wait for Bob between parts.

---

## 0. Rules for this job (read first)

1. **Do not edit Bob's engine code.** Do not change `src/engine/driver_model.py` or any engine file. Bob writes all engine code himself. You may copy the code of record (Appendix 1) into `tests/driver_model/reference_copy.py` and make experimental variants there, clearly named (e.g. `driver_model_v_atan`, `driver_model_v_dragtable`). Every proposed change goes into the report as a **before / after snippet with its measured effect**.
2. **No invented numbers.** Every value you use or propose must come from a named source: VECTO source/resource file + line, Regulation (EU) 2017/2400 (incl. amendments), an ISO/SAE/NREL/JRC document, or a peer-reviewed paper — with a link. If there is no source, write `NO SOURCE` and leave it as an open item. Illustrative test values are allowed only inside tests and must be labelled `ILLUSTRATIVE` in the test and the report.
3. **Tag every statement in the report:**
   - `[VECTO]` read in VECTO source — give file, line numbers, branch/tag and commit hash;
   - `[REG]` from Regulation (EU) 2017/2400 or its amendments;
   - `[SOURCE]` external document, with link and date;
   - `[CALC]` your own arithmetic from sourced inputs (show the inputs);
   - `[TEST]` result of a test you ran (name the test);
   - `[ASSUMPTION]` an HDEV choice with no source;
   - `[SIMPLIFICATION]` a deliberate simplification;
   - `[OPEN]` not resolved.
   Never pass an assumption or inference off as fact. If you are not sure you read something correctly, say so.
4. **VECTO version.** Bob's comparison runs (`.vmod`) were made with **VECTO 5.1.6**. Read the VECTO source at the tag/commit that matches 5.1.6 if you can find it. If you can't, use the stable branch (v5.1.3, commit `d16ba783c`, already in `reference/vecto/`) and list every place where line numbers or logic might differ. Earlier HDEV notes cite lines from the `IEPC-experiments` branch of `mohgsaad-art/VECTO` — re-check every cited line against the version you use and report mismatches.
5. **VECTO cannot build in your sandbox.** Anything that needs a new VECTO run is Bob's job. Write the job files / exact run instructions for him instead (Part G).
6. **Engine purity rule (Bob's architecture).** Engine functions are pure maths: every parameter is an argument, nothing hard-coded, no I/O. Checks, lookups, defaults and gap-filling belong in the parser (`defaults.py`), not the engine. Judge every proposed change against this rule.
7. **Bob's validation rule.** Matching VECTO exactly is **not** validation. VECTO is the audit reference. Validation means comparison with several independent sources (tests, studies, measured data), showing how far HDEV and each source differ from one another. A change that only swaps one assumption for another, without a standard or validation behind it, is not worth making — say so when that is the case.
8. Plain English in the report. Short sentences. Define any technical term the first time you use it. Refer to the owner only as "Bob".
9. If an input listed in Part 0.1 is missing, do not guess it. Do everything that doesn't need it, mark the rest `BLOCKED: <file>` and list it in the final summary.

### 0.1 Inputs (Bob adds these to the repo before the run)

| File | Expected path | Used in |
|---|---|---|
| Code of record (Appendix 1 of this prompt) | this prompt | all parts |
| `BEV_E2_RegionalDelivery_ReferenceLoad_1Hz.vmod` | `reference/vecto/runs/` | D, E |
| `BEV_E2_UrbanDelivery_ReferenceLoad_1Hz.vmod` | `reference/vecto/runs/` | D, E |
| The matching `.vsum` | `reference/vecto/runs/` | D |
| HDEV test harness v1.7 (`hdev_test_harness_v1.7.py`) | `tests/harness/` | parser-side setup for the generic E2 truck (masses, Crr, CdxA table, `.vacc`, cycles) |
| Standard-value drag add-on (`hdev_addon_std_drag_v1.py`) | `tests/harness/` | D3 (EU standard-value coasting-drag table) |
| Generic E2 component files (`BatteryElectricVehicle.vveh`, `.vemo`, `.vemd` = `GenericDrag_125kW_485Nm.vemd`, `Gear_1.vtlm`, `Gear_2.vtlm`, axle `.vtlm`, `Truck.vacc`) | from the VECTO repo, `Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/` | D2 |

---

## 1. What the driver model is and where it sits

HDEV is a Python engine that sizes battery-electric trucks and depots. It is built to be auditable against VECTO (the EU certification simulator for heavy-duty vehicles, Regulation (EU) 2017/2400).

Pipeline: crosswind engine → **driver model** → force engine → consumption engine → charging engine → analytics.

The driver model turns a route (waypoints: distance, target speed, stop time, grade) into a 1-second speed trace: rows of time `T`, distance `S`, speed `V`, acceleration `A`, grade and mode `M` (0 stop, 1 accelerate, 2 cruise, 3 coast, 4 brake). The force engine and consumption engine then work row by row.

### 1.1 Decisions already made by Bob (do not reopen; you may report evidence against them)

- The driver model follows VECTO's `DefaultDriverStrategy` (the strategy VECTO uses for BEVs) for the kinematic parts: `.vacc` acceleration/deceleration limits, exact braking distance on the `.vacc` curve, look-ahead, braking margin 0.1 m, altitude interpolation between waypoints.
- **Look-ahead coasting and overspeed** are included, but computed at **one fixed reference vehicle** (`coast_mass` = VECTO reference mass + reduced wheel mass, reference CdxA table from the crosswind engine at VECTO declaration wind 3 m/s at 4 m, ρ = 1.188, no weather wind). Reason: the driver model must run **once per vehicle**, and every weather/payload scenario is then a per-row multiply-add in the consumption engine. VECTO uses the actually simulated mass. This is `[ASSUMPTION]`, to be quantified (Part E).
- `coast_mass=None` → pure kinematics (no coasting or overspeed roll).
- Fixed 1 s rows. VECTO uses variable steps (~0.5 s) and shortens a step to land exactly on braking starts and stops.
- VECTO driver constants are arguments with VECTO defaults (see Appendix 2).
- **Agreed but not yet in the code (22 Oct):** (a) replace the scalar `P_drag_loss` with a **drivetrain coasting-drag table** (drag force at the wheels vs speed), used in both `coast_acc` and `coast_distance`, built in the parser from the EU standard-value drivetrain maps (gearbox Annex VI App. 8, axle Annex VII App. 3, motor drag curve Annex Xb App. 8, IEPC Annex Xb App. 9) or from uploaded real VECTO component files; (b) "apply `math.atan` to `grad` in `coast_distance`" — **but see Q3: an earlier note said VECTO deliberately does NOT do this. This contradiction must be settled from the source.**

### 1.2 HDEV deviations already flagged (from the 21 Oct close-out)

1. Fixed 1 s rows. First braking step split by fraction; final step snapped onto the stop. Last 1–2 braking steps can reach ~1.78× the `.vacc` deceleration in < 1.5 % of braking rows.
2. Coasting + overspeed at a fixed reference mass / CdxA, no wind.
3. Coasting acceleration uses **instantaneous** air drag; VECTO and the HDEV force engine use the step average `(v1+v2)(v1²+v2²)/8`. Leftover: 0.02–0.29 kWh per cycle of braking hidden in coast rows.
4. Drivetrain drag loss 0 and no motor power cap by default.
5. Back-to-back stops: the truck aims for the next **positive** target speed.
6. Acceleration is capped before slowdowns so braking is still possible (stands in for VECTO `CheckRequestDoesNotExceedNextAction`).
7. Stop arrival: distance snapped to the stop point; the force engine assumes `v_avg × dt` → max 0.18 m per stop (Municipal: +9.4 m over 11.24 km).

---

## 2. History of problems (what is already known)

All numbers below are from earlier HDEV sessions. Treat them as leads to re-check, not as facts.

**2.1 Mode-label bug (fixed 22 Oct, verified).** When the speed cap held speed downhill or during look-ahead coasting, the row stayed mode 3 → the consumption engine gave 0 power → braking energy was not recovered. Fix: `mode = 3 if a >= ca - 1e-9 else 4` in both branches (VECTO switches to Brake, `DefaultDriverStrategy.cs` 1000–1006, 1031–1032, 1046–1052 on the branch used then). Effect: −6 % downhill regen 0.014 → 3.71 kWh. **Check the fix is right and complete.**

**2.2 Coasting and overspeed vs VECTO (open).** Generic E2 truck, VECTO 5.1.6, reference load:

| | VECTO | HDEV, no drag | HDEV + EU standard-value drag |
|---|---|---|---|
| Regional: coasting share of time | 1.3 % | 7.8 % | 4.5 % |
| Urban: coasting share | 1.7 % | 5.2 % | 3.4 % |
| Regional: seconds above 85 km/h | 0 | 177 | 53 |
| Urban: seconds above 85 km/h | 11 | 3 | 13 |
| Regional: speed RMS difference vs VECTO (every 10 m) | – | 1.28 km/h | 0.63 km/h |
| Urban: speed RMS difference | – | 2.00 km/h | 1.27 km/h |
| Regional: braking energy at the wheels | – | −18 % vs VECTO | not re-measured |

Time shares stop / accel / cruise / coast / brake (no drag): Regional VECTO 12.7 / 7.0 / 73.4 / 1.3 / 5.7, HDEV 12.7 / 7.3 / 63.8 / 7.8 / 8.4; Urban VECTO 24.8 / 19.6 / 36.8 / 1.7 / 17.3, HDEV 24.6 / 21.7 / 29.1 / 5.2 / 19.5. **The mapping between VECTO's DriverAction codes and HDEV modes was assumed, not verified.**

Root cause found then: in VECTO's BEV coasting the motor controller returns no torque and `ElectricMotor` applies the **drag curve + inertia** (`BatteryElectricMotorController.cs` 43–46, `ElectricMotor.cs` 289 on the branch used then); gearbox and axle loss maps still act at zero torque. Coasting drag measured from the `.vmod` coast rows: 1.43 kN (40–50 km/h) … 2.05 kN (80–90 km/h). The EU standard-value drag is only 0.63–0.85 kN, so part of the remaining gap is expected — **but this has not been proven**. VECTO's `FirstAccelerateOrCoast` (lines 1097–1110 then): at/above target with overspeed allowed, it tries Coast towards target + 2.5 km/h; if the coast response decelerates and speed ≤ target, it accelerates at target (holds speed with the motor).

**2.3 Other leftovers.**
- Up to 1 km/h over target on 6 rows (Urban, Construction) when a 1 s row crosses waypoints a few metres apart.
- Standing time: VECTO 736 / 3245 s vs HDEV 746 / 3349 s (Regional / Urban). HDEV equals the cycle stop times exactly. Earlier guess (not verified): VECTO's 1 Hz output averages speed in the second the truck stops or starts.
- `g = 9.81` in the code; VECTO uses 9.80665 (`DeclarationData.cs` line 72 then).
- `.vacc` lookup: VECTO extrapolates beyond the table (`AccelerationCurve.cs` 77–90); `interp1` holds the end value. Earlier finding: identical for `Truck.vacc`. **But `decel_distance` skips any part of the speed range that lies outside the table** — check what this does when speed exceeds the last `.vacc` point.
- Earlier tests (21 Oct, ILLUSTRATIVE vehicle: 30 t, flat CdxA 6 m², Crr 0.005): all 10 VECTO declaration cycles reach the end, full standing time at every stop, speed never above target + 2.5 km/h, acceleration never above `.vacc` except 6 downhill rows, speed continuity exact, altitude exact, ~0.1 s per 100 km cycle.

---

## 3. Specific questions to answer from the VECTO source (Part A)

Answer each with `[VECTO]` file + lines + version, and a verdict: **MATCH**, **DEVIATION (already flagged)**, **DEVIATION (new — flag it)** or **BUG**.

- **Q1 `ComputeCoastingDistance`:** copy the exact VECTO formula. Does HDEV's `coast_distance` match term by term: energy (which mass — total mass + `ReducedMassWheels` only, or also motor/gearbox rotating inertia?), air drag (exact average form, which speed CdxA is read at), rolling (which mass, cos of what), drivetrain loss term (what VECTO uses exactly, at which speed, how it is computed for a BEV), decision factor?
- **Q2 Decision factor tables:** read `LAC-DF-Vtarget.csv` and `LAC-DF-Vdrop.csv` (and how VECTO interpolates/uses them, incl. units). The code defaults are `df_vtarget=((0,48,52,100),(0,0,1,1))` and `df_vdrop=((-100,9,11,100),(1,1,0,0))`. Are these exactly the VECTO files? Also check `df_offset=2.5`, `df_scaling=1.5`.
- **Q3 Slope in rolling resistance:** does VECTO apply `cos()` to rise/run directly, or to an angle (`atan`)? Two earlier HDEV notes contradict each other. Quote the line. Also report the numeric difference at 2 %, 6 %, 10 % grade.
- **Q4 Look-ahead:** distance formula (lines ~647–683), which change points are considered, target incl. overspeed (line ~662), how the next action is chosen when several slowdowns are in range (earliest brake start vs earliest coast start), and `CheckSwitchingToBraking`. Does HDEV's `best_b` / `best_c` / `coast_ok` logic reproduce it?
- **Q5 Coasting phase:** `DoCoast` speed cap (`max(target, v)`), what happens when coasting decelerates harder than `.vacc` deceleration (Underload → Brake?), when coasting would go below 5 km/h (`MinVelocityForCoast`), and when VECTO ends coasting and starts braking.
- **Q6 Overspeed / `FirstAccelerateOrCoast`:** all branches, incl. what VECTO does when speed is above target and coasting decelerates (HDEV "roll back down", mode 3) and when coasting accelerates beyond target + 2.5 km/h (HDEV holds with brakes, mode 4).
- **Q7 Braking phase:** `DoBrake`, `AdaptDecelerationToTargetDistance`, braking safety margin, `TargetSpeedReachedDriveAlong`. Is HDEV's last-steps formula `(v_t² − v²)/(2·rem)` what VECTO does?
- **Q8 Coasting acceleration in VECTO's powertrain:** in a BEV coast step, which forces act — air (step average), rolling, slope, wheel inertia, motor drag curve, motor rotor inertia reflected through the gears, gearbox and axle losses at zero torque. Which of these does HDEV's `coast_acc` include, and which are missing?
- **Q9 Acceleration limits:** besides `.vacc`, when does VECTO limit acceleration by motor full-load torque/power for a BEV? Does the E2 `.vmod` show rows where acceleration is below `.vacc` because the motor is at its limit? (Relevant to HDEV's optional `P_max`.)
- **Q10 Cycle handling:** altitude from grade (`DrivingCycleDataReader.cs` ~236), first-waypoint 1 s stop rule (~221), target after a stop (~246–253), start speed (`DistanceBasedDrivingCycle.cs` ~107), step slope from altitude (~417–420). Confirm or correct each.
- **Q11 Stop handling:** how VECTO lands on a stop and how its 1 Hz `.vmod` output represents the stop and start seconds. Explain the ~1 s per stop standing-time difference (2.3) from the source, not by guessing.
- **Q12 DriverAction codes:** find the enum in the source that the `.vmod` "DriverAction" column uses. Give the exact mapping to HDEV modes 0–4 and any VECTO actions with no HDEV equivalent (e.g. Roll vs Coast, halt, brake-to-standstill).
- **Q13 Constants:** `g`, air density, `MinVelocityForCoast`, `BrakingSafetyMargin`, `LookAheadDistanceFactor`, `MinimumSpeed`, overspeed `MinSpeed`/`AllowedOverSpeed`, and whether declaration mode turns look-ahead coasting and overspeed on for this vehicle group.

---

## 4. The parts

### Part A — Line-by-line audit
Go through Appendix 1 line by line. For each logic block, give: what it does in plain words; the VECTO lines it stands in for; verdict (see Section 3). Answer Q1–Q13. List every hard-coded number that is not an argument (engine purity rule) — e.g. `1e-6`, `1e-9`, `0.5` in `max_steps`, `10000`, `1.2`, `2 * v * dt`, `3.6` — and say whether each is a VECTO constant (source), a numerical tolerance, or an HDEV choice.

### Part B — Unit tests for the helpers (`tests/driver_model/test_helpers.py`)
- `interp1`: equals `np.interp` on random points, both ends held, repeated x values, single-segment table.
- `decel_distance`:
  - against a fine numerical integration of `v / a(v)` over the `.vacc` deceleration curve (`Truck.vacc` and two synthetic curves);
  - against VECTO's own formula (`AccelerationCurve.ComputeAccelerationSegmentDistance`) re-implemented independently from the C#;
  - edge cases: `v_to ≥ v_from`; constant deceleration segment; a segment where deceleration is 0 or changes sign (division by zero / log of a negative?); `v_from` above the last table point and below the first; equal adjacent `vacc_v` values.
  - report any case that crashes, returns NaN/negative, or differs from VECTO's extrapolation behaviour.
- `coast_distance`:
  - against a hand calculation of VECTO's formula (Q1) for 6 cases (flat / uphill / downhill × small / large speed drop);
  - sign behaviour: uphill and negative `dE` → negative result (driver_model ignores it — confirm that is VECTO behaviour);
  - `cos(grad)` vs `cos(atan(grad))` difference;
  - `P_drag_loss / v` behaviour as `v` → small (it is only called above 50 km/h — confirm no other call path).

### Part C — Behaviour tests on all VECTO declaration cycles (`tests/driver_model/test_cycles.py`)
Use the generic E2 truck set-up from harness v1.7 (masses, Crr with β, reference CdxA table, `Truck.vacc`). Run every declaration cycle in the VECTO repo (incl. LongHaul, RegionalDelivery, UrbanDelivery, MunicipalUtility, Construction, HeavyUrban, Urban, Suburban, Interurban, Coach — whichever exist) with `coast_mass=None` and with coasting on. Check and report per cycle:
- reaches the end; no `RuntimeError`; runtime;
- standing time at every stop = cycle stop time;
- speed never above target + 2.5 km/h (above 50 km/h) or above target (below 50 km/h) — list every violation with distance, waypoint spacing and cause;
- acceleration never above `.vacc` and deceleration never beyond `.vacc` — list violations (count, max ratio, where, why);
- no row labelled mode 3 where the wheel force (from `force_engine` with the same inputs) needs braking beyond the known instantaneous-vs-average-drag leftover; quantify that leftover in kWh;
- distance continuity, altitude along rows = cycle altitude;
- edge routes: one waypoint; all-zero speeds (must raise a clear error); back-to-back stops; very short waypoint spacing (< 1 m, 1–5 m); steep grades ±10 %; target change of 1 km/h; route starting at speed > 0; `dt = 0.5` and `dt = 2.0`.

### Part D — Comparison with VECTO `.vmod` (the main part)
Metrics for every case, Regional and Urban:
1. speed vs distance every 10 m: mean difference and RMS;
2. time shares by mode using the verified Q12 mapping;
3. coasting: number of coast phases, start distance of each coast phase before its slowdown point, coast distance, speed drop — HDEV vs VECTO, phase by phase;
4. braking start positions before each slowdown/stop;
5. seconds above target and above 85 km/h; max overspeed;
6. standing time per stop and total trip time;
7. wheel energy: positive traction, braking, and coasting rows separately (use `force_engine` from the harness).

Cases — **change one thing at a time** so each effect is isolated:
- **D1** code of record, `P_drag_loss = 0`;
- **D2** with **VECTO's own example drag** as a drag-vs-speed table (from `GenericDrag_125kW_485Nm.vemd` + `Gear_2.vtlm` + axle `.vtlm` at zero torque, gear 2; check the gear VECTO used from the `.vmod`). **Purpose: if HDEV logic is right, D2 should reproduce VECTO's coasting share and overspeed closely. If it doesn't, the remaining difference is logic, not drag.** Say which;
- **D3** with the EU standard-value drag table from `hdev_addon_std_drag_v1.py` (re-check that its formulas match the regulation; flag anything that doesn't);
- **D4** = D2 + `atan` fix (only if Q3 says VECTO uses an angle);
- **D5** = D2 + `g = 9.80665`;
- **D6** = D2 + step-average air drag in `coast_acc` (as VECTO, if Q8 confirms);
- **D7** = D2 + motor/gearbox rotating inertia in the coasting mass (if Q1/Q8 say VECTO includes it);
- **D8** = D2 with every change that Part A found VECTO actually does.

For each case give a table vs VECTO and a short verdict: closer / further / no change, and why. Graphs: speed vs distance for 3 representative stretches per cycle (one downhill overspeed stretch, one look-ahead coast before a speed drop, one stop), VECTO vs D1 vs D2 vs D8.

**Hypotheses for the remaining coasting/overspeed gap to test and rule in or out (not facts):** (h1) drag magnitude only; (h2) wrong DF tables; (h3) mode-mapping mismatch (VECTO Coast vs Roll); (h4) missing VECTO hold-speed branch in `FirstAccelerateOrCoast`; (h5) 1 s step timing of the coast/brake trigger; (h6) missing rotating inertia in coasting; (h7) instantaneous air drag. Rank them by measured effect.

### Part E — Fixed reference mass: how much does it matter?
- Run the driver model at `coast_mass` = empty (curb + body), reference, and full (registered GVW) for the E2 truck on Regional, Urban, LongHaul.
- Then, for each trace, compute wheel energy (traction, braking) and coasting share at the **actual** masses with `force_engine`, i.e. the "wrong-mass trace" error: driver at reference mass, consumption at empty / full mass, vs driver and consumption both at that mass.
- Report the error in % of wheel energy and of braking energy. This decides whether the fixed-mass assumption is acceptable. Do not decide it — show the numbers.
- If Bob adds VECTO LowLoading `.vmod` files (Part G), compare against them too.

### Part F — The 1 s step
- Run D2 and D8 at `dt = 1.0`, `0.5`, `0.25` and show convergence of every Part D metric.
- Quantify the known 1 s artefacts: braking peaks above `.vacc`, overspeed rows at closely spaced waypoints, stop-arrival snapping, braking-start fraction split. For each: size, how often, energy effect.
- Explain the 1 s per stop standing-time difference with Q11.
- Say whether `dt = 1.0` is good enough for energy (within what %), and what it would cost in runtime to go finer.

### Part G — VECTO runs Bob should do (write them, don't run them)
Write ready-to-use VECTO job files (or exact GUI steps) for VECTO 5.1.6, generic E2, with what each run is for:
- LongHaul and Construction, reference load (more coasting/overspeed coverage);
- Regional and Urban at LowLoading (mass effect, Part E);
- one run with look-ahead coasting off and one with overspeed off, if VECTO allows it in engineering mode (isolates each feature);
- the `.vmod` columns Bob must make sure are written (incl. DriverAction, per-component losses).
Put them in `reference/vecto/jobs/driver-model-2026-11/` with a README.

### Part H — Independent research (not VECTO)
Bob's rule: validate against independent sources, not VECTO alone. Search for, read, and summarise (link, date, what was measured, how it compares with HDEV):
1. VECTO validation work comparing simulated and measured speed traces / driver behaviour (JRC, TU Graz, TÜV, ICCT, etc.), incl. anything published 2024–2026; any change to the VECTO driver model in versions after 5.1.6 or in recent amendments to Regulation 2017/2400 (e.g. 2022/1379, 2025/258 — check what actually exists).
2. Measured heavy-truck driver behaviour: coasting share, deceleration rates, braking distances, look-ahead/eco-driving behaviour, overspeed on downhill — e.g. naturalistic driving studies, NREL Fleet DNA, ACEA/OEM data, telematics studies.
3. How other established models handle trace following and coasting (e.g. NREL FASTSim, Autonomie, ADVISOR, PHEM, SUMO), and whether any publish validation of their driver logic.
4. Typical measured coasting drag of electric-truck drivetrains (to check the EU standard-value 0.63–0.85 kN and VECTO example 1.43–2.05 kN against reality). If nothing measured exists, say `NOT FOUND`.
For every source say whether you read the full text or only an abstract/snippet. List documents you could not open with their links in a "Bob to fetch" table.

### Part I — Plain-English explainer
Bob asked for `interp1`, `decel_distance`, `coast_distance` and `driver_model` to be explained to him. Write `docs/explainers/driver-model-explained.md`: what each function does, why it exists, each block in plain words with a small worked example (ILLUSTRATIVE numbers, labelled), and which VECTO lines it stands in for. No jargon without a definition. Explain from scratch — don't assume prior knowledge of the method.

---

## 5. Deliverables

1. `docs/research/driver-model-review-2026-11.md`, structured:
   - **Summary first** (one page): what is right, what is wrong, ranked list of proposed changes with measured effect and source tag, open items.
   - Part A audit table + Q1–Q13 answers.
   - Parts B–F results (tables, then graphs saved under `docs/research/driver-model-review-2026-11/`).
   - Part H research table.
   - **Proposed changes**: for each — before/after code snippet, why (source tag), measured effect (Part D/E/F), whether it belongs in the engine or the parser, and whether it is VECTO, a standard, or an HDEV assumption. Mark changes that only swap one assumption for another.
   - **Deviation register**: the updated list of every HDEV-vs-VECTO deviation (Section 1.2 plus anything new), each with size and how it must be worded in a client report.
   - "Bob to fetch" table and `BLOCKED` list.
2. `tests/driver_model/` — the tests from B and C, runnable with `pytest`, plus `reference_copy.py` and the experimental variants.
3. `reference/vecto/jobs/driver-model-2026-11/` — Part G.
4. `docs/explainers/driver-model-explained.md` — Part I.
5. One PR. The PR description lists: what was done, how to run the tests, every value without a source, every `BLOCKED` item, and the top 5 findings.

## 6. Stop conditions
- Never decide an open design choice for Bob (e.g. accept/reject the fixed-mass assumption, pick a drag source). Show evidence, recommend if you must, and label the recommendation as yours.
- If a test shows the code of record crashes on a realistic route, report it as BUG with a minimal reproducing input, and keep going with the other parts.

---

## Appendix 1 — Code of record (Bob's current code, 2 Nov 2026; imports: `math`, `bisect`, `numpy as np`)

```python
import math, bisect
import numpy as np

# helper: linear interpolation for ONE number, holds end values like np.interp, but much faster inside a loop
def interp1(x, xs, ys):
  if x <= xs[0]:
      return ys[0]
  if x >= xs[-1]:
      return ys[-1]
  i = bisect.bisect_right(xs, x)                                  # first table point above x
  return ys[i-1] + (ys[i] - ys[i-1]) * (x - xs[i-1]) / (xs[i] - xs[i-1])


# helper: braking distance v_from -> v_to on the .vacc deceleration curve, exact per segment
# VECTO AccelerationCurve.ComputeDecelerationDistance / ComputeAccelerationSegmentDistance; speeds and vacc_v in m/s, vacc_dec negative
def decel_distance(v_from, v_to, vacc_v, vacc_dec):
  if v_to >= v_from:
      return 0.0
  dist = 0.0
  for i in range(1, len(vacc_v)):
      v_lo, v_hi = vacc_v[i-1], vacc_v[i]
      a_lo, a_hi = vacc_dec[i-1], vacc_dec[i]
      v1 = min(v_from, v_hi)
      v2 = max(v_to, v_lo)
      if v2 >= v1:
          continue
      if math.isclose(a_lo, a_hi):
          dist += (v1**2 - v2**2) / (2 * -a_lo)
      else:
          k = (a_lo - a_hi) / (v_lo - v_hi)
          d = a_lo - k * v_lo
          t = math.log((v2*k + d) / (v1*k + d)) / k
          m = v1 + d / k
          dist += m / k * math.exp(k * t) - d / k * t - m / k
  return dist


# helper: look-ahead coasting distance, VECTO DefaultDriverStrategy.ComputeCoastingDistance (lines 721-756)
# speeds m/s; cdxa_v in m/s; df tables in km/h like the VECTO csv files
def coast_distance(v, v_target, h_now, h_target, s_now, s_target,
                   coast_mass, m_red_wheels, cdxa_v, cdxa, Crr, rho, g, P_drag_loss,
                   df_offset, df_scaling, df_vtarget, df_vdrop):
  m_eff = coast_mass + m_red_wheels
  dE = m_eff * g * (h_now - h_target) + m_eff * (v**2 - v_target**2) / 2
  v_avg = (v + v_target) / 2
  cda = interp1(v_avg, cdxa_v, cdxa)
  F_air = rho / 8 * cda * (v + v_target) * (v**2 + v_target**2) / v_avg
  grad = (h_target - h_now) / (s_target - s_now)
  F_roll = math.cos(grad) * coast_mass * g * Crr
  F_loss = P_drag_loss / v
  f_vt = interp1(v_target * 3.6, df_vtarget[0], df_vtarget[1])
  f_vd = interp1((v - v_target) * 3.6, df_vdrop[0], df_vdrop[1])
  DF = df_offset - df_scaling * f_vt * f_vd

  return dE / (DF * (F_air + F_roll + F_loss))


##3 Driver model
# driver model: VECTO DefaultDriverStrategy on fixed 1 s rows (HDEV deviation: VECTO uses ~0.5 s variable steps)
# pure kinematics when coast_mass is None; with coast_mass: look-ahead coasting + overspeed at a FIXED reference vehicle (HDEV assumption)
def driver_model(wp_s, wp_v, wp_stop, wp_grade,
                 vacc_v, vacc_acc, vacc_dec, dt=1.0,
                 coast_mass=None, m_red_wheels=0.0, cdxa_v=None, cdxa=None, Crr=None, rho=1.188, g=9.81,
                 P_drag_loss=0.0, P_max=None,
                 lac_min_v=50.0, lac_dist_factor=10.0, df_offset=2.5, df_scaling=1.5,
                 df_vtarget=((0, 48, 52, 100), (0, 0, 1, 1)), df_vdrop=((-100, 9, 11, 100), (1, 1, 0, 0)),
                 os_min_v=50.0, os_allowed=2.5, brake_margin=0.1, v_min_coast=5.0):

  # ---------- A. once, before the loop ----------
  s_wp = [float(x) for x in wp_s]                      # waypoint distance [m]
  v_wp = [float(x) / 3.6 for x in wp_v]                # waypoint target speed [m/s]
  stop_wp = [float(x) for x in wp_stop]                # FINAL standing time [s] (PTO already added by the parser)
  gr_wp = np.asarray(wp_grade, dtype=float)            # waypoint grade [%]
  n = len(s_wp)

  rise = np.diff(np.asarray(s_wp)) * gr_wp[:-1] / 100  # altitude per waypoint, VECTO DrivingCycleDataReader.cs line 236
  alt_wp = np.concatenate(([0.0], np.cumsum(rise)))
  alt_l = alt_wp.tolist()
  gr_l = gr_wp.tolist()

  if v_wp[0] == 0 and stop_wp[0] == 0:                 # VECTO line 221: cycle starting at 0 km/h without stop gets a 1 s stop
      stop_wp[0] = 1.0

  # speed the driver aims for after passing waypoint i; after a stop it is the next waypoint's target (VECTO line 246-253)
  # (HDEV: if several stops follow each other, take the next POSITIVE target, so the truck never gets stuck at 0 km/h)
  seg_v = [0.0] * n
  nxt = 0.0
  for i in range(n - 1, -1, -1):
      seg_v[i] = v_wp[i] if v_wp[i] > 0 else nxt
      if v_wp[i] > 0:
          nxt = v_wp[i]
  # change points: only waypoints whose target differs from the segment before can trigger braking/coasting
  chg = [i for i in range(1, n) if v_wp[i] != seg_v[i-1]]
  chg_s = [s_wp[i] for i in chg]

  vv = [x / 3.6 for x in vacc_v]                       # .vacc speeds in m/s
  va = [float(x) for x in vacc_acc]
  vd = [float(x) for x in vacc_dec]

  coast_on = coast_mass is not None
  if coast_on:
      if cdxa_v is None or cdxa is None or Crr is None:
          raise ValueError("coasting needs cdxa_v, cdxa and Crr")  # guard only; parser gives friendly message
      m_eff = coast_mass + m_red_wheels                # mass incl. rotating wheels
      cv = [x / 3.6 for x in cdxa_v]                   # reference CdxA table speeds in m/s
      cc = [float(x) for x in cdxa]

  lac_min = lac_min_v / 3.6
  os_min = os_min_v / 3.6
  os_add = os_allowed / 3.6
  v_min_c = v_min_coast / 3.6                          # VECTO MinVelocityForCoast 5 km/h (Constants.cs line 301)

  def coast_acc(v, k):                                 # acceleration with no motor torque at speed v on segment k [m/s²]
      th = math.atan(gr_l[k] / 100)
      F = (rho / 2 * interp1(v, cv, cc) * v * v       # air drag, instantaneous (HDEV: VECTO uses the step average)
           + coast_mass * g * Crr * math.cos(th)       # rolling resistance, mass without wheel inertia like VECTO
           + coast_mass * g * math.sin(th)             # slope force
           + (P_drag_loss / v if v > 0 else 0.0))      # motor/gearbox drag while rolling
      return -F / m_eff

  T, S, V, A, M = [], [], [], [], []                   # rows: time, distance, speed, acceleration, mode
  t = 0.0
  s = s_wp[0]
  v = v_wp[0]                                          # VECTO starts at the first waypoint's target speed (DistanceBasedDrivingCycle.cs line 107)
  s_end = s_wp[-1]

  def add_stop(i, t):                                  # standing rows at waypoint i
      for _ in range(int(round(stop_wp[i] / dt))):
          T.append(t); S.append(s_wp[i]); V.append(0.0); A.append(0.0); M.append(0)
          t += dt
      return t

  if v_wp[0] == 0:                                     # depot start stop
      t = add_stop(0, t)
      v = 0.0

  trig = None                                          # active slowdown: [index, trigger distance, target speed, coasting allowed, braking started]
  max_steps = int(sum(stop_wp) / dt + (s_end - s_wp[0]) / 0.5 + 10000)  # guard against endless loops (truck must average > 0.5 m/s)

  # ---------- B. each 1 s step ----------
  for _ in range(max_steps):
      if s >= s_end - 1e-6:
          break
      k = bisect.bisect_right(s_wp, s) - 1             # waypoint segment we are in
      target = seg_v[k]
      v_os = target + os_add if target > os_min else target  # overspeed limit (VECTO IsOverspeedAllowed: > 50 km/h, +2.5 km/h)

      if trig is not None and s >= trig[1] - 1e-6:     # slowdown point passed
          trig = None

      # look ahead (VECTO GetNextDrivingAction, lines 647-683)
      look = max(2 * v * dt, v * 3.6 * lac_dist_factor, 1.2 * decel_distance(v, 0.0, vv, vd) + v * dt)
      j0 = bisect.bisect_right(chg_s, s)
      j1 = bisect.bisect_right(chg_s, s + look)
      best_b = None                                    # candidate with the earliest braking start
      best_c = None                                    # candidate with the earliest coasting start
      for j in range(j0, j1):
          i = chg[j]
          vt = v_wp[i] + os_add if v_wp[i] > os_min else v_wp[i]  # target incl. overspeed (VECTO line 662)
          if vt >= v:
              continue
          b_start = s_wp[i] - (decel_distance(v, vt, vv, vd) + brake_margin)
          c_start = b_start
          if coast_on and v > lac_min:
              cd = coast_distance(v, vt, interp1(s, s_wp, alt_l), alt_l[i], s, s_wp[i],
                                  coast_mass, m_red_wheels, cv, cc, Crr, rho, g, P_drag_loss,
                                  df_offset, df_scaling, df_vtarget, df_vdrop)
              if cd > 0:
                  c_start = s_wp[i] - cd
          if best_b is None or b_start < best_b[1]:
              best_b = (i, b_start, c_start, vt)
          if best_c is None or c_start < best_c[2]:
              best_c = (i, b_start, c_start, vt)
      action = None
      if best_b is not None:                           # VECTO: braking action, unless the earliest coasting one is the same point
          i, b_start, c_start, vt = best_b
          coast_ok = best_c[0] == i and c_start < b_start
          action = (i, s_wp[i], vt, coast_ok, min(b_start, c_start))

      if trig is None and action is not None and s + v * dt >= action[4]:  # start slowing down if the next step would pass the start point (HDEV: VECTO shortens the step to land on it)
          trig = [action[0], action[1], action[2], action[3], False]
      elif trig is not None and action is not None and action[1] != trig[1]:
          b_new = action[1] - (decel_distance(v, action[2], vv, vd) + brake_margin)
          b_cur = trig[1] - (decel_distance(v, trig[2], vv, vd) + brake_margin)
          if b_new < b_cur:                            # a nearer slowdown needs earlier braking (VECTO CheckSwitchingToBraking)
              trig = [action[0], action[1], action[2], False, True]

      # ---------- choose acceleration ----------
      acc_max = interp1(v, vv, va)
      dec_max = interp1(v, vv, vd)
      if trig is not None:
          i_t, s_t, v_t, coast_ok, braking = trig
          b_start = s_t - (decel_distance(v, v_t, vv, vd) + brake_margin)
          if 0 < v <= v_t:                             # next target already reached: drive along at it (VECTO TargetSpeedReachedDriveAlong)
              a = max(dec_max, min(acc_max, (v_t - v) / dt)); mode = 2
          elif coast_on and coast_ok and not braking and s + v * dt < b_start and v >= v_min_c:  # whole step still before braking start
              ca = coast_acc(v, k)                     # look-ahead coasting: acceleration with no motor torque
              a = min(ca, (max(target, v) - v) / dt)   # VECTO DoCoast: never faster than max(target, current speed)
              a = max(a, dec_max)                      # coasting harder than the driver's max deceleration -> limited
              mode = 3 if a >= ca - 1e-9 else 4        # speed cap active -> braking, not coasting (VECTO DefaultDriverStrategy.cs 1000-1006)
          elif not braking and s < b_start:            # braking starts inside this step: brake only for the part of the step after b_start
              frac = (s + v * dt - b_start) / (v * dt) if v > 0 else 1.0
              a = dec_max * min(max(frac, 0.0), 1.0); mode = 4  # HDEV: VECTO shortens the step to start braking exactly at b_start
              trig[4] = True                           # once braking, stay braking until the point (VECTO BrakingPhase.Brake)
          else:
              rem = s_t - s
              if rem < 2 * v * dt and v > v_t:         # last one or two steps: land on v_t at the point (VECTO AdaptDecelerationToTargetDistance)
                  a = (v_t**2 - v**2) / (2 * rem) if rem > 1e-6 else dec_max
              else:
                  a = max(dec_max, (v_t - v) / dt)     # brake along the .vacc deceleration curve, never below the next target (VECTO DoBrake)
              mode = 4
              trig[4] = True
      else:
          if v < target - 1e-9:                        # accelerate
              a = min(acc_max, (target - v) / dt)
              if P_max is not None and coast_on:       # optional motor power cap (HDEV simplification, not VECTO's motor search)
                  F_res = -coast_acc(v, k) * m_eff
                  a = min(a, (P_max / max(v, 1.0) - F_res) / m_eff)
              if action is not None:                   # don't speed up so much that the next slowdown can't be braked for in time
                  room = action[1] - s - v * dt - brake_margin   # distance left after this step (HDEV: stands in for VECTO's CheckRequestDoesNotExceedNextAction)
                  v_cap = math.sqrt(max(action[2]**2 + 2 * -dec_max * max(room, 0.0), 0.0))
                  a = max(min(a, (v_cap - v) / dt), 0.0)
              mode = 1
          elif coast_on and target > os_min:           # at/above target with overspeed allowed: roll (VECTO FirstAccelerateOrCoast)
              ca = coast_acc(v, k)
              if ca >= 0:
                  a = max(dec_max, min(ca, (v_os - v) / dt))   # downhill: let it run up to target + 2.5 km/h, then hold
                  mode = 3 if a >= ca - 1e-9 else 4            # holding the speed needs brakes -> mode 4 (VECTO DefaultDriverStrategy.cs 1031-1032, 1046-1052
              elif v + ca * dt > target:
                  a = ca; mode = 3                     # roll back down towards target
              else:
                  a = (target - v) / dt; mode = 2      # would drop below target -> hold target
          elif v > target + 1e-9:
              a = max(dec_max, (target - v) / dt); mode = 4  # above target without overspeed -> brake to target
          else:
              a = 0.0; mode = 2                        # cruise

      # ---------- move one step ----------
      v_new = v + a * dt
      if v_new < 0:                                    # would stop inside the step
          ds = v * v / (2 * -a) if a < 0 else 0.0
          v_new = 0.0
      else:
          ds = (v + v_new) / 2 * dt
      if trig is not None and trig[2] == 0 and (v_new <= 0 or s + ds >= trig[1]):
          ds = max(trig[1] - s, 0.0)                   # arrive exactly at the stop (HDEV: VECTO shortens the step instead)
          v_new = 0.0
      T.append(t); S.append(s); V.append(v); A.append((v_new - v) / dt); M.append(mode)
      t += dt
      s += ds
      v = v_new

      if trig is not None and trig[2] == 0 and v == 0:  # arrived at a stop
          s = trig[1]
          t = add_stop(trig[0], t)
          trig = None
  else:
      raise RuntimeError("driver_model did not reach the end of the route")  # guard only

  # ---------- C. after the loop: arrays + grade from altitude ----------
  T = np.asarray(T); S = np.asarray(S); V = np.asarray(V); A = np.asarray(A); M = np.asarray(M, dtype=int)
  s_next = np.append(S[1:], s)                         # distance at the end of each row
  ds_row = s_next - S
  h1 = np.interp(S, s_wp, alt_wp)
  h2 = np.interp(s_next, s_wp, alt_wp)
  k_row = np.searchsorted(s_wp, S, side="right") - 1
  grade = np.where(ds_row > 1e-9, (h2 - h1) / np.where(ds_row > 1e-9, ds_row, 1.0) * 100, gr_wp[k_row])  # [%]; standing rows use the waypoint grade
  return T, S, V, A, grade, M
```

Compare this with `src/engine/driver_model.py` in the repo (may be an older version from before the 21 Oct rewrite) and list the differences. **Appendix 1 is the code of record.**

## Appendix 2 — VECTO driver constants as arguments (to verify in Q2/Q13)

| Argument | Meaning | VECTO source as noted earlier (re-check) |
|---|---|---|
| `lac_min_v=50` | look-ahead coasting only above 50 km/h | `DeclarationData.Driver.LookAhead.MinimumSpeed` |
| `lac_dist_factor=10` | look-ahead distance = 10 × speed in km/h, in m | `LookAheadDistanceFactor` |
| `df_offset=2.5`, `df_scaling=1.5` | decision factor 2.5 − 1.5·f(v_target)·f(v_drop) | `DecisionFactorCoastingOffset/Scaling` |
| `df_vtarget` | factor by target speed | `LAC-DF-Vtarget.csv` |
| `df_vdrop` | factor by speed drop | `LAC-DF-Vdrop.csv` |
| `os_min_v=50`, `os_allowed=2.5` | overspeed +2.5 km/h above 50 km/h | `DeclarationData.Driver.OverSpeed` (`DeclarationData.cs` ~731–733), enabled in `DriverDataAdapter.cs` ~48–53 |
| `brake_margin=0.1` | start braking 0.1 m early | `BrakingSafetyMargin` (`DefaultDriverStrategy.cs` ~62) |
| `v_min_coast=5` | no coasting below 5 km/h | `Constants.MinVelocityForCoast` (`Constants.cs` ~301) |
| `rho=1.188` | air density | `DeclarationData.cs` ~74 |
| `g=9.81` | gravity in the code | VECTO 9.80665 (`DeclarationData.cs` ~72) — mismatch, see 2.3 |

## Appendix 3 — Generic E2 test vehicle (from earlier sessions, re-check in the VECTO files)

`Generic Vehicles/Declaration Mode/PEV/GenericVehicleE2/BatteryElectricVehicle.vveh`: group 2, curb 4670 kg + body B2 1900 kg, reference payload 3019.6 kg (`Payloads.cs`), CdA 4.83 m², 2 × 125 kW motors, gear 2 used for > 99 % of driving in the `.vmod`. Crr with β = 0.9 (`VehicleData.cs` ~292–311, exponent `Physics.cs` ~51). Reference CdxA table: crosswind engine at 3 m/s, 4 m, Hellmann 0.2, 60–130 km/h, no yaw clamp (`Physics.cs` ~56–66, `AirdragDataAdapter.cs` ~59–87, `Constants.cs` ~355–357).
