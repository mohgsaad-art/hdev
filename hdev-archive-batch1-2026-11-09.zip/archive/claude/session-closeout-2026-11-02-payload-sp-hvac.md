# HDEV session close-out: function review — payload, steering pump, HVAC thermal (1–2 Nov 2026)

Read this first in a new chat. Related files:
- `claude/session-closeout-2026-11-01-function-status.md` (running status table + detailed notes from this chat)
- `claude/session-closeout-2026-10-31-pto.md` (PTO design, final `pto_engine`)
- `claude/session-closeout-2026-10-22-function-review-crosswind-payload-pto.md`
- `claude/session-closeout-2026-10-19-paux-hvac.md` (original HVAC / VECTO tables, HD cases, COP table)
- `claude/session-closeout-2026-10-22-validation-drivetrain-winter.md` (validation sources, winter test)
- `claude/files-to-fetch-2026-11-02.md` (list of papers/documents Bob still needs to fetch)

Tags: **[VECTO]** read in Bob's repo `mohgsaad-art/VECTO`; **[SOURCE]** external, read by Claude; **[CALC]** Claude's arithmetic from sourced inputs; **[ASSUMPTION]** HDEV choice, flag in reports; **[DECIDED]** Bob agreed; **[OPEN]**.

Working rule restated by Bob: the engine stays dumb and pure; checks, lookups, defaults and gap-filling go in the parser. Kiro is used for research/tests only when genuinely useful (tell Kiro the current date so it looks at new documents).

---

## 1. Function status after this chat

| Function | Status |
|---|---|
| `crosswind_engine` | Final (unchanged) |
| `pto_engine` | Final (returns `is_on, pto_start, stop_1s, drive_1s`) |
| `P_aux` | Final (VECTO factors multiplied; only always-on PTO divided by `PTO_eff`) |
| `payload_engine` | **Final, unchanged** [DECIDED]: all guards go to the parser |
| `SP_power_helper` | **Final** — matches VECTO exactly |
| `ssm_total_w`, `climate_lookup`, `HVAC_thermal` | **Final once Bob makes one edit** (section 4.4) |
| Next in review | `force_engine` or `driver_model` (driver model merged with drivetrain standard-value work) |
| Still open | consumption engine, parser (`defaults.py`), battery engine |

Bob still to confirm the earlier `pto_engine` return fix and `P_aux` multiply fix are in his notebook.

---

## 2. Payload (`payload_engine`) — final, no engine change

Code of record (Bob's, unchanged):
```python
def payload_engine(stop, shape, payload_start, payload_end=None, payload_custom=None):
  stop = np.asarray(stop, dtype=float)
  is_stop = stop > 0
  is_stop[0] = False
  n_stops = int(is_stop.sum())
  if shape == "constant":
      values = np.full(n_stops + 1, float(payload_start))
  elif shape == "linear":
      if n_stops == 0:
          raise ValueError("linear needs at least one stop")
      values = np.linspace(payload_start, payload_end, n_stops + 1) # hdev assumption (unsourced)
  elif shape == "custom":
      values = np.asarray(payload_custom, dtype=float)
      if len(values) != n_stops + 1:
          raise ValueError(f"custom needs {n_stops + 1} values, got {len(values)}")
  else:
      raise ValueError(f"unknown shape: {shape}")
  if np.any(values < 0):
      raise ValueError("payload cannot be negative")
  payload = np.full(len(stop), np.nan)
  payload[0] = values[0]
  payload[is_stop] = values[1:]
  return payload
```

Parser jobs [DECIDED, Bob: "keeps the engine dumb and pure"]:
- `linear` without `payload_end` → clear error; NaN check on custom values.
- Stops the user switches off for payload change: parser passes a cleaned `stop` copy (traffic stops in VECTO cycles: UrbanDelivery has 104 stops, median 15 s).
- Cap: 0 ≤ payload ≤ GVW − curb − body/trailer, using the **registered GVW** (VECTO `TruckSegments.cs` 233–234, 276–277). Tonnes → kg.
- Legal weight limits only as a later **warning**, after Bob confirms the current Danish order.
- Later (battery step): bigger battery → higher curb mass → lower max payload.

Standards found:
- VECTO reference payloads (ACEA White Book; ~75 % long haul, 50 % others; fixed per group ≥ 4, GVW functions for groups 1–3) — SR7 Lot 4 §4.3.5.4.
- Weights law (Kiro research + Claude check): revision 2023/0265(COD) **not adopted** (awaiting Council 1st reading); Directive 96/53/EC applies. ZEV allowance likely max **2 t** = the actual extra ZEV-technology weight (Reg. 2019/1242 Art. 20; Irish SI 47/2025; DK BEK 1663/2023 §22(2)(3),(7)); Kiro read 1 t (alt-fuel only) — EUR-Lex Art. 10b not yet read. DK BEK 1663/2023 is **Historic**; successor (reported 20 t / 28 t rigids) and the 60 t modulvogntog order not found → Bob to look up on retsinformation.dk.
- **[OPEN]** default payload for sizing: VECTO reference (7 Oct decision) vs max payload (conservative), or reference + a max-payload run beside it.

---

## 3. Steering pump (`SP_power_helper`) — final

Code of record (Bob's):
```python
# returns mechanical W, goes into P_aux as SP_power gets multiplied by 0.7 for electrical W
def SP_power_helper(SP_baseline, SP_axle_shares, SP_tech_factors):
  SP_baseline = np.asarray(SP_baseline, dtype=float)         # (UF, B, S) in W, SP-Table.csv
  SP_axle_shares = np.asarray(SP_axle_shares, dtype=float)   # one (UF, B, S) row in % per steered axle, SP-Axles.csv
  SP_tech_factors = np.asarray(SP_tech_factors, dtype=float) # one (UF, B, S) row per steered axle, SP-Tech.csv or custom
  if SP_axle_shares.ndim != 2 or SP_axle_shares.shape[1] != 3 or len(SP_axle_shares) == 0:
      raise ValueError("SP_axle_shares needs one (UF, B, S) row per steered axle")
  if SP_tech_factors.shape != SP_axle_shares.shape:
      raise ValueError("need one technology (UF, B, S) per steered axle")
  parts = SP_baseline * SP_axle_shares.sum(axis=0) / 100
  parts = parts * SP_tech_factors.mean(axis=0)
  return float(parts.sum())
```

[VECTO] checked: `SteeringPump.cs` 58–114 (per-axle shares, tech factor averaged over steered axles, result is mechanical W even for electric pumps, line 56); table /100 at line 142; `HeavyLorryAuxiliaryDataAdapter.cs` 188–190 (tech count = steered axles), 220 (electric = mech × alternator 0.7). Mixed mech/el pumps: VECTO returns two numbers; total is the same; BEV only allows PEV techs anyway.

**Standstill** [VECTO, Kiro + Claude verified]: BEV electric steering pump is **off when the vehicle is stopped** — `ElectricAuxiliaries.PowerDemand` drops key "STP" when `VehicleStopped`; `Constants.cs` 59–60: `SteeringPump` and `SteeringPump_el` are both "STP". Looks incidental (shared ID) → report as "follows VECTO's current behaviour". Stopped = |v| ≤ 0.01 m/s (`Vehicle.cs` 262, per Kiro) → consumption engine: SP on when `v > 0.01`. No BEV `.vmod` with a per-aux column exists in the repo (Bob could run one).

Parser jobs: PEV-applicable techs only (SP-Tech PEV column); max 4 steered axles; clear error for empty SP-Table cells (groups 1s–3 no Municipal/Construction; 6–8 empty); custom W bypasses the helper. Optional engine guard: `SP_baseline` has 3 values.

No ISO/EU alternative method found that works from user-available inputs → keep VECTO.

---

## 4. HVAC thermal — final after one edit

### 4.1 VECTO check [VECTO]
`SSMRun.cs` 25–64 (TotalW: wall + people + solar, solar × 0.25 bare constant line 58; low-floor bus run-2 rule not relevant for trucks); `SSMCalculate.cs` 744–773 (heating demand), 215–245 (split + cap), 172–212 (COP / heater eff; VECTO silently gives 0 W where COP missing), 337–374 + 553–570 (cooling: T ≥ 17 °C, both runs > 0, min, capped, ÷ COP), 272–296 + 376–428 (three ventilation cases); `SSMInputs.cs` 85–88 (VentPower = volume × rate × 0.56 Wh/m³). Bob's code matches, with all three VECTO ventilation switches on. run1 ≥ run2 always, so the three modes cover every hour. VECTO bus area = box 2·(L·W + L·H + W·H) (`PrimaryBusAuxiliaryDataAdapter.cs` 378), U by floor type 4.0 / 3.5 / 3.0 W/m²K (`DeclarationData.cs` 553–561) — our U 3.0 placeholder = high-floor bus value.

### 4.2 Sources read this chat [SOURCE]
- **NREL CoolCab fact sheet** (973699): measured UA, US long-haul sleeper cab, parked at night: **65 W/K and 51 W/K**; curtain + shades −16/−21 %, insulated windows −16/−14 %, arctic curtain −26 %.
- **Lustbader 2012 (SAE)**: UA test = 1 kW heater inside closed truck overnight, UA = Q/ΔT → includes natural leaks; infiltration measured separately (SF6); CoolCalc (NREL 52452) applies infiltration separately. → forced fan fresh air is **not** in a measured UA → fresh-air term is no double count.
- Placeholder 20 m² × U 3.0 = 60 W/K lies inside the measured 51–65 W/K. Measured UA is parked → lower bound while driving.
- **Ramesh Babu 2025 (Chalmers/Volvo, simulated)**: heater 4.15–4.45 kW at −10 °C, cab 22 °C, 30–90 km/h, no recirculation; recirculation not standard in electric trucks below 20 °C (fogging); cites ventilation > 70 % of heating load (Zhang et al.); CO₂ source 21.6 g/h/occupant, set 1000 ppm, ambient 420 ppm; aux 1.8 kW at 10 °C → 9 kW at −20 °C (incl. battery heating); consumption +58 % at −20 vs 20 °C; Crr 0.007 (20 °C) → 0.014 (−20 °C).
- **Mercedes eActros 600 winter tour 2025** (OEM press text): 40 t, −18 to 9 °C, 64–77 km/h. Representative section −2 °C, cold start, class B tyres vs summer class A: **≈ +25 %** = rolling + air resistance ≈ 15 pts, less recuperation ≈ 4, **cab climate at 21 °C ≈ 5**, battery heating < 1, other aux < 1. Snow/ice with class D Nordic tyres: almost +50 %. Hoteling (21 °C day / 19 °C night at −7 to 4 °C): range −2 to −5 %.
- **Öko-Institut ELV-LIVE** (measured eActros fleet, −7 to 36 °C): −0.13 kWh/km per +10 °C at 0.96 kWh/km mean; cooling unit +0.092 kWh/km.
- JRC Gil-Sayas 2022: **passenger cars**, heating at −7 °C 4–10× cooling at 35 °C (pattern only).
- Dollinger & Fischerauer 2021: winter −7 to −9 % range (model). Shiledar et al. 2026 (OSU/ORNL/Stanford) drayage seasonal model: read only abstract.
- Kiro research (PR #20 in `hdev`, `docs/research/hvac-thermal-parameters-2026-11.md`): Reg. (EU) 2025/258 adds **no lorry thermal HVAC** (SSM stays bus-only → HDEV extension, flag); VECTO VentilationRate has no fresh/recirc split; Dvorak 2025 (AIT, WEVJ 16:129) snippet: ~100 m³/h fresh air for 2 occupants at 1000 ppm CO₂ (**not yet read**: https://www.mdpi.com/2032-6653/16/3/129); driver-cab door-opening data NOT FOUND; SAE J2765 = MAC COP bench test, rev. J2765_201707.
- [CALC] CO₂ minimum from Chalmers inputs ≈ 20 m³/h per occupant (lower bound).
- [CALC] Check at −10 °C, cab 22 °C: UA 60 × 32 K = 1.92 kW + 100 m³/h fresh air 1.20 kW = 3.1 kW vs Chalmers 4.2–4.45 kW → HDEV still low while driving.
- **Key conclusion:** HVAC is a small part of the winter penalty; HDEV's missing winter share is mainly rolling resistance (cold + winter tyre class) and air density → take up in the tyre / consumption review.

### 4.3 Decisions [DECIDED, Bob 2 Nov]
1. **Fresh-air term added** in `ssm_total_w`: `q_freshair = rho * cp * Q / 3600 * (T_amb - T_calc)`, `rho = p / (R * (T_amb + 273.15))`. `Q = 0` → exactly VECTO; parser default 100 m³/h (after Dvorak check). Flag: humidity / latent cooling load ignored.
2. **No change to area/U** (Bob: "silly change, not needed"). Keep `A_surface` and `U`.
3. **Missing heat-pump COP (non-R-744 at −20 °C): clip to the −5 °C value.** Done in the **parser**: fill the missing COP with the nearest available one (−20 °C gets the −5 °C value) → `np.interp` gives a flat line = clip. No engine change. Flagged as optimistic below −5 °C. (Without this, `np.interp` with a NaN point gives NaN for every hour between −20 and −5 °C and the engine error fires.)
4. **Setpoints** stay arguments with VECTO defaults (`T_heat=18`, `T_cool=23`, `T_cool_off=17`); note Mercedes tested at 21 °C, Chalmers 22 °C.
5. Weather gaps filled in the parser (a NaN hour would silently give 0 W). Engine guard optional (Bob: leave to parser).
6. Optional items (unmet heat/cool outputs, `eh_eff > 0`, ascending points) → parser.

### 4.4 The one edit Bob still has to make
In `def HVAC_thermal(...)` add at the end of the arguments:
```python
                 waste_heat=0.0, T_heat=18.0, T_cool=23.0, T_cool_off=17.0, Q=0.0, p=101325.0, R=287.05, cp=1005.0):
```
and pass them in both calls (otherwise `ssm_total_w` raises a TypeError):
```python
  run1 = ssm_total_w(T_amb, solar, T_heat, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor, p, R, cp, Q)
  run2 = ssm_total_w(T_amb, solar, T_cool, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor, p, R, cp, Q)
```

### 4.5 Code of record (with the 4.4 edit applied)
```python
def ssm_total_w(T_amb, solar, T_calc, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor, p, R, cp, Q):
  T_amb = np.asarray(T_amb, dtype=float) # outside temp per weather hour [°C]
  solar = np.asarray(solar, dtype=float) # sunlight per weather hour [W/m²]
  rho = p / (R * (T_amb + 273.15)) # density of outside air
  q_wall = (T_amb - T_calc) * A_surface * U
  q_people = N_persons * np.where(T_amb < T_boundary, heat_per_person[0], heat_per_person[1])
  q_solar = solar * A_window * g * np.where(T_amb < T_boundary, clouding[0], clouding[1]) * solar_factor
  q_freshair = rho * cp * Q / 3600 * (T_amb - T_calc)
  return q_wall + q_people + q_solar + q_freshair

def climate_lookup(T_amb, T_heat_points, cop_heat_points, T_cool_points, cop_cool_points, hp_share_points, eh_share_points, fuel_share_points):
  T_amb = np.asarray(T_amb, dtype=float)
  cop_heat = np.interp(T_amb, T_heat_points, cop_heat_points)
  cop_cool = np.interp(T_amb, T_cool_points, cop_cool_points)
  dist = np.abs(T_amb[..., None] - np.asarray(T_heat_points, dtype=float))
  idx = np.argmin(dist, axis=-1)                          # tie -> first = colder
  hp_share = np.asarray(hp_share_points, dtype=float)[idx]
  eh_share = np.asarray(eh_share_points, dtype=float)[idx]
  fuel_share = np.asarray(fuel_share_points, dtype=float)[idx]
  return cop_heat, cop_cool, hp_share, eh_share, fuel_share

def HVAC_thermal(T_amb, solar, A_surface, U, N_persons, A_window, T_heat_points, cop_heat_points, T_cool_points, cop_cool_points,
                 hp_share_points, eh_share_points, fuel_share_points, max_heating_power, max_cooling_power, cab_volume, vent_rate, vent_rate_heating,
                 eh_eff=0.93, spec_vent_power=0.56, heat_per_person=(50.0, 80.0), clouding=(0.65, 0.8), T_boundary=17.0, g=0.95, solar_factor=0.25,
                 waste_heat=0.0, T_heat=18.0, T_cool=23.0, T_cool_off=17.0, Q=0.0, p=101325.0, R=287.05, cp=1005.0):
  T_amb = np.asarray(T_amb, dtype=float)
  # step 1: heat balance at 18 and 23 C
  run1 = ssm_total_w(T_amb, solar, T_heat, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor, p, R, cp, Q)
  run2 = ssm_total_w(T_amb, solar, T_cool, A_surface, U, N_persons, A_window, heat_per_person, clouding, T_boundary, g, solar_factor, p, R, cp, Q)
  losing_heat = (run1 < 0) & (run2 < 0)
  heating_demand = np.where(losing_heat, np.abs(np.maximum(run1, run2)) - waste_heat, 0.0)
  heating_demand = np.maximum(heating_demand, 0.0)
  # step 2: split + cap (SSMCalculate.cs 215-245)
  cop_heat, cop_cool, hp_share, eh_share, fuel_share = climate_lookup(T_amb, T_heat_points, cop_heat_points, T_cool_points, cop_cool_points, hp_share_points, eh_share_points, fuel_share_points)
  fuel_heat = heating_demand * fuel_share
  sum_heat = np.minimum(max_heating_power, heating_demand * (hp_share + eh_share))
  rest = np.where(np.isclose(fuel_share, 1.0), 1.0, 1 - fuel_share)
  scale = sum_heat / rest
  hp_heat = scale * hp_share
  eh_heat = scale * eh_share
  # step 3: heating electric W
  if np.any((hp_heat > 0) & np.isnan(cop_heat)):
    raise ValueError("heat pump COP missing for this temperature")  # HDEV: VECTO silently gives 0 W here
  HP_el = np.where(hp_heat > 0, hp_heat / cop_heat, 0.0)
  EH_el = eh_heat / eh_eff
  # step 4: cooling
  gaining_heat = (run1 > 0) & (run2 > 0) & (T_amb >= T_cool_off)
  cooling_demand = np.where(gaining_heat, np.minimum(run1, run2), 0.0)
  cooling_demand = np.minimum(cooling_demand, max_cooling_power)
  if np.any((cooling_demand > 0) & np.isnan(cop_cool)):
      raise ValueError("cooling COP missing for this temperature")
  AC_el = np.where(cooling_demand > 0, cooling_demand / cop_cool, 0.0)
  # step 5: ventilation fan (SSMCalculate.cs 270-295, 376-397, 399-428; SSMInputs.cs 88)
  ventillation_status = ((T_amb < T_cool_off) & (run1 > 0) & (run2 > 0)) | ((run1 > 0) & (run2 < 0))
  fan_rate = np.where(losing_heat, vent_rate_heating, np.where(gaining_heat | ventillation_status, vent_rate, 0.0))
  fan_el = cab_volume * fan_rate * spec_vent_power
  # step 6: total (into P_aux as HVAC_power with HVAC_eff = 1.0)
  HVAC_el = HP_el + EH_el + AC_el + fan_el
  return HVAC_el, fuel_heat
```

### 4.6 HVAC parser jobs
- Fill missing COP points with the nearest available value (clip), flagged.
- Fill weather gaps before the call.
- `Q` default 100 m³/h (after Dvorak check); 0 = VECTO.
- Cab inputs: no silent defaults beyond flagged placeholders; NREL measured UA 51–65 W/K (US sleeper, parked) as reference; day cab unsourced.
- `HVAC_eff = 1.0` in thermal mode; max heating/cooling power missing → no cap (`np.inf`), flagged.
- Checks: `eh_eff > 0`, heating/cooling points ascending, `T_amb`/`solar` same shape; HD-case column picking (see 19 Oct close-out).
- Fuel heater: VECTO caps at `FuelFiredHeaterPower` and ÷ 0.80 for fuel use — only needed if diesel use is reported.

### 4.7 HVAC report flags
Bus SSM used for a truck cab (no lorry method in 2017/2400 incl. 2025/258); hourly instead of 11 VECTO points; COP interpolation, nearest-point split, COP clip below −5 °C; fresh-air term on (non-VECTO); 0.25 solar factor unexplained in VECTO; unverified whether VECTO `solar` = DMI global horizontal radiation; measured UA is parked (lower bound while driving); humidity ignored; door openings and cold-cab warm-up not modelled → urban winter = lower bound.

### 4.8 Left out / parked
Door openings (no cab data), cold-cab warm-up (needs thermal mass), CO₂-controlled recirculation, per-person scaling of Q. Option test via Kiro (heating setup × fresh-air flow × cab U/area sensitivity, vs eActros) only once cab values are sourced — prompt drafted in chat, not run.

---

## 5. Open items / next steps
1. Bob: make the 4.4 edit; optionally paste for a final check.
2. Bob: read Dvorak 2025 to confirm 100 m³/h; optionally NREL TP-5400-66860 (https://www.nlr.gov/docs/fy16osti/66860.pdf) for more cab data.
3. Next function review: `force_engine` or `driver_model` (+ drivetrain standard-value maps, coasting drag table).
4. Tyre / winter: winter penalty is mainly rolling resistance — revisit cold tyres (ISO 28580 used outside range) with Chalmers Crr 0.007→0.014 and the tyre-class effect from Mercedes.
5. Default payload decision (reference vs max).
6. Danish weights order + modulvogntog lookup (retsinformation.dk); EUR-Lex Art. 10b for 1 t vs 2 t.
7. Parser (`defaults.py`): all jobs listed in sections 2, 3, 4.6 and in the PTO close-out.
8. Fetch list: `claude/files-to-fetch-2026-11-02.md`.
