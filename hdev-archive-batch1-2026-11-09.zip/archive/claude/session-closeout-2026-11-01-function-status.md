# HDEV close-out: function status after the 30 Oct - 1 Nov review

Read this first in a new chat. Details live in:
- `claude/session-closeout-2026-10-31-pto.md` (PTO design, final `pto_engine`, efficiency rules, parser jobs)
- `claude/session-closeout-2026-10-22-function-review-crosswind-payload-pto.md` (crosswind and payload review)

## Status

| Function | Status | Note |
|---|---|---|
| `crosswind_engine` | **Final** | Unchanged. 10° yaw clamp stated in every report. Parser: speed grid 60-130 km/h, no 0 km/h. |
| `pto_engine` | **Final (engine side)** | Fix of record: `return is_on, pto_start, stop_1s, drive_1s` (not `is_stop`). Profiles divided by efficiency inside. |
| `P_aux` | **Final** | Fix of record: VECTO factors multiplied, only always-on PTO divided (code below). |
| `payload_engine` | **Final (1 Nov)** | Engine unchanged. Parser: `linear` without `payload_end` -> clear error; NaN check; cleaned `stop` copy for stops switched off; cap; tonnes->kg; default payload. |
| `SP_power_helper` | **Final (1 Nov)** | Matches VECTO `SteeringPump.cs` exactly (per-axle shares, averaged tech factor, mechanical W; x0.7 in `P_aux` matches adapter line 220). Optional guard: `SP_baseline` has 3 values. |
| `driver_model` + helpers | Not reviewed | Merged with the drivetrain standard-value work. |
| `force_engine` | Not reviewed | |
| HVAC helpers, `consumption_engine`, parser, battery engine | Open | See earlier close-outs. |

Bob to confirm the two fixes are applied in his notebook.

## `P_aux` version of record

```python
##5.1 Electrical system
def P_aux(ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on, ES_alteff=0.7, PS_alteff=1.0, HVAC_eff=1.25, SP_alteff=0.7, cond_eff=1.0, PTO_eff=1.0):
  powers = [np.asarray(p, dtype=float) for p in (ES_power, PS_power, HVAC_power, SP_power, cond_power)]
  effs = (ES_alteff, PS_alteff, HVAC_eff, SP_alteff, cond_eff)
  PTO_always_on = np.asarray(PTO_always_on, dtype=float)

  for p in powers + [PTO_always_on]:
      if np.any(p < 0):
          raise ValueError("aux power cannot be negative")
  for e in effs + (PTO_eff,):
      if e <= 0:
          raise ValueError("efficiency must be > 0")

  ES_power, PS_power, HVAC_power, SP_power, cond_power = (p * e for p, e in zip(powers, effs)) # VECTO factors: multiply
  PTO_always_on = PTO_always_on / PTO_eff # shaft W / efficiency = electric W (1.0 = already electric)

  return ES_power, PS_power, HVAC_power, SP_power, cond_power, PTO_always_on
```

Why: VECTO multiplies (ES 1428.57 W x 0.7 = 1000 W; HVAC 200 W x 1.25 = 250 W; SP 32.87 W x 0.7 = 23.0 W, all matching the VECTO .vmod).

## Payload: weights law (Kiro research, 1 Nov)
- Revision 2023/0265(COD) not adopted; Directive 96/53/EC applies.
- Zero-emission allowance: likely max 2 t (Reg. 2019/1242 Art. 20 amending 96/53/EC; Irish SI 47/2025; DK BEK 1663/2023 §22(2)(3),(7)). Kiro read 1 t (alt-fuel only); EUR-Lex Art. 10b text itself not yet read. Allowance = actual extra ZEV tech weight, capped, not a flat +2 t.
- DK BEK 1663/2023 is Historic; successor (reported 20 t / 28 t rigids) and the 60 t modulvogntog order not found. Bob to look up on retsinformation.dk.
- Decision proposed: payload cap uses registered GVW (VECTO TPMLM): max payload = GVW - curb - body/trailer. Legal limits only as a later warning.
- Open: default payload for sizing (VECTO reference vs max payload).

## Steering pump: VECTO checks (1 Nov)
- Standstill: VECTO switches the BEV electric steering pump OFF when the vehicle is stopped (`ElectricAuxiliaries.PowerDemand`, ignore list `{SteeringPump}`; `Constants.cs` 59-60: `SteeringPump` and `SteeringPump_el` are both "STP", so the electric pump is dropped too; Kiro research, verified by Claude). This looks incidental to the shared ID, so flag it in reports. HDEV rule "SP on when moving" matches VECTO.
- VECTO's stopped test: |v| <= 0.01 m/s (`Vehicle.cs` 262, per Kiro). Consumption engine should use the same threshold.
- Parser jobs: PEV-applicable techs only (SP-Tech PEV column); max 4 steered axles; tech count = steered axles; clear error for empty SP-Table cells (groups 1s-3 have no Municipal/Construction; 6-8 empty); custom W bypasses the helper.

## HVAC_thermal review (1 Nov) [in progress]
- Checked against VECTO `SSMCalculate.cs`: heating demand (744-773), split + cap (215-245), heating COP / eh_eff (172-212), cooling (337-374 and 553-570: T >= 17, both runs > 0, min(run1, run2), capped, / COP), ventilation (272-296, 376-428; `SSMInputs.cs` 85-88 VentPower = volume x rate x specific power). Bob's version matches, with all three VECTO ventilation switches on.
- run1 >= run2 always (same loads, setpoint 5 K apart), so "run1 < 0 and run2 > 0" cannot happen; the three modes cover every hour.
- Proposed: NaN weather guard (NaN hours silently give 0 W now); eh_eff > 0 and shape guards; fresh-air load (non-VECTO, switch) added to the heat balance so it goes through split, cap and COP; optional unmet-heat / unmet-cooling outputs for reports.
- Fuel heater: VECTO caps at FuelFiredHeaterPower and divides by 0.80 for fuel use; HDEV returns heat only (fine for battery; needed only if diesel use is reported).
- Kiro research (1 Nov, PR #20 in `hdev`: `docs/research/hvac-thermal-parameters-2026-11.md`):
  - Reg. (EU) 2025/258 adds no lorry thermal HVAC; SSM stays bus-only, so SSM for a lorry = HDEV extension (flag).
  - VECTO VentilationRate has no fresh/recirculated split (single air-change rate x volume x 0.56 Wh/m3); no 2017/2400 wording found.
  - Fresh-air need ~100 m3/h for 2 occupants at 1000 ppm CO2 (Dvorak 2025, AIT, from search snippet; Bob to verify in paper).
  - Cab A/U/volume/window: NREL CoolCab/CoolCalc reports (TP-5400-52452, 66860) hold them in PDF tables, not read; placeholders stay unsourced until Bob reads them.
  - Validation targets: Oko-Institut ELV-LIVE (19 eActros, 0.96 kWh/km); JRC133756 heating at -7 C is 4-10x cooling at 35 C; eActros 600 OEM winter about +25 % (claim).
  - Door openings for a driver cab: NOT FOUND. SAE J2765 = MAC system COP bench test, current rev. J2765_201707.
- Illustration (placeholders, not a result): 100 m3/h fresh air at -5 C to 18 C = about 845 W heat (rho 1.316, cp 1005), vs 1330 W wall loss for the made-up 20 m2 / U 3.0 cab.
- PDFs read by Claude (2 Nov):
  - NREL CoolCab fact sheet (973699): measured UA, US long-haul sleeper cab, base case, parked at night, 1 kW heater inside: **65 W/K (truck 1), 51 W/K (truck 2)**; curtain + shades -16/-21 %, insulated windows -16/-14 %, arctic curtain -26 %.
  - Lustbader 2012 (SAE): UA test = heater inside closed truck overnight, Q / dT, so UA includes natural leaks; infiltration measured separately (SF6, ACH) and CoolCalc adds it separately (52452). Forced fan fresh air is NOT in a measured UA -> fresh-air term goes on top, no double count.
  - Placeholder A 20 m2 x U 3.0 = 60 W/K sits inside the measured 51-65 W/K. Only A x U is used in `ssm_total_w`, so one UA input is enough.
  - Measured UA is parked; driving raises outside convection (Chalmers models it by speed) -> parked UA is a lower bound while driving.
  - Ramesh Babu 2025 (Chalmers/Volvo, simulated): heater 4.15-4.45 kW at -10 C, cab 22 C, 30-90 km/h, no recirculation; recirculation not standard in electric trucks below 20 C (fogging); cites ventilation >70 % of heating load (Zhang et al.); CO2 source 21.6 g/h/occupant, set 1000 ppm, ambient 420 ppm; aux 1.8 kW at 10 C to 9 kW at -20 C (incl. battery heating); consumption +58 % at -20 vs 20 C; Crr 0.007 (20 C) to 0.014 (-20 C).
  - Oko ELV-LIVE (measured, eActros, -7 to 36 C): -0.13 kWh/km per +10 C at 0.96 kWh/km mean; 400 km -> 358 km at 10 C vs 20 C; cooling unit +0.092 kWh/km.
  - JRC Gil-Sayas 2022: passenger cars (not trucks), MAC heating at -7 C 4-10x cooling at 35 C.
  - Dollinger & Fischerauer 2021: winter reduces range 7-9 % (model, cars and trucks).
  - [CALC] CO2-minimum fresh air from Chalmers inputs: about 20 m3/h per occupant (lower bound); Dvorak 2025 snippet 100 m3/h for 2 (not yet read: https://www.mdpi.com/2032-6653/16/3/129).
  - [CALC] HDEV check at -10 C, 22 C cab: UA 60 x 32 K = 1.92 kW + 100 m3/h fresh air 1.20 kW = 3.1 kW vs Chalmers 4.2-4.45 kW -> HDEV still on the low side while driving.
- Mercedes eActros 600 winter tour 2025 (OEM press text, pasted by Bob): 40 t GCM, -18 to 9 C, avg speed 64-77 km/h. Representative section, avg -2 C, cold start, class B tyres, snow-free, vs same route in summer on class A tyres: **about +25 %**, of which cab climate at 21 C about 5 points, battery heating < 1, other aux < 1, lower recuperation about 4, higher rolling + air resistance about 15. Snowy/icy routes (class D Nordic tyres): almost +50 %. Hoteling (21 C day / 19 C night at -7 to 4 C): range -2 to -5 %.
  - Meaning: HVAC is a small part of the winter penalty; tyres (incl. winter tyre class) and air density dominate. HDEV's missing winter share is mainly in rolling resistance, not HVAC.
- DECIDED (Bob, 2 Nov): fresh-air term added in `ssm_total_w` (`q_freshair = rho*cp*Q/3600*(T_amb - T_calc)`, rho ideal gas from T_amb; Q = 0 -> VECTO, parser default 100 m3/h pending Dvorak check); missing heat-pump COP: clip to the -5 C value (drop NaN points in `climate_lookup`), flagged; no UA/area change (keep A_surface, U); setpoints stay arguments with VECTO defaults.
- Left to code: pass Q/p/R/cp from `HVAC_thermal` to both `ssm_total_w` calls; NaN-point drop in `climate_lookup`; NaN weather guard. Optional: unmet heat/cool outputs, eh_eff > 0 and ascending-points guards.

## Still open around these functions
- `HVAC_eff = 1.25` must be passed as 1.0 when HVAC comes from the thermal model (parser job, flagged 26 Oct).
- `PTO_always_on` must accept a per-hour array (fridge model later); `P_aux` already works for arrays.
- Consumption-engine PTO placement (PTO close-out, section 5).
