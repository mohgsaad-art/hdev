# HDEV project archive, batch 1 (9 Nov 2026)

These files were removed from the claude.ai project "HDEV sizing & Modelling Tool" to free knowledge space.
Nothing here is lost; this folder is the copy of record.

## pdf-text/
These are the text extracts the project held for three uploaded PDFs. They are not the PDFs themselves.
- `CELEX_02017R2400-20260101_EN_TXT.txt`: Reg. (EU) 2017/2400, EUR-Lex consolidated text as of 1 Jan 2026.
  The official PDF is on EUR-Lex (CELEX 02017R2400-20260101).
- `VEcto documentation.txt`: the VECTO documentation PDF.
- `sr7_lot4_final_report_en.txt`: the SR7 Lot 4 final report.

Bob has the original PDFs, which he uploaded.

Markdown transcriptions remain in the project:
- `claude/knowledge-base/eu-regulation-2017-2400/` (32 files);
- `claude/knowledge-base/vecto-methodology/`.

The indexes say to spot-check formulas against the original page images. Use the original PDFs for that.

## vecto-cs-copies/
- `WheelEnd.cs`, `ShiftStrategyFactory.cs`, `FuelCellSystem.cs`: project copies uploaded on 6 May 2026.
  These three are NOT on the `IEPC-experiments` branch of `mohgsaad-art/VECTO`.

The other 26 .cs files removed from the project exist on that branch under `VectoCore/VectoCore/Models/...`:
PTOCycleController, VectoSimulationComponent, Wheels, Battery, VTPCombustionEngine, Vehicle,
RoadSweeperAuxiliary, SimplePowertrainContainer, PWheelCycle, Retarder, PowertrainDrivingCycle,
MeasuredSpeedDrivingCycle, PWheelBatteryElectricMotorController, EngineAuxiliary,
ElectricSystemDrivingCycle, EngineFanAuxiliary, ElectricSystem, ElectricAuxiliaries, BEVCycleGearbox,
DummyGearboxInfo, Driver, DefaultDriverStrategy, DistanceBasedDrivingCycle, DrivingCycleEnumerator,
BatteryElectricMotorController and Conditioning.

The project copies may differ slightly from the branch version; they were not compared line by line.

## bob-early-notes/
- `Current code - 14th April 2026.py`: the April 2026 class-based driver model, force engine and consumption engine. Superseded.
- `Summary.md`: an early chat summary on the SOC engine and product ideas (BESS revenue tool, grid queue). Superseded by the later status docs.

## claude/
- `session-closeout-2026-11-01-function-status.md`, `session-closeout-2026-11-02-payload-sp-hvac.md` and `session-closeout-2026-11-03-driver-model-review.md`:
  merged into the project doc `claude/status-engine.md` (9 Nov).
- `hdev_test_harness_v1.7.py`: the 22 Oct test harness, the last version.
