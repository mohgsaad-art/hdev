**Full Chat Summary — SOC Engine + Product Ideas**

---

## PART 1: SOC ENGINE PROJECT

### What we are building
A physics-based simulation and sizing tool for heavy-duty EV depot charging — think PVsyst but for electric truck fleets. Full consulting tool that models EVs, sizes depots, and drives million-dollar infrastructure decisions. Also models diesel trucks for comparison. Built on top of MSc thesis work (MARL for HDEV depot charging in DK2). Current phase: building and validating the physics engines before adding the depot allocator and MARL layers.

---

### Architecture — three clean layers
- **Layer 1 — Physics engines** (current focus): consumption and charging, pure physics, deterministic, no strategy logic
- **Layer 2 — Depot allocator** (next): takes N trucks' charging needs, applies site limit, implements ASAP/JIT/EDF/MARL strategies
- **Layer 3 — Sizing wrappers** (later): iterative loops that call the engines to size battery and charger

---

### What is built and working

**Event dataclass:**
```python
@dataclass
class Event:
    type:         str    # "drive", "idle", "charge", "break"
    duration_min: int
    speed_kmh:    float
    charger_kw:   float
    theta:        float  # road grade in degrees
    pto_kw:       float
```

**force_engine(Crr, m, T, Cd, A, v, theta):**
- F_roll = Crr × m × g
- F_aero = 0.5 × ρ × Cd × A × v² (air density via ideal gas law from T in Kelvin)
- F_grade = m × g × sin(arctan(theta))
- F_accel = m × (1 + lambda) × a (currently a=0, lambda=0 — placeholder)
- η_drivetrain = motor × inverter × gearbox (currently all 0.9 placeholders)
- P_battery = (P_wheel / η_drivetrain) + P_aux
- **m is GVW — total moving mass including battery, payload, everything**
- Returns watts

**charging_physics_engine** (current version — agreed to replace):
- Per-minute stateful loop
- CC-CV taper using exponential decay above SOC_THRESHOLD=0.90
- Charger efficiency η=0.95
- V2G flag sets SOC floor to -0.2
- Returns soc_trace, current_kwh, charge_trace
- **This exponential model is to be replaced with VECTO OCV+R curve model**

---

### Key design decisions locked
- All parameters come from outside — engine never invents defaults
- Per-event calculation for consumption (stateless within event)
- Per-minute for charging (stateful — SOC changes each minute)
- energy_trace stores kWh per minute, not cumulative
- Estimator wrappers are external to engines
- Depot allocator is a separate layer above charging engine
- Tool models BEV, diesel, and hybrid for comparison (like PVsyst)

---

### Mass / GVW handling — fully resolved

**m in force_engine is GVW. Two distinct cases:**

For existing trucks: GVW is published, kerb_mass is published, battery already inside kerb_mass. User inputs GVW and payload. m = kerb_mass + payload_kg. No loop needed.

For hypothetical sizing (user says "40t class, here is my schedule"):
```
Step 1: Run engine with m = GVW_limit (conservative upper bound)
Step 2: battery_needed = total_consumption × buffer (e.g. 1.20)
Step 3: battery_mass_kg = 6.7 × (battery_kwh − ref_kwh) × 1000  [Zacharof et al. 2024]
Step 4: Check kerb_mass + battery_mass + payload ≤ GVW_limit. Flag if violated.
Step 5: Rerun with actual m = base_kerb + payload + battery_mass
Step 6: Iterate until battery_needed converges (3–5 iterations typical)
```

**Truck classes with GVW limits:**
```python
TRUCK_CLASSES = {
    "18t_rigid":  {"base_kerb_kg": 7500,  "gvw_limit_kg": 18000},
    "26t_rigid":  {"base_kerb_kg": 9500,  "gvw_limit_kg": 26000},
    "40t_artic":  {"base_kerb_kg": 15000, "gvw_limit_kg": 40000},
    "44t_artic":  {"base_kerb_kg": 16000, "gvw_limit_kg": 44000},
}
```
Base kerb masses from EU fleet average data — JRC VECTO dataset.

---

### Payload handling — resolved

Payload varies per leg. New leg structure:
```python
@dataclass
class Leg:
    type:          str    # "drive", "stop", "break"
    duration_min:  int
    distance_km:   float
    route_type:    str    # "long_haul", "regional", "urban", "custom"
    payload_kg:    float  # payload for THIS leg
    grade_pct:     float | None  # None = use cycle grade data
```

Payload templates:
- `linear_decrease`: delivery truck — drops load each stop
- `linear_increase`: collection truck — picks up load
- `constant`: fixed payload all day
- `custom`: user-supplied list per leg

For "200km, 50 stops" case: avg_leg = 4km → inferred urban. Payload distributed across 50 legs per chosen template.

---

### Physics to add to force_engine — decided

**P_aux (currently 0):**
- VECTO auxiliary energy module gives per-cycle values by component (cooling fan, steering pump, air compressor, electrical system, HVAC)
- For BEV: all auxiliaries pull directly from battery, not through drivetrain
- VECTO overview document gives citable Watt values by mission profile
- Comes from outside the engine as a parameter

**η_drivetrain (currently fixed 0.9×0.9×0.9):**
- VECTO Declaration Mode fallback per Regulation EU 2017/2400 Annex IX — citation for fixed fallback
- Zacharof et al. 2024 shows motor efficiency is speed-dependent: 0.87–0.88 at low speed, ~0.91 at high speed
- Short term: keep fixed, cite VECTO Declaration Mode
- Medium term: speed-dependent lookup table, same architecture as acceleration curve

**F_accel and regen:**
- Currently zero because Events have constant speed
- Regen requires second-by-second speed trace — not possible with current event-level format
- When speed trace available: if P_wheel < 0 → P_battery = P_wheel × η_regen (multiply not divide — direction matters)
- η_regen ≈ 0.65, citeable from ESCALATE project
- Regen material for urban/regional, negligible for long haul

**EM mass scaling (Zacharof et al. 2024):**
- Mem = 0.625 × (Pem − Pem_ref) kg/kW
- Only relevant for hypothetical sizing, not for existing trucks

---

### Charging engine — VECTO OCV+R replacement model

Replace exponential taper entirely with:

```python
OCV = interpolate(ocv_table, SOC)       # from VECTO generic battery XML (EUPL 1.2)
R   = interpolate(r_table, SOC)         # internal resistance, scales linearly with capacity
I_max = interpolate(max_current_table, SOC)
I_actual = min(P_requested / OCV, I_max)
V_terminal = OCV - I_actual × R
P_actual = V_terminal × I_actual
delta_SOC = P_actual / (battery_kwh × 3600)
```

Taper emerges from physics — as SOC rises, OCV rises, charger voltage limit approached, current drops naturally. No assumed band thresholds needed.

Heat generation is a byproduct: P_heat = I² × R — falls out automatically, report it as an output if needed, do not need to do anything special with it.

**Manufacturer-specific battery profiles — three tiers:**

Tier 1 — Generic: VECTO OCV + R curves (default, fully citable, EUPL 1.2)

Tier 2 — Manufacturer-declared:
- Scania NMC: linear behaviour within 15–83% SOC window. BMS never reaches taper region. Implemented as: narrow SOC window on generic NMC curve. Citation: Scania press release Oct 2023
- Mercedes eActros LFP: CC-CV transition at ~90–95% SOC by LFP chemistry. Different OCV curve shape. Citation: LFP chemistry literature
- Volvo FH Electric: NMC, near-full power to 86–89% SOC

Tier 3 — Real cell data: proprietary, not available. Tool states this explicitly.

```python
def get_battery_model(truck_model):
    # returns standardised dict: chemistry, ocv_curve, soc_min, soc_max, citation
    # charging engine takes this dict regardless of source
```

---

### Diesel and hybrid comparison

**Diesel path:**
- Same force_engine for P_shaft
- Then lookup fuel consumption from engine fuel map (torque × RPM → g/kWh)
- VECTO ships generic Euro VI fuel maps — copy under EUPL 1.2
- For user's real diesel truck: use their measured L/100km from fleet records — more accurate than any generic map

**Hybrid path:**
- Diesel physics + hybridisation reduction factors from Zacharof et al. 2024 by route type:
  - Urban delivery: 15.9% reduction
  - Regional delivery: 4.8% reduction
  - Long haul: 2.7% reduction
- Applied as lookup correction, not full hybrid simulation
- Defensible because it cites JRC paper directly

---

### VECTO driver model — what we learned from the actual source code

Read DefaultDriverStrategy.cs, DistanceBasedDrivingCycle.cs, and Driver.cs from code.europa.eu/vecto/vecto (EUPL 1.2).

**Cycle file format — confirmed from source:**
- Distance-based: `[distance_m, speed_kmh, altitude_m, stop_time_s]`
- Grade NOT stored directly — derived from altitude difference between consecutive waypoints
- Speed at each waypoint is TARGET speed — the driver model computes actual speed
- Three lorry profiles: Long Haul (~80 km/h), Regional Delivery (~60 km/h), Urban Delivery (~29 km/h)
- Files are in VECTO download from code.europa.eu/vecto/vecto/-/releases

**What the actual VECTO profiles look like:**
- NOT rectangular waveforms — they have hundreds of speed changes per cycle
- Long Haul: mostly 80 km/h but with drops to 60, 50, stops throughout
- Regional: constant switching between 60, 50, 30, 0
- Urban: chaotic — 50, 30, 0, 10, 50, 0 — high frequency stop-start
- This was confirmed from Zacharof et al. 2024 Figure 2 which shows the actual cycle plots

**Key functions from Driver.cs relevant to BEV:**

ComputeAcceleration (port this — 10 lines):
```
dt = 2 × ds / (v_current + v_target)
a_required = (v_target - v_current) / dt
clip against AccelerationCurve.Lookup(v_current)
```

LimitAccelerationByDriverModel: clip against speed-dependent acceleration curve

GetNextDrivingAction (look-ahead braking trigger):
```
lookahead_distance = v_kmh × LookAheadDistanceFactor
scan ahead for next speed reduction
trigger coast or brake accordingly
```

ComputeCoastingDistance: energy conservation — kinetic + potential energy at current vs target position, divided by coasting resistance force. Replace ICE drag with motor drag for BEV.

**What to ignore from VECTO source (all ICE-specific):**
- SearchOperatingPoint, SearchBrakingPower, SetTCOperatingPointATGbxCoastOrRoll
- HandleEcoRoll, HandlePCC, HandleEngineStopStartDuringVehicleStop
- All gear shifting, torque converter, clutch logic

**For BEV the whole driver model is ~100-150 lines of Python, not 2000+ lines of C#**

**Acceleration curve — differs for BEV vs diesel:**
- VECTO generic curve derived from diesel HDVs
- BEV: higher low-speed acceleration (max torque from zero RPM), similar or slightly lower at high speed
- For existing trucks: use manufacturer performance specs to back-calculate curve at key speed points
- For generic BEV: apply ~20% upward correction at low speeds vs VECTO generic

---

### Schedule to speed trace — the core unresolved design question

**Current Events have constant speed — blocks regen and accurate acceleration energy.**

User inputs are operational: "200km, 50 stops" — no speed waypoints provided or expected.

**Two paths discussed:**

Path A — Port VECTO driver model:
- Take VECTO cycle file for the route type
- Run ported driver model over waypoints
- Get second-by-second trace with all speed variation shown in the actual VECTO profiles
- Citation: VECTO source code, EUPL 1.2
- Fully auditable

Path B — Synthetic trace from schedule:
- Route type gives cruise speed, stop statistics from VECTO cycle documentation
- Leg distances from log-normal distribution (Holguin-Veras freight literature)
- Each leg: accelerate → cruise → brake using acceleration curve
- Braking trigger: remaining_distance ≤ braking_distance (VECTO look-ahead)
- Short legs: bisect for peak speed when d_accel + d_decel > leg_distance
- Problem identified: produces rectangular waveforms — not realistic, misses intra-leg speed variation

**Conclusion: Path B is only valid for rough energy estimation. For defensible regen modelling and accurate acceleration energy you need Path A — the actual VECTO cycle files as input.**

The synthetic generator is useful only when no cycle data is available and the user cannot characterise their route type at all.

---

### Danish road grade — resolved

- VECTO profiles include European average grades — too hilly for Denmark
- Denmark average elevation 36m, total relief 178m — essentially flat for freight purposes
- Danish road grade from: **Danmarks Højdemodel (DHM/Terræn)**, Klimadatastyrelsen, via dataforsyningen.dk
- 0.4m resolution LiDAR, freely available
- Workflow: road network shapefile + DHM raster → sample elevation along centreline every 15-50m → compute grade
- Citation: Klimadatastyrelsen DHM/Terræn, dataforsyningen.dk
- Implementation: use VECTO speed trace but replace grade column with Danish values for DK2 localised version

---

### Key citations bank

- VECTO source code and generic data: European Commission, code.europa.eu/vecto/vecto, EUPL 1.2
- Regulation (EU) 2017/2400: VECTO certification mandate for HDVs
- Zacharof et al. 2024, Energies 17(2):286: Mbat equation (6.7 kg/kWh), Mem equation (0.625 kg/kW), motor efficiency maps, hybridisation factors by route type, battery size effects on mass and consumption
- Butt & Li 2025 (arXiv:2507.18853): original piecewise SOC-band model — superseded by VECTO OCV approach but still citable as prior work
- Danmarks Højdemodel (DHM/Terræn): Klimadatastyrelsen, dataforsyningen.dk
- Holguin-Veras et al.: log-normal freight leg distance distribution
- Scania press release Oct 2023: 15–83% SOC window for Scania NMC battery
- EC 561/2006: EU driver duty cycle regulations used in thesis for schedule generation
- ESCALATE project: η_regen ≈ 0.65 for zero-emission truck regen efficiency

---

### Immediate next steps (in order)

1. Replace charging_physics_engine exponential taper with VECTO OCV + R curve model
2. Add P_aux to force_engine (VECTO citable values by route type, comes from outside)
3. Upgrade η_drivetrain to speed-dependent lookup
4. Implement leg format with payload per leg
5. Download actual VECTO cycle files (.vdri) and build parser
6. Port VECTO driver model (Path A) to get realistic speed traces
7. Wire regen into force_engine with sign-aware efficiency
8. Diesel path (same force_engine, different post-processing)
9. Depot allocator layer

---

## PART 2: PRODUCT IDEAS DISCUSSED

### Idea 1 — BESS Project Revenue Modelling (agreed best near-term product)

**What it is:** A tool that takes a battery storage project's technical specifications and produces a defensible revenue distribution across Danish and European flexibility markets, with an optimal bidding strategy.

**Target customer:** BESS project developers and their project finance banks, making investment decisions before financial close. Not aggregators, not asset operators — upstream of them.

**Why this customer specifically:** They have all technical specs already documented from the engineering and procurement process. No site visit needed, no telemetry needed, no hardware. The flexibility window for a standalone BESS is trivially computed from the spec sheet — SOC bounds, charge/discharge rates, round-trip efficiency. Everything is known.

**What they cannot do in Excel or AI:**
- Stochastic simulation against real Energinet activation signals (FCR-D, aFRR, mFRR historical data — public but requires real processing)
- Market stacking optimisation across all products simultaneously under real constraints — LP or RL problem, not a spreadsheet
- Degradation cost model — cycling depth × C-rate × temperature → capacity fade → replacement cost, feeds into true NPV optimisation
- Prequalification gap analysis — encoding actual Energinet technical requirements as structured assessment
- P10/P50/P90 revenue distribution — not a point estimate

**What they are paying for:** Accuracy, speed, and defensibility. The number from Excel is wrong in ways they cannot detect. Consultant takes 3 months and €80k. This tool gives the right number fast with a cited methodology they can put in front of a CFO or bank.

**Two product forms:**
- Form A: Assessment report, one-time, €5–15k per project. First 5 done as paid consulting to validate model, then productised.
- Form B: Ongoing bidding optimisation SaaS, €1–3k/month or % of revenue. Requires asset control integration — build later.

**Moat:** Historical activation data processed into calibrated simulation (public data, takes effort), prequalification outcome patterns across multiple assets, track record of predictions vs actual revenue.

**Generalised flexibility tool — why it collapsed:**
- Discussed extending to all asset types (factories, data centres, HVAC)
- Problem: flexibility window requires knowing operational constraints which differ completely per asset type and cannot be known from outside without site visit or telemetry
- Aggregator solution (Sympower, Flexitricity): hardware gateway reads live asset state — requires going on-site, competing with aggregators
- Conclusion: generalised approach does not work. Narrow to BESS where asset is fully characterised by spec sheet.

---

### Idea 2 — Grid Connection Queue Analytics (interesting but timing risk)

**The problem:** Denmark Energinet froze all new grid connection agreements March 2025. 60 GW in queue against 7 GW peak demand. Data centres account for 14 GW of queue. No prioritisation criteria exist yet — Energinet designing them in a 3-month window while Denmark forms a new government.

**Tariff change confirmed:** Old Energinet tariff was purely DKK/MWh (energy only). Capacity charge DKK/MW/year is genuinely new in 2025 — confirmed from Energinet's own development document: "Today, the grid tariff is collected as a fixed price energy payment. Therefore, Energinet will introduce a capacity payment." This was not a rebalancing, it is a new component.

**What the product would be:** Tool helping queued applicants understand and strengthen their position under whatever criteria Energinet publishes. Likely criteria based on UK/US precedents: project maturity, willingness to accept curtailment/flexibility, energy efficiency, economic contribution to Denmark.

**Why timing is risky:**
- Criteria do not exist yet — building a tool against unpublished criteria
- Once criteria published, Rambøll/Niras/WSP will have methodology out within weeks
- They have existing client relationships with data centre developers and regulatory credibility

**Data centre capacity sizing gap — concluded no gap:**
- Large hyperscalers (Microsoft, Google) have internal teams, do not need a tool
- Smaller operators hire consultants who do deterministic load calculations — not a complex problem
- PUE × IT load = total MW is not a hard calculation
- The gap is not capacity sizing, it is queue prioritisation — which has the timing risk above

**Conclusion:** Queue analytics has the right structural characteristics (growing, painful, technical gap) but timing and competition risk make it hard to productise right now. Revisit once Energinet publishes prioritisation framework.

---

### Other ideas discussed and assessed

**O&M optimisation for offshore wind:** Biggest market, direct skill fit, but requires vessel logistics and turbine failure data domain expertise not yet developed. Stretch.

**Scope 3 carbon accounting:** Large market but commoditising fast, many startups entering, less technical differentiation.

**Renewable pre-feasibility screening:** Good fit, user has Hesselø feasibility experience, but longer sales cycle — replacing analyst work.

**PPA risk analytics:** Right market, needs advisory firm relationships as sales channel.

**Grid congestion analytics for developers:** Real pain, power systems skills apply, but more technical infrastructure to build.

**Electricity price forecasting for industrial consumers:** Clear budget holder, clear ROI, but requires building forecasting credibility track record over time.

**Flexibility asset valuation generalised:** Collapsed — cannot know flex window without live telemetry or site visit for arbitrary assets. Narrowed to BESS only.

---

### Overall product conclusion

**Build the BESS revenue modelling tool first.** It pays fastest because:
- Asset is fully characterised by spec sheet — no site visit, no hardware, no telemetry
- Customer already has a budget (project finance due diligence)
- Your thesis already built the flexibility quantification and optimisation methodology
- Market is growing fast — EU BESS market expanding rapidly driven by renewable integration
- First 5 customers are in Denmark, reachable through energy sector network from SEC presidency role